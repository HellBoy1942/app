/**
 * File : addLeague.js
 * 
 * This file contain the validation of add league form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
	
	var newLeague = $("#newLeague");
	
	var validator = newLeague.validate({
		
		rules:{
			name :{ required : true },
			league_type :{ required : true },
			match :{ required : true },
			win_amount :{ required : true },
			size :{ required : true },
			margin : { required : false },
			entry_fees : { required : false },
			set_of_winners : { required : true },
		},
		messages:{
			name :{ required : "This field is required" },
			league_type :{ required : "This field is required" },
			match :{ required : "This field is required" },
			win_amount :{ required : "This field is required" },
			size :{ required : "This field is required" },
			margin : { required : "This field is required"},
			entry_fees : { required : "This field is required" },
			set_of_winners : { required : "This field is required" }
		}
	});

$("#add").click(function() {
        //var check = checkAvailableRank();
        var set_of_winners = $("#set_of_winners").val();
        var min_rank = 1;
        var max_rank = set_of_winners;

        var win_amt = parseFloat($("#win_amount").val());
        var rank_amt = (win_amt/set_of_winners);
        var rank_per = (rank_amt * 100) / win_amt;

        // if (check.list > 0) {
        //  min_rank = check.min_rank;
        //  max_rank = check.max_rank;
        //  rank_per =  check.rank_per;
        // }
        var lastField = $("#winner_detail_wrap div:last");
        var intId = (lastField && lastField.length && lastField.data("idx") + 1) || 1;
        var fieldWrapper = $("<div class=\"fieldwrapper\" id=\"field" + intId + "\"/>");
        fieldWrapper.data("idx", intId);
        var minRank = $("<input type=\"text\" placeholder=\"Min Rank\" name=\"min_rank" + intId + "\" class=\"min_rank fields\" />");
        var maxRank = $("<input type=\"text\" placeholder=\"Max Rank\" name=\"max_rank" + intId + "\" class=\"max_rank fields\"/>");
        var rankPercent = $("<input type=\"hidden\" placeholder=\"Percent\" name=\"rank_peercent" + intId + "\" class=\"rank_percent fields\"/>");
        var rankAmt = $("<input type=\"text\" placeholder=\"Amount\" name=\"rank_amt" + intId + "\" class=\"rank_amt fields\"/>");
        var removeButton = $("<input type=\"button\" class=\"remove fields\" value=\"x\" />");
        removeButton.click(function() {
            $(this).parent().remove();
        });
        fieldWrapper.append(minRank);
        fieldWrapper.append(maxRank);
        fieldWrapper.append(rankPercent);
        fieldWrapper.append(rankAmt);
        fieldWrapper.append(removeButton);
        $("#winner_detail_wrap").append(fieldWrapper);
    });

function checkAvailableRank(event, val) {

        var set_of_winners = $("#set_of_winners").val();
        var minranks = 1;
        var maxranks = set_of_winners;

        var win_amt = parseFloat($("#win_amount").val());
        var rank_amt = (win_amt/set_of_winners);
        var rankpers = (rank_amt * 100) / win_amt;

        var sets = $("#winner_detail_wrap").find(".fieldwrapper");
        var prv_obj = sets.last();
        var list = prv_obj.length;
        if (list > 0) {
            minranks = $(prv_obj).find('.min_rank').val();
            maxranks = $(prv_obj).find('.max_rank').val();
            rankpers = $(prv_obj).find('.rank_percent').val();
            if (event === 'min_rank') {
                if (val < minranks || val > maxranks || val > set_of_winners) {
                    alert("Invalid Minimum Rank");
                    return false;
                }
            }
            if (event === 'max_rank') {
                if (val < minranks || val > set_of_winners) {
                    alert("Invalid Maximum Rank");
                    return false;
                }
            }
            if (event === 'rank_percent') {
                if (val > 100) {
                    alert("Invalid Percentage");
                    return false;
                }
            }

            //return result;
        }
        //return false;
    }
	$("#league_type").change(function(){
		if ($(this).val() == 'CASH') {
			//alert('hlo');
			$('#name').val('CASH');
			
		} else if ($(this).val() == 'PRACTICE') {
			$('#name').val('PRACTICE');

		}
		else if ($(this).val() == 'MEGA') {
		$('#name').val('MEGA');	

		}

	});
    function entryFees()
    {
        var win_amt = parseFloat($("#win_amount").val());
        var size = parseFloat($("#size").val());
        var margin = parseFloat($("#margin").val());
        var total_earning = (win_amt + (win_amt * (margin / 100)));

        var entry_fees = (total_earning / size);
        var entry_fees = entry_fees.toFixed(2);
        $("#entry_fees").val(entry_fees);
    }

    /*function winnerRank()
    {
    	var leage_size = $("#size").val();
    	var set_of_winners = $("#set_of_winners").val();
    	// if (parseInt(leage_size) < parseInt(set_of_winners)) {
    	// 	$('#winner_section').html('');
    	// 	$('#win_error').html('Set of winners can not be more than leage size');
    	// 	return false;
    	// }
        var win_amt = parseFloat($("#win_amount").val());
        var rank_amt = (win_amt/set_of_winners);
        var rank_per = (rank_amt * 100) / win_amt;
        var rank_html = '';
        rank_html += '<div class="box-body table-responsive">';
        rank_html += '<table class="table table-hover table-bordered table-striped">';
        rank_html += '<tr><th class="text-center" colspan="5">Winners</th></tr>';
        rank_html += '<tr><th>Rank</th><th>Winner Ammount (%)</th><th>Amount</th></tr>';
		rank_html += '<div class="box box-primary">';	
        rank_html += '<div class="box box-primary">';
        for (i = 0; i < set_of_winners; i++) { 
		    rank_html += '<tr class="winner_rank_item"><td class="winner_rank">' + parseFloat(i+1) + '</td><td class="winner_rank_per"><input type="text" class="form-control" name="percen_' + i + '" value="' + rank_per + '"></td><td class="winner_rank_amt"><input type="text" class="form-control" name="rank_amt_' + i + '" value="' + rank_amt + '"></td></tr>';
		}
		rank_html += '</table>';
		rank_html += '</div>';
		$('#winner_section').html(rank_html);
    }*/
    function winnerRank()
    {
        var leage_size = $("#size").val();
        var set_of_winners = $("#set_of_winners").val();

        if ( ! set_of_winners ) {
            $('#winner_section').html('');
            $('#win_error').html('Please specify Set of Winners');
            return false;
        }
        if ( isNaN(parseInt(leage_size)) || isNaN(parseInt(set_of_winners))) {
            $('#winner_section').html('');
            $('#win_error').html('Set of winners or leage size can not be empty');
            return false;
        }
        var win_amt = parseFloat($("#win_amount").val());
        var rank_amt = (win_amt/set_of_winners);
        var rank_per = (rank_amt * 100) / win_amt;
        var rank_html = '';
        rank_html += '<div class="box-body table-responsive">';
        rank_html += '<table class="table table-hover table-bordered table-striped">';
        rank_html += '<tr><th class="text-center" colspan="5">Winners</th></tr>';
        rank_html += '<tr><th>Rank</th><th>Winner Ammount (%)</th><th>Amount</th></tr>';
        rank_html += '<div class="box box-primary">';   
        rank_html += '<div class="box box-primary">';
        for (i = 0; i < set_of_winners; i++) { 
            rank_html += '<tr class="winner_rank_item"><td class="winner_rank">' + parseFloat(i+1) + '</td><td class="winner_rank_per"><input type="text" class="form-control" name="percen_' + i + '" value="' + rank_per + '"></td><td class="winner_rank_amt"><input type="text" class="form-control" name="rank_amt_' + i + '" value="' + rank_amt + '"></td></tr>';
        }
        rank_html += '</table>';
        rank_html += '</div>';
        $('#winner_section').html(rank_html);
    }
    function winnerRankAmt () {
        var win_amt = parseFloat($("#win_amount").val());
        var per = $(this).val();
        var amt_input = $(this).parent().find('.rank_amt');
        var new_amt_val = (per / 100) * win_amt;
        $(amt_input).val(new_amt_val);
    }

    function winnerRankList() {
    	//var set_of_winners = $("#set_of_winners").val();
        var win_amt = parseFloat($("#win_amount").val());
        // var rank_amt = (win_amt/set_of_winners);
        // var rank_per = (rank_amt * 100) / win_amt;

        var per = $(this).val();
        var amt_td = $(this).parents('.winner_rank_item').find('.winner_rank_amt');
        var amt_val = $(amt_td).find('input');
        amt_val = $(amt_val).val();
        var new_amt_val = (per / 100) * win_amt;
        $(amt_td).find('input').val(new_amt_val);
    }

	jQuery("#winner_data_wraper").hide();
    function showFieldSet () {
        var set_of_winners = $("#set_of_winners").val();
        if (set_of_winners) {
            jQuery("#winner_data_wraper").show();
        } else {
            jQuery("#winner_data_wraper").hide();
        }
    }
    $(document).on("change, keyup", ".rank_percent", winnerRankAmt);

    $(document).on("change, keyup", "#set_of_winners", showFieldSet);
    $(document).on("click", "#calculate", winnerRank);

    $(document).on("change, keyup", ".winner_rank_per input", winnerRankList);

    $(document).on("change, keyup", "#win_amount", entryFees);
    $(document).on("change, keyup", "#size", entryFees);
    $(document).on("change, keyup", "#margin", entryFees);
});
