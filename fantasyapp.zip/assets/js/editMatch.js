/**
 * File : editSeries.js
 * 
 * This file contain the validation of edit series form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
  
  var editMatch = $("#editMatch");
  
  var validator = editMatch.validate({
    
    rules:{
      series : { required : true },
      admin_status : { required : true },
      team1_short : { required : true },
      team2_short : { required : true },
      match_type : { required : true },
      status : { required : true },
    },
    messages:{
      series : { required : "This field is required" },   
      admin_status : { required : "This field is required" },
       team1_short : { required : "This field is required" },   
      team2_short : { required : "This field is required" },
       match_type : { required : "This field is required" },   
      status : { required : "This field is required" },
    }
  });
});

  


   
    $(function () {
                $('#datetimepicker2').datetimepicker();
            });
    
      $(function () {
          $('#datetimepicker1').datetimepicker();
      });
  
      
        
        /** for select flag team 1**/
         $('#team_flag1').click(function(){
         var team1 = $('#team1').val();
          //var id = $('#po2_id').val();
           //alert(team1);
           //alert(points);
       
         $.ajax({
            type: 'post',
            url: '<?php echo base_url(); ?>Match/editOldMatch/' ,
            data: {team1:team1},
            success: function (data) {
            //alert('Points updated');
              
            },
             error : function(data) {
            // do something
            }

          });
      })
         /** for select flag team 1**/
         $('#team_flag2').click(function(){
         var team1 = $('#team1').val();
          //var id = $('#po2_id').val();
           //alert(team_name);
           //alert(points);
       
         $.ajax({
            type: 'post',
            url: '<?php echo base_url(); ?>Match/editMatch/' ,
            data: {team1:team1},
            success: function (data) {
            //alert('Points updated');
              
            },
             error : function(data) {
            // do something
            }

          });
      })
