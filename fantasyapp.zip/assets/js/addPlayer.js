/**
 * File : addFlag.js
 * 
 * This file contain the validation of add flag form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
	
	var newPlayer = $("#newPlayer");
	
	var validator = newPlayer.validate({
		
		rules:{
			name :{ required : true },
			p_id :{ required : true},
			credit :{ required : true },
			
		},
		messages:{
			PlayerName :{ required : "This field is required" },
			PlayerId :{ required : "This field is required" },
			PlayerCredit :{ required : "This field is required" }
			
		}
	});
});
