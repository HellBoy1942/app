/**
 * File : addNotification.js
 * 
 * This file contain the validation of add flag form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
	
	var notify_form = $("#notify_form");
	
	var validator = notify_form.validate({
		
		rules:{
			title :{ required : true },
			message :{ required : true },
			
		},
		messages:{
			title :{ required : "This field is required" },
			message :{ required : "This field is required" }
			
		}
	});
});
	
	
   
   