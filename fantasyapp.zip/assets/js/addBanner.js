/**
 * File : addBanner.js
 * 
 * This file contain the validation of add banner form
 * 
 * Using validation plugin : jquery.validate.js
 */
$(document).ready(function(){
	
	var newbanner = $("#newbanner");
	
	var validator = newbanner.validate({
		
		rules:{
			banner_type :{ required : true },
			banner_name :{ required : true },
			
		},
		messages:{
			banner_type :{ required : "This field is required" },
			banner_name :{ required : "This field is required" }
			
		}
	});
});
