

        function updateValue($id){

          //alert('hlo');

          var credit= $('#credit'+$id).val();

          var playing_role= $('#playing_role'+$id).val();

             $('#loading').html('<img src="../uploads/load.gif"> loading...');

           console.log(credit);

           console.log(playing_role);

          $.ajax({

              url: "players/editPlayer",

              data:{credit:credit,playing_role:playing_role,id:$id},

              type: "get",

              success: function(data){

                alert('Credits update successfully.');

              //document.getElementById("credit").reset();

             //document.getElementById("playing_role").reset();



              }

          });



       }

$(function(){

        $('#country').change(function(){

          //alert('hlo');

         var country= $('#country').val();

           $('#playerTbl').html('<img src="assets/images/load.gif"> loading...');

          //alert(country);

          //alert(playing_role);

          $.ajax({

              url: "players/playerListingAjax",

              data:{country:country},

              type: "get",

              success: function(data){

                //alert(data);

              //$('#playerTbl').empty();

              $('#playerTbl').html(data);

              //document.getElementById('playerTbl').innerHTML=data;



        }

          });



        });

      });