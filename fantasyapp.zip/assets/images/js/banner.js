/*$('#edit-banner').click(function(){
   //alert('hlo');
         var id = $('#b_id').val();
          //var id = $('#po2_id').val();
           alert(id);
           //alert(points);
           var baseurl = "<?php echo base_url(); ?>"
       
         $.ajax({
            type: 'post',
            url: baseurl+"Banner/editOldBanner" ,
            data: {id:id},
            success: function (data) {
            //alert('Points updated');
              
            },
             error : function(data) {
            // do something
            }

          });
      })*/


/* Updated new Item */
/*$(document).ready(function(){
    $("#submit-edit").click(function(e){


    e.preventDefault();

    alert('hlo');
   
    $.ajax({
        
        type:'POST',
        url: form_action,
        data:{name:name, banner_type:banner_type}
    }).done(function(data){


        
        $(".modal").modal('hide');
        toastr.success('Item Updated Successfully.', 'Success Alert', {timeOut: 5000});


    });


    });
});*/