/**
 * File : addFlag.js
 * 
 * This file contain the validation of add flag form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
	
	var newFlag = $("#newFlag");
	
	var validator = newFlag.validate({
		
		rules:{
			team_name :{ required : true },
			image_name :{ required : true },
			
		},
		messages:{
			Team Name :{ required : "This field is required" },
			Icon Name :{ required : "This field is required" }
			
		}
	});

	
	
   
   