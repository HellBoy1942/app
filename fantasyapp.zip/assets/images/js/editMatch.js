/**
 * File : editSeries.js
 * 
 * This file contain the validation of edit series form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
  
  var editMatch = $("#editMatch");
  
  var validator = editMatch.validate({
    
    rules:{
      series : { required : true },
      admin_status : { required : true },
      team1_short : { required : true },
      team2_short : { required : true },
      match_type : { required : true },
      status : { required : true },
    },
    messages:{
      series : { required : "This field is required" },   
      admin_status : { required : "This field is required" },
       team1_short : { required : "This field is required" },   
      team2_short : { required : "This field is required" },
       match_type : { required : "This field is required" },   
      status : { required : "This field is required" },
    }
  });
});

 


   
    $(function () {
                $('#datetimepicker2').datetimepicker();
            });
    
      $(function () {
          $('#datetimepicker1').datetimepicker();
      });
  
      
        
       