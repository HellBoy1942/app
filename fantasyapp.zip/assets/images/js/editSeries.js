/**
 * File : editSeries.js
 * 
 * This file contain the validation of edit series form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
	
	var editSeries = $("#editSeries");
	
	var validator = editSeries.validate({
		
		rules:{
			name :{ required : true },
			start_dt : { required : true },
			end_t : { required : true },
			status : { required : true },
		},
		messages:{
			name :{ required : "This field is required" },
			start_dt : { required : "This field is required"},
			end_dt : { required : "This field is required" },		
			status : { required : "This field is required" },
		}
	});
});
