/**
 * File : addSeries.js
 * 
 * This file contain the validation of add series form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){

	$("#start_dt").inputmask("dd-mm-yyyy", {"placeholder": "dd-mm-yyyy"});
	
	$("#end_dt").inputmask("dd-mm-yyyy", {"placeholder": "dd-mm-yyyy"});
	
	var newSeries = $("#newSeries");
	
	var validator = newSeries.validate({
		
		rules:{
			name :{ required : true },
			start_dt : { required : true },
			end_t : { required : true },
		},
		messages:{
			name :{ required : "This field is required" },
			start_dt : { required : "This field is required"},
			end_dt : { required : "This field is required" }
		}
	});
});
