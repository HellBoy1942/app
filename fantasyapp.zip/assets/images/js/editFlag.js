/**
 * File : addLeague.js
 * 
 * This file contain the validation of add league form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
	
	var editFlag = $("#editFlag");
	
	var validator = editFlag.validate({
		
		rules:{
			taem_name :{ required : true },
			
			
		},
		messages:{
			taem_name :{ required : "This field is required" },
			
			
		}
	});
});

function editFlag(x)
{   
    //alert(x);
    var id=x;
    var baseurl = "https://play11.in/adminpanel";
    $.ajax ({
        type : 'POST',
         url: baseurl+"Banner/editOldBanner" ,
        cache: false,
        data: {
            id: id 
        },
        async : false,
        success: function(result)
        {   
            
            
             
            
        },
        error: function()
        {                       
            //alert('Error while request..');
        }
    }); 
    $("#myModal1").modal("show");
}


	