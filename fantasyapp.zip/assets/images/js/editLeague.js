/**
 * File : addLeague.js
 * 
 * This file contain the validation of add league form
 * 
 * Using validation plugin : jquery.validate.js
 */

$(document).ready(function(){
	
	var editLeague = $("#editLeague");
	
	var validator = editLeague.validate({
		
		rules:{
			name :{ required : true },
			league_type :{ required : true },
			match :{ required : true },
			win_amount :{ required : true },
			size :{ required : true },
			margin : { required : true },
			entry_fees : { required : true },
		},
		messages:{
			name :{ required : "This field is required" },
			league_type :{ required : "This field is required" },
			match :{ required : "This field is required" },
			win_amount :{ required : "This field is required" },
			size :{ required : "This field is required" },
			margin : { required : "This field is required"},
			entry_fees : { required : "This field is required" }
		}
	});

	$("#league_type").change(function(){
		if ($(this).val() == 'PRACTICE') {
			$("#win_amount").attr('disabled', 'disabled');
			$("#size").attr('disabled', 'disabled');
			$("#margin").attr('disabled', 'disabled');
			$("#entry_fees").attr('disabled', 'disabled');
		} else {
			$("#win_amount").removeAttr('disabled');
			$("#size").removeAttr('disabled');
			$("#margin").removeAttr('disabled');
			$("#entry_fees").removeAttr('disabled');
		}

	});

    function entryFees()
    {
        var win_amt = parseFloat($("#win_amount").val());
        var size = parseFloat($("#size").val());
        var margin = parseFloat($("#margin").val());
        var total_earning = (win_amt + (win_amt * (margin / 100)));

        var entry_fees = (total_earning / size);
        var entry_fees = entry_fees.toFixed(2);
        $("#entry_fees").val(entry_fees);
    }
    function winnerRank()
    {
    	var leage_size = $("#size").val();
    	var set_of_winners = $("#set_of_winners").val();
    	// if (parseInt(leage_size) < parseInt(set_of_winners)) {
    	// 	$('#winner_section').html('');
    	// 	$('#win_error').html('Set of winners can not be more than leage size');
    	// 	return false;
    	// }
        var win_amt = parseFloat($("#win_amount").val());
        var rank_amt = (win_amt/set_of_winners);
        var rank_per = (rank_amt * 100) / win_amt;
        var rank_html = '';
        rank_html += '<div class="box-body table-responsive">';
        rank_html += '<table class="table table-hover table-bordered table-striped">';
        rank_html += '<tr><th class="text-center" colspan="5">Winners</th></tr>';
        rank_html += '<tr><th>Rank</th><th>Winner Ammount (%)</th><th>Amount</th></tr>';
		rank_html += '<div class="box box-primary">';	
        rank_html += '<div class="box box-primary">';
        for (i = 0; i < set_of_winners; i++) { 
		    rank_html += '<tr class="winner_rank_item"><td class="winner_rank">' + parseFloat(i+1) + '</td><td class="winner_rank_per"><input type="text" class="form-control" name="percen_' + i + '" value="' + rank_per + '"></td><td class="winner_rank_amt"><input type="text" class="form-control" name="rank_amt_' + i + '" value="' + rank_amt + '"></td></tr>';
		}
		rank_html += '</table>';
		rank_html += '</div>';
		$('#winner_section').html(rank_html);
    }

    function winnerRankList() {
    	//var set_of_winners = $("#set_of_winners").val();
        var win_amt = parseFloat($("#win_amount").val());
        // var rank_amt = (win_amt/set_of_winners);
        // var rank_per = (rank_amt * 100) / win_amt;

        var per = $(this).val();
        var amt_td = $(this).parents('.winner_rank_item').find('.winner_rank_amt');
        var amt_val = $(amt_td).find('input');
        amt_val = $(amt_val).val();
        var new_amt_val = (per / 100) * win_amt;
        $(amt_td).find('input').val(new_amt_val);
    }

	$(document).on("change, keyup", "#set_of_winners", winnerRank);

	$(document).on("change, keyup", ".winner_rank_per input", winnerRankList);
    
    $(document).on("change, keyup", "#win_amount", entryFees);
    $(document).on("change, keyup", "#size", entryFees);
    $(document).on("change, keyup", "#margin", entryFees);
});
