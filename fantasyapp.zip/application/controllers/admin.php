<?php 
error_reporting(0);

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Flag (FlagController)
 * Flag Class to manage all flag related operations.
 */
class ADMIN extends BaseController
{
    // helo world sadsad
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();  
        $this->load->model('admin_model');
        $this->load->model('user_model');
    }
    

    /**
     * This function is used to load the flag list
     */
    function adminListing()
    {

            
            $adminlist = $this->admin_model->admindetaillist();
            $data['adminlist'] = $adminlist;

            $this->global['pageTitle'] = 'Expect11 : Admin';            
            $this->loadViews("admin", $this->global, $data, NULL);
        
    }

    /**
     * This function is used to load the add new league form
     */
    function newUser()
    {
       
           
            $menulist=$this->admin_model->getMenu();
            $data['menulist']=$menulist;
             $this->global['pageTitle'] = 'Expect11 : Add New User';

            $this->loadViews("newUser", $this->global, $data,  NULL);
        
    }

   
    /**
     * This function is used to add new flag to the system
     */
    function addNewUser()
    {
        
        
            $this->load->library('form_validation');
             $this->form_validation->set_rules('fname','Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('password','Password','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('mobile','Mobile','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('role','Role','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('view','View','required|max_length[128]|xss_clean');
            if ($this->form_validation->run() == FALSE)
               {
                $this->newUser();
               } 
            else 
            {
                            $name=ucwords($this->input->post('fname'));
                            $email=$this->input->post('email');
                            $password=getHashedPassword($this->input->post('password'));
                            $mobile=$this->input->post('mobile');
                            $roleId=$this->input->post('role');
                            $view_string = implode(',', $_POST['view']);
                        $data =array(
                            
                            'name'=> $name,
                            'email'=> $email,
                            'password'=> $password,
                            'mobile'=>$mobile,
                            'roleId'=> $roleId,
                            'view'=>$view_string
                          


                        );
                       
            }
          
                        
                        $user_id = $this->user_model->addNewUser($data);
                        if($user_id > 0)
                        {
                            $this->session->set_flashdata('success', 'New User added successfully');
                        }
                        else
                        {
                            $this->session->set_flashdata('error', 'User addition failed');
                        }
                
                    redirect('adminListing');

            
           
        
    }
    private function set_upload_options()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']      = '500';
        $config['overwrite']     = FALSE;


        return $config;
    }

    /**
     * This function is used load league edit information
     * @param number $id : Optional : This is league id
     */
    function editOldUser($id = NULL)
    {
        
            if($id == null)
            {
                redirect('adminListing');
            }

            
            $menulist=$this->admin_model->getMenu();
            $data['menulist']=$menulist;
            $userInfo_edit = $this->admin_model->getuserInfo($id);
            $data['userInfo_edit'] = $userInfo_edit;
              $this->global['pageTitle'] = 'Expect11 : Edit User';
            
            $this->loadViews("editOldUser", $this->global, $data, NULL);
       
    }

    function editUser() {
       
            $this->load->library('form_validation');

            $id = $this->input->post('user_id');
            $this->form_validation->set_rules('fname', 'Name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
            $this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|xss_clean');
            
            if ($this->form_validation->run() == FALSE) {
                $this->editOldUser($id);
            } else {

                $name = $this->input->post('fname');
                $email = $this->input->post('email');
                $password = getHashedPassword($this->input->post('password'));
                $mobile = $this->input->post('mobile');
                 $view = $this->input->post('view');
                  $roleId = $this->input->post('role');
                   $view_string1 = implode(',', $_POST['view']);
                
                

                $data = array(
                    'name' => $name,
                    'email' => $email,
                    'password' => $password,
                    'mobile' => $mobile,
                    'view' => $view_string1,
                    'roleId'=> $roleId,
                    
                );
            
              
                $result = $this->admin_model->editUser($data, $id);

                if ($result > 0) {
                    $this->session->set_flashdata('success', 'User updated successfully');
                } else {
                    $this->session->set_flashdata('error', 'User updation failed');
                }

                redirect('editOldUser');
            }
       
    }


    function deleteOldUser($id = NULL) {
     
            
            if($id == NULL)
            {
                redirect('adminListing');
            }
            
          
            $id = $this->admin_model->deleteUser($id);

            if ($id) {
                $this->session->set_flashdata('success', 'User deleted successfully');
            } else {
                $this->session->set_flashdata('error', 'User deletion failed');
            }
            redirect('adminListing');
       
    }
    
   
  }  
?>