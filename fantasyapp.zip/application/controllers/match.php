<?php

error_reporting(0);

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Match (MatchController)
 * Match Class to manage all match related operations.
 */
class Match extends BaseController {
    
    private $headers;
    private $subject;
    private $message;
    private $_url;
    private $points1;

    /**
     * This is default constructor of the class
     */
    public function __construct() {
        parent::__construct();
        if (!in_array($this->uri->segment(1), array('storePoints', 'liveMatchCron'))) {
            $this->isLoggedIn();
        }
        $this->_url = $this->config->item('notify_url');
        $from = $this->config->item('email');
        $this->points1 = $this->config->item('point_cal');
        $this->headers = 'MIME-Version: 1.0' . "\r\n";
        $this->headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $this->headers .= 'From:' . $from;

      
    }

    /**
     * This function is used to load the player list
     */
    function matchListing($type) {

       
        $this->load->model('match_model');
        $this->load->model('series_model');
        $this->load->model('league_model');
        // $abk=file_get_contents(base_url().'liveMatchCron');

        $searchText = $this->input->post('searchText');
        $data['searchText'] = $searchText;

        $this->load->library('pagination');

        $count = $this->match_model->matchsListingCount($searchText, $type);

        if ($type == 'upcomming') {
            $returns = $this->paginationCompress("upcommingMatches/", $count, 300);
        }
        if ($type == 'live') {
            $returns = $this->paginationCompress("liveMatches/", $count, 300);
        }
        if ($type == 'result') {
            $returns = $this->paginationCompress("resultMatches/", $count, 300);
            //print_r($result);die;
        }
        if ($type == 'cancel') {
            $returns = $this->paginationCompress("cancelMatches/", $count, 300);
            //print_r($returns);
        }
        $data['type'] = $type;
        $match_records = $this->match_model->matchListing($searchText, $type, $returns["page"], $returns["segment"]);
        
        $series_names = array();
        $leage_list_count = array();
        $join_team_count = array();
        foreach ($match_records as $record) {
            $series_names [$record->series] = $this->series_model->getSeriesDesc($record->series);

            $leage_list = $this->league_model->getLegueByMatch($record->match_id);
            //print_r($leage_list);
            $leage_list_count[$record->id] = count($leage_list);


            $this->load->model('joined_league_model');
            $teams_list = $this->joined_league_model->getByLeague($record->match_id);
            $join_team_count[$record->id] = count($teams_list);
        }

        $data['series_names'] = $series_names;
        $data['matchRecords'] = $match_records;
        $data['leage_list_count'] = $leage_list_count;
        $data['join_team_count'] = $join_team_count;

        $this->global['pageTitle'] = 'expect11 : Match Listing';
        $this->loadViews("match", $this->global, $data, NULL);
        /* } */
    }

    /** this function is used for get all match by series* */
    function getallMatchesBySeries($id) {
        $this->load->model('match_model');
        $matchInfo = $this->match_model->getMatchInfoBySeries($id);
        $this->loadViews("fetchNewMatches");
    }

    /**
     * This function is used to fetchNewMatches
     */
    function newMatchCron() {

        $this->config->load('config');

        $data['match_api_key'] = $this->config->item('match_api_key');

        $data = array(
            'apikey' => $data['match_api_key']
        );

        $data_string = json_encode($data);

        $curl = curl_init('http://cricapi.com/api/matches');

        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string))
        );

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);  // Make it so the data coming back is put into a string
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);  // Insert the data
        // Send the request
        $result = curl_exec($curl);

        // Free up the resources $curl is using
        curl_close($curl);
        $this->load->model('league_model');
        $alldefaultleague = $this->league_model->getdefaultLeague();
        $data['leagueRecords'] = $alldefaultleague;
        $matches = json_decode($result);
        $match_count = count($matches->matches);
        $ids = array();

        $allMatches = $matches->matches;
        $data['matchRecords'] = $allMatches;
        $this->global['pageTitle'] = 'expect11 : All API Matches';

        $this->loadViews("allMatches", $this->global, $data, NULL);
       
    }

    /**
     * This function is used to update live matches
     */
    function liveMatchCron() {
        date_default_timezone_set('Asia/Kolkata');

        $this->load->model('match_model');
        $this->load->model('league_model');
        $this->load->model('notification_model');
        $match_records = $this->match_model->getAllMatch();
        $live_matches = array();
        $cancel_desc = '';
        //print 'Match ID --- Current Time --- Match Start Time --- Match Start Time - 30 mins --- ( Status ) <br/>';
        foreach ($match_records as $i => $match) {
            $live_start_date = date('Y-m-d H:i:s', strtotime('-1 minutes', strtotime($match->start_dt)));
            $match_start_dt = date('Y-m-d H:i:s', strtotime($match->start_dt));
            $match_end_dt = date('Y-m-d H:i:s', strtotime($match->end_dt));
            $current_time = date('Y-m-d H:i:s', time());
            $live_sttus = $match->status;
            if ((($match->matchStarted == 1) or ( strtotime($current_time) > strtotime($live_start_date)))
                    and $match->admin_status == 'APPROVED' and $match->status == 'UPCOMING') {
                $live_sttus = 'LIVE';
                $live_matches[] = $match->match_id;
                $match_id = $match->match_id;
               
                // Auto Contest Cancelled
                $contest = $this->league_model->leagueInfo($match_id);
                foreach ($contest as $value) {
                    $league_id = $value['id'];
                    $contest_size = $value['contest_size'];
                    $is_cancelled = $value['cancel_contest'];
                    if (!empty($league_id)) {
                        $res = $this->league_model->getCountOfLeague($league_id);
                        $userid = $res[0]['user_id'];
                        $res_1 = count($res);
                        if (!empty($userid)) {
                            $match_status = 'The Match will Started Soon.';
                            $postData = '';
                            $params = array(
                                'title' => 'Match Started Soon',
                                'msg' => $match_status,
                                'image' => null,
                                'user_id' => $userid
                            );

                            $postData = http_build_query($params);
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, $this->_url);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                            curl_setopt($ch, CURLOPT_HEADER, false);
                            curl_setopt($ch, CURLOPT_POST, count($postData));
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                            $output = curl_exec($ch);
                            $output_data [] = json_decode($output);
                            curl_close($ch);

                            $params = array(
                                'title' => 'Match Started Soon',
                                'message' => $match_status,
                                'user_id' => $userid
                            );
                            $nid = $this->notification_model->addNewNotification($params);
                        }
                        // if ($res_1 < $contest_size && $is_cancelled == 1) {
                        if ($res_1 < $contest_size && $is_cancelled == 1) {
                            $data = array(
                                'status' => 'CANCEL',
                                'cancel_desc' => 'Auto Cancelled because League not full'
                            );
                            $res1 = $this->league_model->updateStatus($data, $league_id);
                            $this->refundAmount($league_id, $match_id);
                        }
                    }
                }
            }
            if ($match->matchStarted == 1 or strtotime($current_time) > strtotime($match_end_dt) and
                    $match->admin_status == 'APPROVED' and $match->status == 'LIVE') {
                $live_sttus = 'FINISH';

                $match_id = $match->match_id;
                $this->load->model('league_model');
                $contest = $this->league_model->leagueInfo($match_id);

                foreach ($contest as $value) {
                    $league_id = $value->id;
                    $this->load->model('league_model');
                    if (!empty($league_id)) {
                        $res = $this->league_model->getCountOfLeague($league_id);
                        $userid = $res[0]->user_id;
                        if (!empty($userId)) {
                            $match_status = 'The Match was Finished';
                            $postData = '';
                            $params = array(
                                'title' => 'Match Finished',
                                'msg' => $match_status,
                                'image' => null,
                                'user_id' => $userid
                            );

                            $postData = http_build_query($params);

                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, $this->_url);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                            curl_setopt($ch, CURLOPT_HEADER, false);
                            curl_setopt($ch, CURLOPT_POST, count($postData));
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                            $output = curl_exec($ch);
                            $output_data [] = json_decode($output);
                            curl_close($ch);

                            $params = array(
                                'title' => 'Match Finished Soon',
                                'message' => $match_status,
                                'user_id' => $userid
                            );
                            $this->load->model('notification_model');
                            $nid = $this->notification_model->addNewNotification($params);
                        }
                    }
                }
            }
            /*if ($match->admin_status == 'ABANDONED' && $live_sttus == 'ABANDONED') {
                $live_sttus = 'ABANDONED';
                $live_matches[] = $match->match_id;
                $match_id = $match->match_id;
                // Auto Contest Cancelled
                $contest = $this->league_model->leagueInfo($match_id);
                foreach ($contest as $value) {
                    $league_id = $value['id'];
                    $contest_size = $value['contest_size'];
                    $is_cancelled = $value['cancel_contest'];
                    $league_staus = $value['status'];
                    $cancel_desc = 'Match is abandoned.';
                    if (!empty($league_id) && $league_staus == 'ACTIVE') {
                        $res = $this->league_model->getCountOfLeague($league_id);
                        $userid = $res[0]['user_id'];
                        //print_r($userid);
                        $res_1 = count($res);
                        if (!empty($userid)) {
                            $match_status = 'The Match will be abandoned.';
                            $postData = '';
                            $params = array(
                                'title' => 'Match Abadoned',
                                'msg' => $match_status,
                                'image' => null,
                                'user_id' => $userid
                            );

                            $postData = http_build_query($params);
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, $this->_url);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                            curl_setopt($ch, CURLOPT_HEADER, false);
                            curl_setopt($ch, CURLOPT_POST, count($postData));
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                            $output = curl_exec($ch);
                            $output_data [] = json_decode($output);
                            curl_close($ch);

                            $params = array(
                                'title' => 'Match Abaddoned',
                                'message' => $match_status,
                                'user_id' => $userid
                            );
                            $nid = $this->notification_model->addNewNotification($params);
                        }
                        $data = array(
                            'status' => 'CANCEL',
                            'cancel_desc' => 'Contest is cancel because Match is abandoned'
                        );
                        $res1 = $this->league_model->updateStatus($data, $league_id);
                        $this->refundAmount($league_id, $match);
                    }
                }
            }*/

            $data = array(
                'status' => $live_sttus,
                'cancel_desc'=> $cancel_desc
            );
            $result = $this->match_model->editmatch($data, $match->match_id);
        }
    }

 function playerInfo($match_id){

                
               
               //$squads = array();
            
                $this->config->load('config');

                $data['match_api_key'] = $this->config->item('match_api_key');
                $data = array(
                    'apikey' => $data['match_api_key'],
                    'unique_id' => $match_id
                );

                $data_string = json_encode($data);

                $curl = curl_init('http://cricapi.com/api/fantasySquad');

                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data_string))
                );

                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);  // Make it so the data coming back is put into a string
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);  // Insert the data
                // Send the request
                $result = curl_exec($curl);

                // Free up the resources $curl is using
                curl_close($curl);


                $squads = json_decode($result);

                $squads = $squads->squad;

                 $data['squads'] = $squads;
                
                $this->loadViews("playerInfo", $this->global, $data, NULL);

    }
    
      function getmicrotime() {
        list($usec, $sec) = explode(" ", microtime());
        return ((float) $usec + (float) $sec);
    }
    
    function refundAmount($league_id, $match_id) {
        $this->load->model('teams_model');
        $this->load->model('user_model');
        $this->load->model('match_model');
        $this->load->model('transaction_model');
        $this->load->model('joined_league_model');
        $this->load->model('notification_model');
        $this->load->model('league_model');

        // Match Informtion
        $matchInfo = $this->match_model->getMatch($match_id);
        $team1 = $matchInfo[0]->team1;
        $team2 = $matchInfo[0]->team2;
        $match_name = $team1 . ' vs ' . $team2;
        // League Information
        $league_info = $this->league_model->getLegueInfo($league_id);
        $entry_fees = $league_info[0]->entry_fees;
        $league_status = $league_info[0]->status;
        $refund_status = $league_info[0]->refund;

        // User Joined List regarding this league 
        $contestJoinedUserLIst = $this->league_model->getContestJoinedUserList($league_id);
        // Transsaction id
        
        if (!empty($contestJoinedUserLIst) AND $league_status == 'CANCEL' AND $refund_status == 0) {
            foreach ($contestJoinedUserLIst as $joinedList) {
                $txn_id = round(microtime(true) * 1000);
                
                $used_cash_bonus = $joinedList->used_cash_bonus;
                $used_referral_binus = $joinedList->used_referral_binus;
                $used_add_cash = $joinedList->used_add_cash;
                $used_winning_amount = $joinedList->used_winning_amount;
                // print_r($joinedList);

                $userid = $joinedList->user_id;
                
                $trn_data = array();
                $trn_ids = array();

                $user_info = $this->user_model->getUser($userid);

                $refund_msg = "Your entry fee has been refunded for the Rs." . "$entry_fees " . "contest. The contest you joined had to be cancelled as all the slots were not filled or match is Abandoned.";

                // $refund_msg = 'Your Entry Fees  Rs. ' . $entry_fees . ' has been refunded to your Wallet';
                // $postData = '';
                // $params = array(
                //     'title' => 'Your Entry Fees refund successfully',
                //     'msg' => $refund_msg,
                //     'image' => null,
                //     'user_id' => '1'
                // );

                // $postData = http_build_query($params);
                // $ch = curl_init();
                // curl_setopt($ch, CURLOPT_URL, $this->_url);
                // curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                // curl_setopt($ch, CURLOPT_HEADER, false);
                // curl_setopt($ch, CURLOPT_POST, count($postData));
                // curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                // $output = curl_exec($ch);
                // $output_data [] = json_decode($output);
                // curl_close($ch);

                // $params = array(
                //     'title' => 'Your Entry Fees refund successfully',
                //     'message' => $refund_msg,
                //     'user_id' => '1'
                // );
                // $nid = $this->notification_model->addNewNotification($params);

                $name = $user_info[0]->name;
                $to = $user_info[0]->email;
                $teams_bw = $match_name;
                $date = date("d-m-Y");
                $this->subject = "Refund Amount confirmation!";
               

                $email_data = array(
                    'name' => $name,
                    'msg' => $refund_msg,
                );

                $message = $this->load->view('emailView', $email_data, TRUE);
                $this->message = $this->message . $this->message_footer;
                $this->load->library('email');
                $config['protocol']    = 'smtp';
                $config['smtp_host']    = 'mail.demohost.com';
                $config['smtp_port']    = '465';
                $config['smtp_timeout'] = '7';
                $config['smtp_user']    = 'fantacyleague@demohost.com';
                $config['smtp_pass']    = 'xsrry2[23$7';
                $config['charset']    = 'utf-8';
                $config['newline']    = "\r\n";
                $config['mailtype'] = 'text'; // or html
                $config['validation'] = TRUE; // bool whether to validate email or not      

                $this->email->initialize($config);

                $this->email->from('fantacyleague@demohost.com', 'FantacyLeague Admin Panel');
                $this->email->to($to); 

                $this->email->subject($this->subject);
                $this->email->message($message);  

                $this->email->send();

                // echo $this->email->print_debugger();
                // mail($to, $this->subject, $message, $this->headers);

                $wallet_amount = $user_info[0]->cash_bonus + $user_info[0]->referral_bonus + $user_info[0]->add_cash + $user_info[0]->cash_winning;
                
                $trn_data = array(
                    'txn_id' => $txn_id,
                    'user_id' => $userid,
                    'txn_amt' => $entry_fees,
                    'txn_status' => 'SUCCESS',
                    'txn_type' => 'TEST_REFUND_AMT',
                    'cash_bonus'=>$user_info[0]->cash_bonus,
                    'referral_bonus'=>$user_info[0]->referral_bonus,
                    'add_cash'=>$user_info[0]->add_cash,
                    'winning_amount'=>$user_info[0]->cash_winning,
                    'wallet_amount'=>$wallet_amount,
                    'txn_msg' => $refund_msg
                );

                $user_data = array(
                    'cash_bonus' => $user_info[0]->cash_bonus + $used_cash_bonus,
                    'referral_bonus' => $user_info[0]->referral_bonus + $used_referral_binus,
                    'add_cash' => $user_info[0]->add_cash + $used_add_cash,
                    'cash_winning' => $user_info[0]->cash_winning + $used_winning_amount
                );

            $trn_ids[] = $this->transaction_model->addTrans($trn_data);
            $ud = $this->user_model->editAppUser($user_data, $userid);
            }
            if (count($trn_ids) > 0) {
                $this->load->model('league_model');
                $league_data = array(
                    'refund' => TRUE
                );
                
                $this->league_model->editLeague($league_data, $league_id);
            }
        }
    }

    function getPoints() {

        $this->load->model('match_model');
        $live_matches = $this->match_model->matchListing('', 'live', 999, 0);
        
        $summary = array();
        $match_summary = array();
        if (!empty($live_matches)) {

            foreach ($live_matches as $match) {
                
                $this->config->load('config');
                


                $data['match_api_key'] = $this->config->item('match_api_ley');

                $data = array(
                    'unique_id' => $match->match_id,
                    'apikey' => "4B5LoWgVmIdM22wTgarwgfk03DL2"
                );


                $data_string = json_encode($data);

                $curl = curl_init('http://cricapi.com/api/fantasySummary/');

                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data_string))
                );

                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);  // Make it so the data coming back is put into a string
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);  // Insert the data
                // Send the request
                $result = curl_exec($curl);

                // Free up the resources $curl is using
                curl_close($curl);


                $match_summary = json_decode($result);
                $summary[$match->match_id] = $match_summary->data;
                $summary[$match->match_id]->match_type = $match->match_type;
            }
        }

        if (!empty($summary)) {
            foreach ($summary as $id => $data) {
                $batting1 = (!empty($data->batting[0])) ? $data->batting[0]->scores : array();
                $batting2 = (!empty($data->batting[1])) ? $data->batting[1]->scores : array();
                $batting3 = (!empty($data->batting[2])) ? $data->batting[2]->scores : array();
                $batting4 = (!empty($data->batting[3])) ? $data->batting[3]->scores : array();
                $batting = array_merge($batting1, $batting2, $batting3, $batting4);



                $bowling1 = (!empty($data->bowling[0])) ? $data->bowling[0]->scores : array();
                $bowling2 = (!empty($data->bowling[1])) ? $data->bowling[1]->scores : array();
                $bowling3 = (!empty($data->bowling[2])) ? $data->bowling[2]->scores : array();
                $bowling4 = (!empty($data->bowling[3])) ? $data->bowling[3]->scores : array();
                $bowling = array_merge($bowling1, $bowling2, $bowling3, $bowling4);


                $fielding1 = (!empty($data->fielding[0])) ? $data->fielding[0]->scores : array();
                $fielding2 = (!empty($data->fielding[1])) ? $data->fielding[1]->scores : array();
                $fielding3 = (!empty($data->fielding[2])) ? $data->fielding[2]->scores : array();
                $fielding4 = (!empty($data->fielding[3])) ? $data->fielding[3]->scores : array();
                $fielding = array_merge($fielding1, $fielding2, $fielding3, $fielding4);

                $team1 = (!empty($data->team[0])) ? $data->team[0]->players : array();
                $team2 = (!empty($data->team[1])) ? $data->team[1]->players : array();
                $players = array_merge($team1, $team2);


                $match_type = $data->match_type;

                if ($match_type == 'T20' || $match_type == 'Twenty20') {

                    // Batings
                    $for_every_run = 1; // for every run scored 
                    $for_every_boundry_hit = 0.5; // Bundry Bonus
                    $for_every_six_hit = 1; // Six Bonus
                    $half_century = 4; // Half Century Bonus
                    $century = 8; // Century Bonus
                    $dismiss_for_duck = -2; // dismiss for duck
                    // Bowling
                    $wicket_wo_ro = 15; //wicket excluding run out
                    $four_wicket = 4; // 4 Wicket haul Bounus
                    $above_4_wicket = 8; // above 4 wicket
                    $maiden_over = 4; // Maiden Over
                    //Fielding
                    $catch_point = 4; //catch
                    $run_out_point = 6; // Stumping / runout
                    // Others

                    $in_starting_11 = 2; // In Starting 11 Players
                    //Economy Rate
                    $over_condition = 2; // (Min 2 Overs To Be Bowled)
                    $below_4_run_over = 3; // Below 4 runs per over
                    $less_then_5_run_over = 2; // Between 4-4.99 runs per over
                    $less_then_5_6_run_over = 1; // Between 4-4.99 runs per over

                    $bw_9_10_per_over = -1;
                    $bw_10_11_per_over = -2;
                    $above_11_per_over = -3;


                    // Strike run rates
                    $strike_ball = 10; // Min 10 Balls To Be Played
                    $strike_rate_less_50 = -3; // Below 50 runs per 100 balls
                    $strike_rate_less_50_60 = -2; //Between 50-59.9 runs per 100 balls
                    $strike_rate_less_60_70 = -1; //Between 60-70 runs per 100 balls
                } else
                if ($match_type == 'ODI') {

                    // Batings
                    $for_every_run = 1; // for every run scored 
                    $for_every_boundry_hit = 0.5; // Bundry Bonus
                    $for_every_six_hit = 1; // Six Bonus
                    $half_century = 2; // Half Century Bonus
                    $century = 4; // Century Bonus
                    $dismiss_for_duck = -3; // dismiss for duck
                    // Bowling
                    $wicket_wo_ro = 18; //wicket excluding run out
                    $four_wicket = 2; // 4 Wicket haul Bounus
                    $above_4_wicket = 4; // above 4 wicket
                    $maiden_over = 2; // Maiden Over
                    //Fielding
                    $catch_point = 4; //catch
                    $run_out_point = 6; // Stumping / runout
                    // Others
                    $in_starting_11 = 2; // In Starting 11 Players
                    //Economy Rate
                    $over_condition = 5; // (Min 5 Overs To Be Bowled)

                    $below_4_run_over = 3; // Below 4 runs per over
                    $less_then_5_run_over = 2; // Between 4-4.99 runs per over
                    $less_then_5_6_run_over = 1; // Between 4-4.99 runs per over

                    $bw_9_10_per_over = -1;
                    $bw_10_11_per_over = -2;
                    $above_11_per_over = -3;

                    // Strike run rates
                    $strike_ball = 20; // Min 20 Balls To Be Played
                    $strike_rate_less_40 = -3;
                    $strike_rate_less_40_50 = -2;
                    $strike_rate_less_50_60 = -1;
                } else {

                    // Batings
                    $for_every_run = 1; // for every run scored 
                    $for_every_boundry_hit = 0.5; // Bundry Bonus
                    $for_every_six_hit = 1; // Six Bonus
                    $half_century = 2; // Half Century Bonus
                    $century = 4; // Century Bonus
                    $dismiss_for_duck = -4; // dismiss for duck
                    // Bowling
                    $wicket_wo_ro = 12; //wicket excluding run out
                    $four_wicket = 2; // 4 Wicket haul Bounus
                    $above_4_wicket = 4; // above 4 wicket
                    $maiden_over = 0; // Maiden Over
                    //Fielding
                    $catch_point = 4; //catch
                    $run_out_point = 6; // Stumping / runout
                    // Others

                    $in_starting_11 = 2; // In Starting 11 Players
                    //Economy Rate

                    $over_condition = 0; // Min Over Required
                    $below_4_run_over = 0; // Below 4 runs per over
                    $less_then_5_run_over = 0; // Between 4-4.99 runs per over
                    $less_then_5_6_run_over = 0; // Between 4-4.99 runs per over

                    $bw_9_10_per_over = 0;
                    $bw_10_11_per_over = 0;
                    $above_11_per_over = 0;

                    $strike_ball = 0; // Min 10 Balls To Be Played
                    // Strike run rates
                    $strike_rate_less_50 = 0;
                    $strike_rate_less_50_60 = 0;
                    $strike_rate_less_60_70 = 0;

                    $strike_rate_less_40 = 0;
                    $strike_rate_less_40_50 = 0;
                    $strike_rate_less_50_60 = 0;
                }

                foreach ($players as $i => $p_data) {
                    $pid = $p_data->pid;
                    $point = $in_starting_11;

                    // each run points
                    foreach ($batting as $b_i => $b_v) {
                        if ($b_v->pid == $pid) {
                            $point += ($b_v->R * $for_every_run);

                            // Player out on zero run
                            if ($b_v->R == 0 && $b_v->dismissal != 'not out') {
                                $point += $dismiss_for_duck;
                            }

                            //boundary
                            $tempb_v = (array) $b_v;
                            if ($tempb_v['4s'] > 0) {
                                $point += ($tempb_v['4s'] * $for_every_boundry_hit);
                            }
                            //six
                            if ($tempb_v['6s'] > 0) {
                                $point += ($tempb_v['6s'] * $for_every_six_hit);
                            }

                            // Half Century
                            if ($b_v->R >= 50 && $b_v->R < 100) {
                                $point += $half_century;
                            }

                            // Centuary
                            if ($b_v->R >= 100) {
                                $point += $century;
                            }

                            // For Strike Run Rate condition
                            if ($b_v->B >= $strike_ball) {
                                // if less then 50 Sr

                                if ($match_type == 'T20') {
                                    if ($b_v->SR <= 50) {
                                        $point += $strike_rate_less_50;
                                    } else
                                    if ($b_v->SR > 50 && $b_v->SR < 60) {
                                        $point += $strike_rate_less_50_60;
                                    } else
                                    if ($b_v->SR >= 60 && $b_v->SR <= 70) {
                                        $point += $strike_rate_less_60_70;
                                    }
                               //     else
                               //                                    if ($b_v->SR >= 110 && $b_v->SR <= 140) {
                               //                                        $point += $strike_rate_110_to_140;
                               //                                    } else
                               //                                    if ($b_v->SR > 140 && $b_v->SR <= 180) {
                                //                                        $point += $strike_rate_140_to_180;
                                //                                    } else
                                //                                    if ($b_v->SR > 180) {
                                //                                        $point += $strike_rate_above_180;
                                //                                    }
                                } else {
                                    if ($b_v->SR <= 40) {
                                        $point += $strike_rate_less_40;
                                    } else
                                    if ($b_v->SR > 40 && $b_v->SR < 50) {
                                        $point += $strike_rate_less_40_50;
                                    } else
                                    if ($b_v->SR >= 50 && $b_v->SR <= 60) {
                                        $point += $strike_rate_less_50_60;
                                    }
                    //                                    else
                    //                                    if ($b_v->SR >= 110 && $b_v->SR <= 140) {
                    //                                        $point += $strike_rate_110_to_140;
                    //                                    } else
                    //                                    if ($b_v->SR > 140 && $b_v->SR <= 180) {
                    //                                        $point += $strike_rate_140_to_180;
                    //                                    } else
                    //                                    if ($b_v->SR > 180) {
                    //                                        $point += $strike_rate_above_180;
                    //                                    }
                                }
                            }
                        }
                    }

                    // wicket without run out points
                    foreach ($bowling as $bw_i => $bw_v) {
                        if ($bw_v->pid == $pid) {
                            $point += ($bw_v->W * $wicket_wo_ro);
                            $point += ($bw_v->M * $maiden_over);
                            if ($bw_v->W == 4) {
                                $point += $four_wicket;
                            }
                            if ($bw_v->W >= 5) {
                                $point += $above_4_wicket;
                            }

                            if ($bw_v->O >= $over_condition) {
                                if ($bw_v->Econ < 4) {
                                    $point += $below_4_run_over;
                                }
                                if ($bw_v->Econ >= 4 && $bw_v->Econ < 5) {
                                    $point += $less_then_5_run_over;
                                }

                                if ($bw_v->Econ >= 5 && $bw_v->Econ <= 6) {
                                    $point += $less_then_5_6_run_over;
                                }
                                if ($bw_v->Econ >= 9 && $bw_v->Econ <= 10) {
                                    $point += $bw_9_10_per_over;
                                }
                                if ($bw_v->Econ > 10 && $bw_v->Econ <= 11) {
                                    $point += $bw_10_11_per_over;
                                }
                                if ($bw_v->Econ > 11) {
                                    $point += $above_11_per_over;
                                }
                            }
                        }
                    }

                    // catch points
                    foreach ($fielding as $f_i => $f_v) {
                        if ($f_v->pid == $pid) {
                            $point += ($f_v->catch * $catch_point);
                        }
                    }

            //                    // stumped / runout points
                    foreach ($fielding as $f_i => $f_v) {
                        if ($f_v->pid == $pid) {
                            $point += (($f_v->stumped + $f_v->runout) * $run_out_point);
                        }
                    }

                    $pl_data = array(
                        'points' => $point
                    );

                    $pc_data = array(
                        'points' => $point
                    );
                    echo $pid."<hr>";
                    print_r($pl_data);


                    $this->load->model('players_model');
                    $result = $this->players_model->editPlayer($pl_data, $pid);

                    // store points to points calculation table
                    $pc_result = $this->players_model->storePointsCalc($pc_data, $id, $pid);
                }
            }

            $this->calculatePoints();
        }
    }

    function calculatePoints() {
      
    //   $points1 = "https://expect11.com/api/calculate_points_ranks.php";
        $postData = '';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->points1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, count($postData));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

        $output = curl_exec($ch);
        $output_data [] = json_decode($output);
        curl_close($ch);
    }
    function calculatePoints2($v1='') {
      
    //   $points1 = "https://expect11.com/api/calculate_points_ranks.php";
        $postData = 'mid='.$v1;
        $abc=base_url()."mobile_api/api/calculate_points_ranks2.php";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->points1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, count($postData));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

        $output = curl_exec($ch);
        $output_data [] = json_decode($output);
        curl_close($ch);
        print_r($output_data);
    }

    /**
     * This function is used add single match to the db
     */
    function addMatch() {
        $player_img_url = array();
        $player_playingRole = array();

        if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {
            $this->load->model('match_model');
            $id = $this->input->post('match_id');

            $match_type = $this->input->post('match_type');
            $start_date = date('Y-m-d H:i:s', strtotime('+5 hour +30 minutes', strtotime($this->input->post('start_dt'))));

            $end_date = '';
            if ($match_type == 'T20' || $match_type == 'Twenty20') {
                $end_date = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($start_date)));
                
            } elseif ($match_type == 'ODI' || $match_type == 'First-class') {
                $end_date = date('Y-m-d H:i:s', strtotime('+9 hour ', strtotime($start_date)));
                
            } else {
                $end_date = date('Y-m-d H:i:s', strtotime('+5 days', strtotime($start_date)));
               
            }


            $match_data = array(
                'match_id' => $id,
                'start_dt' => $start_date,
                'end_dt' => $end_date,
                'match_type' => $this->input->post('match_type'),
                'team1' => $this->input->post('team1'),
                'team2' => $this->input->post('team2'),
                'squad' => $this->input->post('squad'),
                'matchStarted' => $this->input->post('matchStarted')
            );

            $matchInfo = $this->match_model->getMatchInfo($id);

            if (empty($matchInfo)) {
                $mid = $this->match_model->storeNewmatches($match_data);
                if ($mid > 0) {
                    $this->session->set_flashdata('success', 'Match added successfully');
                    $data['match_id'] = $this->session->set_flashdata('match_id', $id);
                   
                    $this->loadViews("allMatches", $data);
                } else {
                    $this->session->set_flashdata('error', 'Match addition failed');
                   ;
                }
            } else {
                $this->session->set_flashdata('error', 'This Match was already added!');
                redirect('fetchNewMatches');
            }

            $squads = array();
            if ($match_data['squad']) {
                $this->config->load('config');

                $data['match_api_key'] = $this->config->item('match_api_key');
                $data = array(
                    'apikey' => $data['match_api_key'],
                    'unique_id' => $match_data['match_id']
                );

                $data_string = json_encode($data);

                $curl = curl_init('http://cricapi.com/api/fantasySquad');

                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data_string))
                );

                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);  // Make it so the data coming back is put into a string
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);  // Insert the data
                // Send the request
                $result = curl_exec($curl);

                // Free up the resources $curl is using
                curl_close($curl);


                $squads = json_decode($result);
                $squads = $squads->squad;

                $this->load->model('squad_model');
                $this->load->model('players_model');

                foreach ($squads as $i => $squad) {
                    $players[] = json_encode($squad->players);
                    $teams[] = $squad->name;
                }
                
                if($teams[0] === 'TBA'){
                    $teams[0] = $match_data['team1'];
                }
                if($teams[1] === 'TBA'){
                    $teams[1] = $match_data['team2'];;
                }

                $squad_info = $this->squad_model->getSquadByMatch($match_data['match_id']);

                $squad_data = array(
                    "match_id" => $match_data['match_id'],
                    "team1" => $teams[0],
                    "team2" => $teams[1],
                    "players1" => $players[0],
                    "players2" => $players[1]
                );

                if (empty($squad_info)) {
                    $sid = $this->squad_model->addSquad($squad_data);
                }

                $players1 = json_decode($players[0]);
                $players2 = json_decode($players[1]);

                foreach ($players1 as $i => $player) {

                    $player_role = "BOWL";
                    $this->config->load('config');

                    $data['match_api_key'] = $this->config->item('match_api_key');
                    // Fetch Player statistics like imageURL and playingRole
                    $data = array(
                        'apikey' => $data['match_api_key'],
                        'pid' => $player->pid
                    );

                    $data_string = json_encode($data);
                    $curl = curl_init('http://cricapi.com/api/playerStats');

                    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

                    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/json',
                        'Content-Length: ' . strlen($data_string))
                    );

                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);  // Insert the data
                    // Send the request
                    $result = curl_exec($curl);

                    // Free up the resources $curl is using
                    curl_close($curl);

                    $player_stats = json_decode($result);
                    $player_img_url = $player_stats->imageURL;
                    $player_playingRole = strtolower($player_stats->playingRole);

                    if (preg_match("/wicketkeeper/", $player_playingRole)) {
                        $player_role = "WK";
                    } elseif (preg_match("/batsman/", $player_playingRole)) {
                        $player_role = "BAT";
                    } elseif (preg_match("/allrounder/", $player_playingRole)) {
                        $player_role = "AR";
                    }

                    $pdata = array(
                        "p_id" => $player->pid,
                        "name" => $player->name,
                        "country" => $teams[0],
                        "playing_role" => $player_role,
                        "photo" => $player_img_url
                    );

                     $pints_data = array(
                        "match_id" => $match_data['match_id'],
                        "player_id" => $player->pid,
                        "points" => 0,
                         "credit" => 8,
                         "role" => $player_role,
                         "name"=>$player->name,
                         "country" => $teams[0]
                    );

                    //$poid = $this->players_model->addPlayerInPointsCalculation($pints_data);
                    $player_info = $this->players_model->getPlayersByPid($player->pid);

//                    if (empty($player_info)) {
                    $pid = $this->players_model->addPlayer($pdata, $player_info, $pints_data);

//                    }
                }

                foreach ($players2 as $i => $player) {

                    $player_role = "BOWL";
                    $this->config->load('config');

                    $data['match_api_key'] = $this->config->item('match_api_key');
                    // Fetch Player statistics like imageURL and playingRole
                    $data = array(
                        'apikey' => $data['match_api_key'],
                        'pid' => $player->pid
                    );

                    $data_string = json_encode($data);
                    $curl = curl_init('http://cricapi.com/api/playerStats');

                    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

                    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/json',
                        'Content-Length: ' . strlen($data_string))
                    );

                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);  // Insert the data
                    // Send the request
                    $result = curl_exec($curl);

                    // Free up the resources $curl is using
                    curl_close($curl);

                    $player_stats = json_decode($result);
                    $player_img_url = $player_stats->imageURL;
                    $player_playingRole = strtolower($player_stats->playingRole);
                    $player_battingStyle = $player_stats->battingStyle;
                    $player_bowlingStyle = $player_stats->bowlingStyle;
                    $player_born = $player_stats->born;


                    if (preg_match("/wicketkeeper/", $player_playingRole)) {
                        $player_role = "WK";
                    } elseif (preg_match("/batsman/", $player_playingRole)) {
                        $player_role = "BAT";
                    } elseif (preg_match("/allrounder/", $player_playingRole)) {
                        $player_role = "AR";
                    }

                    $pdata = array(
                        "p_id" => $player->pid,
                        "name" => $player->name,
                        "country" => $teams[1],
                        "playing_role" => $player_role,
                        "battingStyle" => $player_battingStyle,
                        "bowlingStyle" => $player_bowlingStyle,
                        "born" => $player_born,
                        "photo" => $player_img_url
                    );

                    $pints_data = array(
                        "match_id" => $match_data['match_id'],
                        "player_id" => $player->pid,
                        "points" => 0,
                         "credit" => 8,
                         "role" => $player_role,
                         "name"=>$player->name,
                         "country" => $teams[0]
                    );
                    $player_info = $this->players_model->getPlayersByPid($player->pid);
//                    if (empty($player_info)) {
                    $pid = $this->players_model->addPlayer($pdata, $player_info, $pints_data);
                    //$poid = $this->players_model->addPlayerInPointsCalculation($pints_data);
//                    }
                }
            }

            redirect('fetchNewMatches');
            
        }
    }

    /**
     * This function is used load match view information
     * @param number $id : Optional : This is match id
     */
    function viewResultMatch($id = NULL) {

        if ($id == null) {
            redirect('upcommingMatches');
        }
        $this->load->model('match_model');
        $this->load->model('league_model');
          $this->load->model('players_model');
         $matchInfo = $this->match_model->getMatchInfo($id);
        $team1 =$matchInfo[0]->team1;
        $team2 =$matchInfo[0]->team2;
      
        $players1 = $this->players_model->getplayer1ByMatch($id,$team1);
        $players2 = $this->players_model->getplayer2ByMatch($id,$team2);

        $data['team1'] = $team1;
        $data['players1'] = $players1;
        $data['team2'] = $team2;
        $data['players2'] = $players2;

        $matchInfo = $this->match_model->getMatchInfo($id);
        $data['match_info'] = $matchInfo;

        $leage_list = $this->league_model->getLegueByMatch($id);
        $leage_list_count = count($leage_list);
        $data['leage_list_count'] = $leage_list_count;

        $this->load->model('series_model');
        $series_list = $this->series_model->getSeriesList();
        $data['series_list'] = $series_list;


        $this->global['pageTitle'] = 'expect11 : Edit Match';

        $this->loadViews("viewResultMatch", $this->global, $data, NULL);
        /* } */
    }

    /**
     * This function is used load match edit information
     * @param number $id : Optional : This is match id
     */
    function editOldMatch($id = NULL) {

        if ($id == null) {
            redirect('upcommingMatches');
        }
        $this->load->model('match_model');
         $matchInfo = $this->match_model->getMatchInfo($id);
        $team1 =$matchInfo[0]->team1;
        $team2 =$matchInfo[0]->team2;
        $this->load->model('players_model');
        $players1 = $this->players_model->getplayer1ByMatch($id,$team1);
        $players2 = $this->players_model->getplayer2ByMatch($id,$team2);
        
       
        $data['team1'] = $team1;
        $data['players1'] = $players1;
        $data['team2'] = $team2;
        $data['players2'] = $players2;


        $data['match_info'] = $matchInfo;

        $this->load->model('series_model');
        $series_list = $this->series_model->getSeriesList();
        $data['series_list'] = $series_list;

        $this->load->model('flag_list_model');
        $flag_list1 = $this->flag_list_model->getflag_team1($team1);
        $flag_list2 = $this->flag_list_model->getflag_team2($team2);
        $data['flag_list1'] = $flag_list1;
        $data['flag_list2'] = $flag_list2;
         $player_country = $this->players_model->getCountryList();
            $data['country_list'] = $player_country;
        


        $this->global['pageTitle'] = 'expect11 : Edit Match';

        $this->loadViews("editOldMatch", $this->global, $data, NULL);
    }
    
    
     function checkPlayer()
    {
       
        
        $players_name = $_POST['player_name'];
        $match_id = $_POST['match_id'];
        $name = explode("," , $players_name);
        $name1 = $name[1];
        $this->db->select('name');
        $this->db->where('name',$name1);
        $this->db->where('match_id',$match_id);
        $query = $this->db->get('points_calculation');
        if ($query->num_rows() > 0){
          echo "taken";
          
        }else{
          echo 'not_taken';
          
        }
        exit();
    }
    
    
       function checkPlayer1()
    {
       
        
        $players_name = $_POST['player_name'];
        $match_id = $_POST['match_id'];
        $name = explode("," , $players_name);
        $name1 = $name[1];
        $this->db->select('name');
        $this->db->where('name',$name1);
        $this->db->where('match_id',$match_id);
        $query = $this->db->get('points_calculation');
        if ($query->num_rows() > 0){
          echo "taken";
          
        }else{
          echo 'not_taken';
          
        }
        exit();
    }
    
     function addNewPlayer1()
    {
        
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('country','Country','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('player','Player','trim|required|xss_clean');
            
             
                $player = $this->input->post('player_id');
                $match_id = $this->input->post('match_id');
                $country = $this->input->post('country');
                 $team1 = $this->input->post('team1');
                $players=explode(',',$player);
                
                
                 if((!empty($match_id))){
                    
                    $this->load->model('players_model');
                    $playerInfos=$this->players_model->getplayersByPlayerId($players[0]);
                    

                    $credit=$playerInfos[0]->credit;
                    $points=$playerInfos[0]->points;
                    $role=$playerInfos[0]->playing_role;
                    $country=$playerInfos[0]->country;
                    $name=$playerInfos[0]->name;


                    $users = array();
                    $users = json_decode($players1, true);
                   
                   
                        
                }
                    $this->load->model('players_model');
                
                $data = array(
                   
                    'match_id'=> $match_id,
                    'player_id'=> $players[0],
                    'credit' => $credit,
                    'points' => $points,
                    "role" => $role,
                    "country" => $team1,
                     "name" => $name
                  
                    
                   
                );
               
               
                $result = $this->players_model->addPlayerInPointsCalculation($data);
            
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Players added successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Players addition failed');
                }
                
                redirect('editOldMatch/'.$match_id);
          
    }
    

   
    
   
    /**
     * This function is used to edit the player information
     */

     function setPlayer(){
         
            $country=$this->input->post('country');
            //echo "Series name".$series_name;
           
            if($country!="" && $country!='NULL'){
                // echo "Series Not Found";
               
                $this->load->model('players_model');
                  $player_records = $this->players_model->getPlayersByCountry($country);
                $data['player_records'] = $player_records;
                echo" <select id='player_id'>";
                echo'<option>---Select Player---</option>';
                    
                   foreach($player_records as  $record1):
                   //print_r($matchInfo1);

                            echo '<option value="' . $record1->p_id.',' .$record1->name. '">' . $record1->name. '</option>';
                        endforeach;
                        
                    
                  echo"</select>";  
            }
        
    }

    function setPlayer1(){
         
            $country=$this->input->post('country');
            //echo "Series name".$series_name;
           
            if($country!="" && $country!='NULL'){
                // echo "Series Not Found";
               
                $this->load->model('players_model');
                  $player_records = $this->players_model->getPlayersByCountry($country);
                $data['player_records'] = $player_records;
                echo" <select id='player_id1'>";
                echo'<option>---Select Player---</option>';
                    
                   foreach($player_records as  $record1):
                   //print_r($matchInfo1);

                            echo '<option value="' . $record1->p_id.',' .$record1->name. '">' . $record1->name. '</option>';
                        endforeach;
                        
                    
                  echo"</select>";  
            }
        
    }

    /**
     * This function is used to edit the player information
     */
    function editMatch() {

        $this->load->library('form_validation');

        $id = $this->input->post('match_id');

        $this->form_validation->set_rules('series', 'Series', 'trim|required|xss_clean');
        $this->form_validation->set_rules('admin_status', 'Status', 'trim|required|xss_clean');
        $this->form_validation->set_rules('admin_status', 'Status', 'trim|required|xss_clean');
        $this->form_validation->set_rules('admin_status', 'Status', 'trim|required|xss_clean');
//        $team1_img_data = json_decode($this->do_upload('team1_img1'));
//        $team2_img_data = json_decode($this->do_upload('team2_img1'));

        if ($this->form_validation->run() == FALSE) {
            $this->editOldMatch($id);
        } else {
            $cancel_desc = $this->input->post('cancel_desc');
            $team1_logo = $this->input->post('team1_img_1');
            $team2_logo = $this->input->post('team2_img_1');
            $team1_short = $this->input->post('team1_short');
            $team2_short = $this->input->post('team2_short');
            $series = $this->input->post('series');
            $admin_status = $this->input->post('admin_status');
            $match_type = $this->input->post('match_type');
           
            $start_dt = date('Y-m-d H:i:s', strtotime($this->input->post('start_dt')));
            $end_dt = date('Y-m-d H:i:s', strtotime($this->input->post('end_dt')));
            if (!empty($cancel_desc)) {
                $status = 'ABANDONED';
                $cancel_desc = $cancel_desc;
                $data = array(
                    'admin_status' => $admin_status,
                    'series' => $series,
                    'match_type' => $match_type,
                    'team1_short_name' => $team1_short,
                    'team2_short_name' => $team2_short,
                    'status' => $status,
                    'cancel_desc' => $cancel_desc,
                    'start_dt' => $start_dt,
                    'end_dt' => $end_dt
                );
                $this->load->model('league_model');
                $leage_list = $this->league_model->getLegueByMatch($id);
                $id = $leage_list[0]->id;
                $leage_list1 = $this->league_model->getleagueInfobyId($id);
                $u_id = $league_list1[0]->user_id;
                $this->load->model('user_model');
                $user_info = $this->user_model->getUser($u_id);
                $userid = $user_info[0]->id;
               
                $postData = '';
                $params = array(
                    'title' => 'Match Cancelled Successfully',
                    'msg' => $cancel_desc,
                    'image' => null,
                    'user_id' => $userid
                );
                $postData = http_build_query($params);
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $this->_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_POST, count($postData));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                $output = curl_exec($ch);
                $output_data [] = json_decode($output);
                curl_close($ch);

                $params = array(
                    'title' => 'Match Cancelled Successfully',
                    'message' => $cancel_desc,
                    'user_id' => $userid
                );
                $nid = $this->notification_model->addNewNotification($params);
                foreach ($leage_list as $record) {
                    if ($admin_status == 'ABANDONED') {
                        $status = 'CANCEL';
                    }
                    $result1 = $this->league_model->editLeaguestatus($status, $id);
                    $this->refundAmount($league_id, $match_id);
                }
            } else {
                $data = array(
                    'admin_status' => $admin_status,
                    'series' => $series,
                    'match_type' => $match_type,
                    'team1_short_name' => $team1_short,
                    'team2_short_name' => $team2_short,
                    'status' => 'UPCOMING',
                    'start_dt' => $start_dt,
                    'end_dt' => $end_dt
                );
            }

            if (isset($team1_img_data->status->file_name) && !empty($team1_img_data->status->file_name)) {
                $data['team1_logo'] = $team1_img_data->status->file_name;
                print_r($data['team1_logo']);
                print $team1_img_data->status->full_path;
            } else if (!empty($team1_logo)) {
                $data['team1_logo'] = $team1_logo;
            }

            if (isset($team2_img_data->status->file_name) && !empty($team2_img_data->status->file_name)) {
                $data['team2_logo'] = $team2_img_data->status->file_name;
                print $team2_img_data->status->full_path;
                die;
            } else if (!empty($team2_logo)) {
                $data['team2_logo'] = $team2_logo;
            }
            $this->load->model('match_model');
            $result = $this->match_model->editmatch($data, $id);
            //$this->load->model('flag_list_model');
            //$result1 = $this->flag_list_model->addFlagShort($data, $id);
            if ($result > 0) {
                $this->session->set_flashdata('success', 'Match updated successfully');
            } else {
                $this->session->set_flashdata('error', 'Match updation failed');
            }
            redirect('editOldMatch');
        }
    }
    
    
    function deletePlayer() {

        $id =$_GET['id'];
       

        if ($id == null) {
            redirect('upcommingMatches');
        }
        
        $this->load->model('players_model');
        $id = $this->players_model->deletePlayerfromPoints($id);

        
       
    }

    /**
     * This function is used load match edit information
     * @param number $id : Optional : This is match id
     */
    function deleteOldMatch($id = NULL) {

        if ($id == null) {
            redirect('upcommingMatches');
        }

        $this->load->model('match_model');
        $id = $this->match_model->deleteMatch($id);

        if ($id) {
            $this->session->set_flashdata('success', 'Match deleted successfully');
        } else {
            $this->session->set_flashdata('error', 'Match deletion failed');
        }
        redirect('upcommingMatches');
    }
    
    
     /** edit player info**/
    function editPlayer()
    {
        
            $this->load->library('form_validation');
             $id = $_GET['id']; 
                 $credit = $_GET['credit'];
                  $playing_role = $_GET['playing_role'];
                $data = array(
                    'credit' => $credit,
                   
                    'role' => $playing_role
                );
                                
                $this->load->model('players_model');
                $result = $this->players_model->editPlayer($data, $id);
               
               
    }
    
    function addDefaultLeague() {
        
        $league = $this->input->post('league');
        if (!empty($league)) {


            foreach ($league as $value) {
                
                $this->load->model('league_model');
                $leagues = $this->league_model->getLegueInfobyId($value);
                
                foreach ($leagues as $value1) {
                    $contest_id = $value1['id'];
                    $matchs = $this->input->post('mat_id');
                    
                    $data = array(
                        'name' => $value1['name'],
                        'is_default' => 'NO',
                        'match_id' => $matchs,
                        'type' => $value1['type'],
                        'type_id' => $value1['type_id'],
                        'winning_amount' => $value1['winning_amount'],
                        'contest_size' => $value1['contest_size'],
                        'commission' => $value1['commission'],
                        'entry_fees' => $value1['entry_fees'],
                        'winner' => $value1['winner'],
                        'multi_joined' => $value1['multi_joined'],
                        'cancel_contest' => $value1['cancel_contest']
                    );

                    
                    $this->load->model('league_model');

                    $leage_id = $this->league_model->addNewLeague($data);
                   
                    $this->load->model('winners_model');
                    if (!empty($contest_id)) {
                        
                        $winners = $this->winners_model->getwinnerbymatchid($contest_id);
                       
                        foreach ($winners as $val) {
                            $league_id = $leage_id;

                            $wdata = array(
                                // 
                                'match_id' => $matchs,
                                'min' => $val['min'],
                                'max' => $val['max'],
                                'percent' => $val['percent'],
                                'amount' => $val['amount'],
                                 'user_percent' => $val['user_percent'],
                                'user_amount' => $val['user_amount'],
                                'contest_id' => $league_id
                            );
                            
                            $this->load->model('league_model');
                            $winner_id = $this->league_model->addWinnerConfig($wdata);
                        }
                    }

                    $this->load->model('winners_model');
                    if (!empty($contest_id)) {
                        
                        $winner = $this->winners_model->getWinnerByLeague($contest_id);
                        
                        foreach ($winner as $vals) {
                            $league_id = $leage_id;
                            $data = array(
                                'rank' => $vals['rank'],
                                'winning_percent' => $vals['winning_percent'],
                                'winning_amount' => $vals['winning_amount'],
                                'set_of_winners' => $vals['set_of_winners'],
                                'contest_id' => $league_id
                            );
                            
                            $this->load->model('winners_model');
                            $winner_id = $this->winners_model->addWinnerList($data);
                            if ($winner_id > 0) {
                                $this->session->set_flashdata('successed', 'League added successfully');
                                $this->session->unset_userdata('match_id');
                            } else {
                                $this->session->set_flashdata('error', 'League addition failed');
                                
                            }
                        }
                    }
                }
            }
        }
        redirect('fetchNewMatches');
    }

    function do_upload($file_name = "") {

        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|gif|png';
        $config['overwrite'] = TRUE;
        $config['max_size'] = '8048';

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload($file_name)) {
            $status = 'error';
            $msg = $this->upload->display_errors('', '');
        } else {
            $status = 'success';
            $image_data = $this->upload->data(); //get image data          
            $msg = $image_data;
        }
        if ($status == 'success') {
            $config = array(
                'source_image' => $image_data['full_path'], //get original image
                'new_image' => './uploads/', //save as new image //need to create thumbs first
                'overwrite' => TRUE,
                'maintain_ratio' => TRUE,
                'width' => 630,
                'height' => 340,
            );
            //$this->load->library('image_lib', $config); //load library
            //$this->image_lib->resize(); //do whatever specified in config
            // $data = array(
            //     'type'  => 'banner',
            //     'created'   => date("Y-m-d H:i:s", now()),
            //     'status'    => 'active',
            //     'banner'    => $image_data['file_name'] 
            // );
            // $id = $this->Banners_model->save($data);
        }

        return json_encode(array(
            'status' => $msg
        ));
    }
     function cancelMatch(){
        $id = $this->input->post('id');
        $cancel_desc = $this->input->post('cancel_desc');
        $status = 'ABANDONED';
        $admin_status = 'ABANDONED';
        $data =array(
            'cancel_desc' =>$cancel_desc,
            'status' =>$status,
            'admin_status' =>$admin_status,
        );
        $this->load->model('match_model');
        $result = $this->match_model->editMatchStatus($data, $id);
        $this->cancelLeague($id);
        }
   
        function cancelLeague($id){
                $contest = $this->league_model->leagueInfo($id);
                foreach ($contest as $value) {
                    $league_id = $value['id'];
                    $contest_size = $value['contest_size'];
                    $is_cancelled = $value['cancel_contest'];
                    $league_staus = $value['status'];
                    $cancel_desc = 'Match is abandoned.';
                    if (!empty($league_id) && $league_staus == 'ACTIVE') {
                        $res = $this->league_model->getCountOfLeague($league_id);
                        $userid = $res[0]['user_id'];
                        
                        $res_1 = count($res);
                        if (!empty($userid)) {
                            $match_status = 'The Match will be abandoned.';
                            $postData = '';
                            $params = array(
                                'title' => 'Match Abadoned',
                                'msg' => $match_status,
                                'image' => null,
                                'user_id' => $userid
                            );

                            $postData = http_build_query($params);
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, $this->_url);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                            curl_setopt($ch, CURLOPT_HEADER, false);
                            curl_setopt($ch, CURLOPT_POST, count($postData));
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                            $output = curl_exec($ch);
                            $output_data [] = json_decode($output);
                            curl_close($ch);

                            $params = array(
                                'title' => 'Match Abaddoned',
                                'message' => $match_status,
                                'user_id' => $userid
                            );
                            $nid = $this->notification_model->addNewNotification($params);
                        }
                        $data = array(
                            'status' => 'CANCEL',
                            'cancel_desc' => 'Contest is cancel because Match is abandoned'
                        );
                        $res1 = $this->league_model->updateStatus($data, $league_id);
                        $this->refundAmount($league_id, $match_id);
                    }
                }
        }

        function getPoints2($v1='') {

            $this->load->model('match_model');
            $live_matches = $this->match_model->matchListing('', 'live', 999, 0);
            
            $summary = array();
            $match_summary = array();
            // if (!empty($live_matches)) 
            {

                // foreach ($live_matches as $match) 
                {
                    
                    $this->config->load('config');
                    


                    $data['match_api_key'] = $this->config->item('match_api_ley');

                    $data = array(
                        'unique_id' => $v1,
                        'apikey' => "4B5LoWgVmIdM22wTgarwgfk03DL2"
                    );
                    // print_r($data);


                    $data_string = json_encode($data);

                    $curl = curl_init('http://cricapi.com/api/fantasySummary/');

                    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

                    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/json',
                        'Content-Length: ' . strlen($data_string))
                    );

                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);  // Make it so the data coming back is put into a string
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);  // Insert the data
                    // Send the request
                    $result = curl_exec($curl);

                    // Free up the resources $curl is using
                    curl_close($curl);


                    $match_summary = json_decode($result);
                    $summary[$match->match_id] = $match_summary->data;
                    $summary[$match->match_id]->match_type = $match->match_type;
                    // print_r($match_summary);
                }
            }

            if (!empty($summary)) {
                foreach ($summary as $id => $data) {
                    $batting1 = (!empty($data->batting[0])) ? $data->batting[0]->scores : array();
                    $batting2 = (!empty($data->batting[1])) ? $data->batting[1]->scores : array();
                    $batting3 = (!empty($data->batting[2])) ? $data->batting[2]->scores : array();
                    $batting4 = (!empty($data->batting[3])) ? $data->batting[3]->scores : array();
                    $batting = array_merge($batting1, $batting2, $batting3, $batting4);



                    $bowling1 = (!empty($data->bowling[0])) ? $data->bowling[0]->scores : array();
                    $bowling2 = (!empty($data->bowling[1])) ? $data->bowling[1]->scores : array();
                    $bowling3 = (!empty($data->bowling[2])) ? $data->bowling[2]->scores : array();
                    $bowling4 = (!empty($data->bowling[3])) ? $data->bowling[3]->scores : array();
                    $bowling = array_merge($bowling1, $bowling2, $bowling3, $bowling4);


                    $fielding1 = (!empty($data->fielding[0])) ? $data->fielding[0]->scores : array();
                    $fielding2 = (!empty($data->fielding[1])) ? $data->fielding[1]->scores : array();
                    $fielding3 = (!empty($data->fielding[2])) ? $data->fielding[2]->scores : array();
                    $fielding4 = (!empty($data->fielding[3])) ? $data->fielding[3]->scores : array();
                    $fielding = array_merge($fielding1, $fielding2, $fielding3, $fielding4);

                    $team1 = (!empty($data->team[0])) ? $data->team[0]->players : array();
                    $team2 = (!empty($data->team[1])) ? $data->team[1]->players : array();
                    $players = array_merge($team1, $team2);


                    $match_type = $data->match_type;

                    if ($match_type == 'T20' || $match_type == 'Twenty20') {

                        // Batings
                        $for_every_run = 1; // for every run scored 
                        $for_every_boundry_hit = 0.5; // Bundry Bonus
                        $for_every_six_hit = 1; // Six Bonus
                        $half_century = 4; // Half Century Bonus
                        $century = 8; // Century Bonus
                        $dismiss_for_duck = -2; // dismiss for duck
                        // Bowling
                        $wicket_wo_ro = 15; //wicket excluding run out
                        $four_wicket = 4; // 4 Wicket haul Bounus
                        $above_4_wicket = 8; // above 4 wicket
                        $maiden_over = 4; // Maiden Over
                        //Fielding
                        $catch_point = 4; //catch
                        $run_out_point = 6; // Stumping / runout
                        // Others

                        $in_starting_11 = 2; // In Starting 11 Players
                        //Economy Rate
                        $over_condition = 2; // (Min 2 Overs To Be Bowled)
                        $below_4_run_over = 3; // Below 4 runs per over
                        $less_then_5_run_over = 2; // Between 4-4.99 runs per over
                        $less_then_5_6_run_over = 1; // Between 4-4.99 runs per over

                        $bw_9_10_per_over = -1;
                        $bw_10_11_per_over = -2;
                        $above_11_per_over = -3;


                        // Strike run rates
                        $strike_ball = 10; // Min 10 Balls To Be Played
                        $strike_rate_less_50 = -3; // Below 50 runs per 100 balls
                        $strike_rate_less_50_60 = -2; //Between 50-59.9 runs per 100 balls
                        $strike_rate_less_60_70 = -1; //Between 60-70 runs per 100 balls
                    } else
                    if ($match_type == 'ODI') {

                        // Batings
                        $for_every_run = 1; // for every run scored 
                        $for_every_boundry_hit = 0.5; // Bundry Bonus
                        $for_every_six_hit = 1; // Six Bonus
                        $half_century = 2; // Half Century Bonus
                        $century = 4; // Century Bonus
                        $dismiss_for_duck = -3; // dismiss for duck
                        // Bowling
                        $wicket_wo_ro = 18; //wicket excluding run out
                        $four_wicket = 2; // 4 Wicket haul Bounus
                        $above_4_wicket = 4; // above 4 wicket
                        $maiden_over = 2; // Maiden Over
                        //Fielding
                        $catch_point = 4; //catch
                        $run_out_point = 6; // Stumping / runout
                        // Others
                        $in_starting_11 = 2; // In Starting 11 Players
                        //Economy Rate
                        $over_condition = 5; // (Min 5 Overs To Be Bowled)

                        $below_4_run_over = 3; // Below 4 runs per over
                        $less_then_5_run_over = 2; // Between 4-4.99 runs per over
                        $less_then_5_6_run_over = 1; // Between 4-4.99 runs per over

                        $bw_9_10_per_over = -1;
                        $bw_10_11_per_over = -2;
                        $above_11_per_over = -3;

                        // Strike run rates
                        $strike_ball = 20; // Min 20 Balls To Be Played
                        $strike_rate_less_40 = -3;
                        $strike_rate_less_40_50 = -2;
                        $strike_rate_less_50_60 = -1;
                    } else {

                        // Batings
                        $for_every_run = 1; // for every run scored 
                        $for_every_boundry_hit = 0.5; // Bundry Bonus
                        $for_every_six_hit = 1; // Six Bonus
                        $half_century = 2; // Half Century Bonus
                        $century = 4; // Century Bonus
                        $dismiss_for_duck = -4; // dismiss for duck
                        // Bowling
                        $wicket_wo_ro = 12; //wicket excluding run out
                        $four_wicket = 2; // 4 Wicket haul Bounus
                        $above_4_wicket = 4; // above 4 wicket
                        $maiden_over = 0; // Maiden Over
                        //Fielding
                        $catch_point = 4; //catch
                        $run_out_point = 6; // Stumping / runout
                        // Others

                        $in_starting_11 = 2; // In Starting 11 Players
                        //Economy Rate

                        $over_condition = 0; // Min Over Required
                        $below_4_run_over = 0; // Below 4 runs per over
                        $less_then_5_run_over = 0; // Between 4-4.99 runs per over
                        $less_then_5_6_run_over = 0; // Between 4-4.99 runs per over

                        $bw_9_10_per_over = 0;
                        $bw_10_11_per_over = 0;
                        $above_11_per_over = 0;

                        $strike_ball = 0; // Min 10 Balls To Be Played
                        // Strike run rates
                        $strike_rate_less_50 = 0;
                        $strike_rate_less_50_60 = 0;
                        $strike_rate_less_60_70 = 0;

                        $strike_rate_less_40 = 0;
                        $strike_rate_less_40_50 = 0;
                        $strike_rate_less_50_60 = 0;
                    }

                    foreach ($players as $i => $p_data) {
                        $pid = $p_data->pid;
                        $point = $in_starting_11;

                        // each run points
                        foreach ($batting as $b_i => $b_v) {
                            if ($b_v->pid == $pid) {
                                $point += ($b_v->R * $for_every_run);

                                // Player out on zero run
                                if ($b_v->R == 0 && $b_v->dismissal != 'not out') {
                                    $point += $dismiss_for_duck;
                                }

                                //boundary
                                $tempb_v = (array) $b_v;
                                if ($tempb_v['4s'] > 0) {
                                    $point += ($tempb_v['4s'] * $for_every_boundry_hit);
                                }
                                //six
                                if ($tempb_v['6s'] > 0) {
                                    $point += ($tempb_v['6s'] * $for_every_six_hit);
                                }

                                // Half Century
                                if ($b_v->R >= 50 && $b_v->R < 100) {
                                    $point += $half_century;
                                }

                                // Centuary
                                if ($b_v->R >= 100) {
                                    $point += $century;
                                }

                                // For Strike Run Rate condition
                                if ($b_v->B >= $strike_ball) {
                                    // if less then 50 Sr

                                    if ($match_type == 'T20') {
                                        if ($b_v->SR <= 50) {
                                            $point += $strike_rate_less_50;
                                        } else
                                        if ($b_v->SR > 50 && $b_v->SR < 60) {
                                            $point += $strike_rate_less_50_60;
                                        } else
                                        if ($b_v->SR >= 60 && $b_v->SR <= 70) {
                                            $point += $strike_rate_less_60_70;
                                        }
                                   //     else
                                   //                                    if ($b_v->SR >= 110 && $b_v->SR <= 140) {
                                   //                                        $point += $strike_rate_110_to_140;
                                   //                                    } else
                                   //                                    if ($b_v->SR > 140 && $b_v->SR <= 180) {
                                    //                                        $point += $strike_rate_140_to_180;
                                    //                                    } else
                                    //                                    if ($b_v->SR > 180) {
                                    //                                        $point += $strike_rate_above_180;
                                    //                                    }
                                    } else {
                                        if ($b_v->SR <= 40) {
                                            $point += $strike_rate_less_40;
                                        } else
                                        if ($b_v->SR > 40 && $b_v->SR < 50) {
                                            $point += $strike_rate_less_40_50;
                                        } else
                                        if ($b_v->SR >= 50 && $b_v->SR <= 60) {
                                            $point += $strike_rate_less_50_60;
                                        }
                        //                                    else
                        //                                    if ($b_v->SR >= 110 && $b_v->SR <= 140) {
                        //                                        $point += $strike_rate_110_to_140;
                        //                                    } else
                        //                                    if ($b_v->SR > 140 && $b_v->SR <= 180) {
                        //                                        $point += $strike_rate_140_to_180;
                        //                                    } else
                        //                                    if ($b_v->SR > 180) {
                        //                                        $point += $strike_rate_above_180;
                        //                                    }
                                    }
                                }
                            }
                        }

                        // wicket without run out points
                        foreach ($bowling as $bw_i => $bw_v) {
                            if ($bw_v->pid == $pid) {
                                $point += ($bw_v->W * $wicket_wo_ro);
                                $point += ($bw_v->M * $maiden_over);
                                if ($bw_v->W == 4) {
                                    $point += $four_wicket;
                                }
                                if ($bw_v->W >= 5) {
                                    $point += $above_4_wicket;
                                }

                                if ($bw_v->O >= $over_condition) {
                                    if ($bw_v->Econ < 4) {
                                        $point += $below_4_run_over;
                                    }
                                    if ($bw_v->Econ >= 4 && $bw_v->Econ < 5) {
                                        $point += $less_then_5_run_over;
                                    }

                                    if ($bw_v->Econ >= 5 && $bw_v->Econ <= 6) {
                                        $point += $less_then_5_6_run_over;
                                    }
                                    if ($bw_v->Econ >= 9 && $bw_v->Econ <= 10) {
                                        $point += $bw_9_10_per_over;
                                    }
                                    if ($bw_v->Econ > 10 && $bw_v->Econ <= 11) {
                                        $point += $bw_10_11_per_over;
                                    }
                                    if ($bw_v->Econ > 11) {
                                        $point += $above_11_per_over;
                                    }
                                }
                            }
                        }

                        // catch points
                        foreach ($fielding as $f_i => $f_v) {
                            if ($f_v->pid == $pid) {
                                $point += ($f_v->catch * $catch_point);
                            }
                        }

                //                    // stumped / runout points
                        foreach ($fielding as $f_i => $f_v) {
                            if ($f_v->pid == $pid) {
                                $point += (($f_v->stumped + $f_v->runout) * $run_out_point);
                            }
                        }

                        $pl_data = array(
                            'points' => $point
                        );

                        $pc_data = array(
                            'points' => $point
                        );
                        echo "id ".$id." - ".$pid."<hr>";
                        print_r($pl_data);


                        $this->load->model('players_model');
                        $result = $this->players_model->editPlayer($pl_data, $pid);

                        // store points to points calculation table
                        $pc_result = $this->players_model->storePointsCalc($pc_data, $v1, $pid);
                    }
                }

                $this->calculatePoints2($v1);
            }
        }

 }
?>