<?php 

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Series (SeriesController)
 * Series Class to manage all series related operations.
 */
class Series extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn(); 
         $this->load->model('series_model');
       $this->load->model('match_model');
        $this->load->model('league_model');
         $this->load->model('joined_league_model');
    }

    /**
     * This function is used to load the series list
     */
    function seriesListing()
    {
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->series_model->seriesListingCount($searchText);

			$returns = $this->paginationCompress ( "seriesListing/", $count, 10 );

            
            $seriesRecords = $this->series_model->seriesListing($searchText, $returns["page"], $returns["segment"]);
             $matchInfo_list= array();
            foreach ($seriesRecords as $records) {
               
            $matchInfo = $this->match_model->getMatchInfoBySeries($records->id);
            
            $matchInfo_list[$records->id] =count($matchInfo);
           
            }
            $data['seriesRecords'] = $seriesRecords;
            $data['matchInfo_list'] = $matchInfo_list;
            
            
            $this->global['pageTitle'] = 'Expect11 : Series Listing';
            
            $this->loadViews("series", $this->global, $data, NULL);
      
    }

    /**
     * This function is used to load the add new form
     */
    function newSeries()
    {
            $data = array();
            $this->global['pageTitle'] = 'Expect11 : Add New User';

            $this->loadViews("newSeries", $this->global, $data, NULL);
        
    }
    
    /** This function is used to compare date**/
    function compareDate() {
              $startDate = strtotime($_POST['start_dt']);
              $endDate = strtotime($_POST['end_dt']);

              if ($endDate >= $startDate)
                return True;
              else {
                $this->form_validation->set_message('compareDate', '%s should be greater than  Start Date.');
                return False;
              }
            }

     /**
     * This function is used to add new series to the system
     */       
    function addNewSeries()
    {
       
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('name','Series Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('start_dt','Start Date','trim|required|xss_clean');
            $this->form_validation->set_rules('end_dt','End Date','trim|required|xss_clean|callback_compareDate');
            $this->form_validation->set_rules('status','Status','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->newSeries();
            }
            else
            {
                $name = ucwords(strtolower($this->input->post('name')));
                $start_dt = $this->input->post('start_dt');
                $end_dt = $this->input->post('end_dt');
                $status = $this->input->post('status');
                
                $data = array(
                    'name' => $name, 
                    'start_dt' => date("Y-m-d h:i:sa", strtotime($start_dt)), 
                    'end_dt' => date("Y-m-d h:i:sa", strtotime($end_dt)), 
                    'status' => $status
                );
                
                
                $result = $this->series_model->addNewSeries($data);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Series added successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Series addition failed');
                }
                
                redirect('seriesListing');
            }
        
    }

    /**
     * This function is used load series edit information
     * @param number $id : Optional : This is series id
     */
    function editOldSeries($id = NULL)
    {
        if($id == null)
            {
                redirect('seriesListing');
            }
          
              $seriesInfo = $this->series_model->getSeriesInfo($id);
            $data['series_info'] = $seriesInfo;
            
            $this->global['pageTitle'] = 'Expect11 : Edit User';
            
            $this->loadViews("editOldSeries", $this->global, $data, NULL);
      
    }

    /** this function is used for get all match by series**/
    function getallMatchesBySeries($id = NULL){
        
            if($id == null)
            {
                redirect('seriesListing');
            }
        
         $matchInfo = $this->match_model->getMatchInfoBySeries($id);
         $data['matchInfo'] = $matchInfo;
         $leage_list_count = array();
         $join_team_count = array();
         foreach($matchInfo as $value){
             
               
                $leage_list = $this->league_model->getLegueByMatch($value->match_id);
                $leage_list_count[$value->id] = count($leage_list);
                $data['leage_list_count'] = $leage_list_count;
                 
                $teams_list = $this->joined_league_model->getByLeague($value->match_id);
                $join_team_count[$value->id] = count($teams_list);
                $data['join_team_count'] = $join_team_count;
                
         }
            $this->global['pageTitle'] = 'Expect11 : Match Management';
            $this->loadViews("getallMatchesBySeries", $this->global, $data, NULL);
}

    

    /**
     * This function is used to edit the series information
     */
    function editSeries()
    {
        
            $this->load->library('form_validation');
            
            $id = $this->input->post('id');
            
            $this->form_validation->set_rules('name','Series Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('start_dt','Start Date','trim|required|xss_clean');
            $this->form_validation->set_rules('end_dt','End Date','trim|required|xss_clean');
            $this->form_validation->set_rules('status','Status','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->editOldSeries($id);
            }
            else
            {
                $name = ucwords(strtolower($this->input->post('name')));
                $start_dt = $this->input->post('start_dt');
                $end_dt = $this->input->post('end_dt');
                $status = $this->input->post('status');
                
                $data = array(
                    'name' => $name, 
                    'start_dt' => date("Y-m-d", strtotime($start_dt)), 
                    'end_dt' => date("Y-m-d", strtotime($end_dt)), 
                    'status' => $status
                );
                
                
               
                $result = $this->series_model->editSeries($data, $id);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Series updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Series updation failed');
                }
                
                redirect('seriesListing');
            }
        
    }

}

?>