<?php 
error_reporting(0);

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Refeeral (RefeeralController)
 * Banner Class to manage all Refeeral related operations.
 */
class Referrals extends BaseController
{
    // helo world sadsad
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();   
    }
    

    /**
     * This function is used to load the referral list
     */
    function referralListing()
    {

        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            /*$id=$this->input->post('id');
            print_r($id);*/
            $this->load->model('user_model');
            //$bannerlist_info = array();
            $referrallist = $this->user_model->getAllUserInfo();
            print_r($referrallist);
            $data['referrallist'] = $referrallist;

            $this->global['pageTitle'] = 'Expect11 : Referral';            
            $this->loadViews("referral", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new league form
     */
    function newbanner()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            
            
            

            $this->global['pageTitle'] = 'Expect11 : Add New Banner';

            $this->loadViews("newBanner", $this->global,  NULL);
        }
    }

   
    /**
     * This function is used to add new flag to the system
     */
    function addNewBanner()
    {
        
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
             $config = array();
                    $config['upload_path'] = './uploads/';
                    $config['allowed_types'] = 'gif|jpg|png';
                    $config['max_size']      = '0';
                    $config['overwrite']     = FALSE;
           
            $this->load->library('form_validation', $config);
       

            $this->form_validation->set_rules('banner_type','Banner Type','trim|required|max_length[128]|xss_clean');
              if ($this->form_validation->run() == FALSE)
               {
                $this->newbanner();
               } 
                else 
                {
                        $this->load->library('upload', $config);

                       
                        if($_FILES)
                        {
                            //print_r($_FILES);
                            $files = $_FILES;
                            $_FILES['banner_name']['name'];
                           
                            
                            $this->upload->initialize($config);
                            $this->upload->do_upload('banner_name');
                            $dataInfo = $this->upload->data();
                            $image= $dataInfo['file_name'];

                        }
                    
                        $data =array(
                            'name'=>$image,
                            'banner_type'=>$this->input->post('banner_type')
                        );
                        //print_r($data);die;
                }
          
                        $this->load->model('banner_model');
                        $banner_id = $this->banner_model->addNewBanner($data);
                        if($banner_id > 0)
                        {
                            $this->session->set_flashdata('success', 'New Banner added successfully');
                        }
                        else
                        {
                            $this->session->set_flashdata('error', 'Banner addition failed');
                        }
                
                    redirect('bannerListing');

            
            }
        
    }
    private function set_upload_options()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']      = '500';
        $config['overwrite']     = FALSE;


        return $config;
    }

    /**
     * This function is used load league edit information
     * @param number $id : Optional : This is league id
     */
    function editOldBanner($id = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($id == null)
            {
                redirect('bannerListing');
            }
            $id=$this->input->post('id');
            //print_r($id);die;

            $this->load->model('banner_model');
            

            $bannerInfo_edit = $this->banner_model->getbannerInfo($id);
            //print_r($bannerInfo_edit);die;
            $data['banner_info_edit'] = $bannerInfo_edit;

           


            $this->global['pageTitle'] = 'Expect11 : Edit Banner';
            
            $this->loadViews("bannerListing", $this->global, $data, NULL);
        }
    }

    function editBanner() {
        if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {
            $this->load->library('form_validation');

            $id = $this->input->post('banner_id');
            //print_r($id);die;
            $this->form_validation->set_rules('banner_type', 'Banner Type', 'trim|required|xss_clean');
            
           

            if ($this->form_validation->run() == FALSE) {
                $this->editOldBanner($id);
            } else 

            {
               
                $image_name_data = json_decode($this->do_upload('banner_name'));
                

                $banner_type = $this->input->post('banner_type');

                $data = array(
                    'banner_type' => $banner_type,
                    
                );

                if (isset($image_name_data->status->file_name) && !empty($image_name_data->status->file_name)) {
                    $data['name'] = $image_name_data->status->file_name;
                    //print $image_name_data->status->full_path;
                }

               
                $this->load->model('banner_model');
               
                $result = $this->banner_model->editBanner($data, $id);

                if ($result>0) {
                    $this->session->set_flashdata('success', 'Banner updated successfully');
                } else {
                    $this->session->set_flashdata('error', 'Banner updation failed');
                }

                redirect('bannerListing');
            }
        }
    }
    
    function statusChange(){

    

         if ($this->isAdmin() == TRUE) {
            $this->loadThis();
            
            } 
            else {
                //echo "string  2";
                $id = $this->input->post('id');
                 $status = $this->input->post('status');
                
                if ($status == 'ACTIVE') {
                      $data = array(
                        'status' => $status
                    ); 
                      //print_r($data);die;

                $this->load->model('banner_model');
                $result = $this->banner_model->editBanner($data, $id); 
                 //print_r($result);die;
                }
                else if($status == 'INACTIVE') { 
                //print_r($id);die;

                $data = array(
                    'status' => $status
                );
                
                $this->load->model('banner_model');
                $result = $this->banner_model->editBanner($data, $id);

                }

                //print_r($result);die;
                if ($result) {
                $this->session->set_flashdata('success', 'Thank you for you request. We will get back to you shortly.');
                } else {
                $this->session->set_flashdata('error', 'Something goes wrong. Please try again later.');
                } 
             redirect('bannerListing');

            }
              
    }
    function deleteOldBanner($id = NULL) {
        if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {
            
            if($id == NULL)
            {
                redirect('bannerListing');
            }
            //print_r($id);die;
            $this->load->model('banner_model');
            $id = $this->banner_model->deletebanner($id);

            if ($id) {
                $this->session->set_flashdata('success', 'Banner deleted successfully');
            } else {
                $this->session->set_flashdata('error', 'Banner deletion failed');
            }
            redirect('bannerListing');
        }
    }

    function do_upload($file_name = "") {

        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|gif|png';
        $config['overwrite'] = TRUE;
        $config['max_size'] = '8048';

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload($file_name)) {
            $status = 'error';
            $msg = $this->upload->display_errors('', '');
        } else {
            $status = 'success';
            $image_data = $this->upload->data(); //get image data          
            $msg = $image_data;
        }
        if ($status == 'success') {
            $config = array(
                'source_image' => $image_data['full_path'], //get original image
                'new_image' => './uploads/', //save as new image //need to create thumbs first
                'overwrite' => TRUE,
                'maintain_ratio' => TRUE,
                'width' => 630,
                'height' => 340,
            );
            //$this->load->library('image_lib', $config); //load library
            //$this->image_lib->resize(); //do whatever specified in config
            // $data = array(
            //     'type'  => 'banner',
            //     'created'   => date("Y-m-d H:i:s", now()),
            //     'status'    => 'active',
            //     'banner'    => $image_data['file_name'] 
            // );
            // $id = $this->Banners_model->save($data);
        }

        return json_encode(array(
            'status' => $msg
        ));
    }
  }  
?>