<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 */
class User extends BaseController
{
    /**
     * This is default constructor of the class
     */
      private $headers;
    private $subject;
    private $message;
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('transaction_model');
        $this->load->model('match_model');
        $this->load->model('league_model');
        $this->load->model('players_model');
        $this->load->model('transaction_model');
        $this->load->model('series_model');
        $this->load->model('admin_model');
        $this->load->model('bank_details_model');
        $this->load->model('withdraw_request_model');
        $this->isLoggedIn(); 
         $this->config->load('config');
            $this->_url = $this->config->item('notify_url');
         $from = $this->config->item('email');
        $this->headers = 'MIME-Version: 1.0' . "\r\n";
        $this->headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $this->headers .= 'From:' . $from;
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        
        

        $data['total_customers'] = $this->user_model->appUserListingCount();
         $data['total_bank'] = count($this->bank_details_model->bankDetailList());
        $data['total_subadmin'] = count($this->admin_model->admindetaillist());
        $data['total_leagues'] = $this->league_model->leagueListingCount();
        $data['total_series'] = $this->series_model->seriesListingCount();
       $data['total_matches'] = count($this->match_model->getAllMatch());
        $data['total_players'] = count($this->players_model->getAllPlayers());
         $data['total_withdraw'] = $this->withdraw_request_model->withdrawListingCount();
         $this->global['pageTitle'] = 'Expect11 : Dashboard';
        
        $this->loadViews("dashboard", $this->global, $data , NULL);
    }
    
    /**
     * This function is used to load the user list
     */
    function userListing()
    {
       
           $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->userListingCount($searchText);

			$returns = $this->paginationCompress ( "userListing/", $count, 5 );
            
            $data['userRecords'] = $this->user_model->userListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Expect11 : User Listing';
            
            $this->loadViews("users", $this->global, $data, NULL);
        
    }

    /**
     * This function is used to load the user list
     */
    function appUserListing()
    {
       
            $cities = array();
            $referral_count = array();
            $data['userRecords'] = $this->user_model->appUserListing();
            if(!empty($data['userRecords'])) {
                foreach($data['userRecords'] as $record) {
                    $referral = $this->user_model->getrefferal($record->r_id);
                     $referral_count[$record->id] = count($referral);
                   $cities [$record->city] = $this->user_model->getCityName($record->city); 

                }
            }
            $data['city'] = $cities;
            $data['referral_count'] = $referral_count;
            $this->global['pageTitle'] = 'Expect11 : User Listing';
            
            $this->loadViews("appUsers", $this->global, $data, NULL);
       
    }

    /**
     * This function is used load user information
     * @param number $userId : This is user id
     */
    function viewAppUser($userId)
    {
        if($userId == null)
        {
            redirect('appUserListing');
        }
       
         $cities = array();
        $states = array();
        $transcation_list_info= array();
        $transcation_list_info1= array();
        $data['userInfo'] = $this->user_model->getAppUserInfo($userId);
        $txn_type=$this->input->post('txn_type');
        if(!empty($data['userInfo'])) {
                foreach ($data['userInfo'] as $record) {
                
               $transcation_info= $this->transaction_model->getTransaction($record->id);
               
               $transcation_info1= $this->transaction_model->getsumAmount($record->id);
               $transcation_list_info1[$record->id] = $transcation_info1;
              $transcation_list_info[$record->id] = $transcation_info;
               $referral_info = $this->user_model->getrefferal($record->r_id);
               
            }
             
           $cities [$data['userInfo'][0]->city] = $this->user_model->getCityName($data['userInfo'][0]->city); 
           $states [$data['userInfo'][0]->state] = $this->user_model->getStateName($data['userInfo'][0]->state);
        }
        $data['city'] = $cities;
        $data['state'] = $states;
        $data['referral_info']=$referral_info;
        $data['transcation_list_info1']=$transcation_list_info1;
        $data['transcation_list_info']=$transcation_list_info;
        $this->global['pageTitle'] = 'Expect11 : View User';
        
        $this->loadViews("viewAppUser", $this->global, $data, NULL);
    }
    
    /** Update User Status**/
    function userStatus(){
        $id= $_POST['user_id'];
        $status=$_POST['user_status'];
       
        if($status =='ACTIVE'){
                 $data = array(
                    'status' =>'INACTIVE'
                );
                
                 $user_info = $this->user_model->getUser($id);
                 $name = $user_info[0]->name;
                $to = $user_info[0]->email;
                
                $date = date("d-m-Y");

                $this->subject = "Account Suspended!";
                 $msg ="Your Account has been Suspended  on ' . $date . '";
                                             $email_data =array(
                                                 'name' =>$name,
                                                 'msg' =>$msg,
                                                 
                                             );
                $message = $this->load->view('emailView',$email_data,TRUE);
                                                
                                            
               
                mail($to, $this->subject, $message, $this->headers);

                
                $this->user_model->updateStatus($data,$id);
                redirect('viewAppUser/'.$id);
        }
         else if($status =='INACTIVE'){
                 $data = array(
                    'status' =>'ACTIVE'
                );
                
                 $user_info = $this->user_model->getUser($id);
                 $name = $user_info[0]->name;
                $to = $user_info[0]->email;
                
                $date = date("d-m-Y");

                $this->subject = "Account UnSuspended!";
                 $msg ="Your Account has been Resumed  on ' . $date . '";
                                             $email_data =array(
                                                 'name' =>$name,
                                                 'msg' =>$msg,
                                                 
                                             );
                $message = $this->load->view('emailView',$email_data,TRUE);
                                                
                                            
                
                mail($to, $this->subject, $message, $this->headers);

                
                $this->user_model->updateStatus($data,$id);
                redirect('viewAppUser/'.$id);
        }
        
       
        
    }

    /**
     * This function is used to load the add new form
     */
    function addNew()
    {
        
            $data['roles'] = $this->user_model->getUserRoles();
            
            $this->global['pageTitle'] = 'Expect11 : Add New User';

            $this->loadViews("addNew", $this->global, $data, NULL);
       
    }

    /**
     * This function is used to check whether email already exist or not
     */
    function checkEmailExists()
    {
        $userId = $this->input->post("userId");
        $email = $this->input->post("email");

        if(empty($userId)){
            $result = $this->user_model->checkEmailExists($email);
        } else {
            $result = $this->user_model->checkEmailExists($email, $userId);
        }

        if(empty($result)){ echo("true"); }
        else { echo("false"); }
    }
    
    /**
     * This function is used to add new user to the system
     */
    function addNewUser()
    {
      
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('fname','Full Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean|max_length[128]');
            $this->form_validation->set_rules('password','Password','required|max_length[20]');
            $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]|max_length[20]');
            $this->form_validation->set_rules('role','Role','trim|required|numeric');
            $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNew();
            }
            else
            {
                $name = ucwords(strtolower($this->input->post('fname')));
                $email = $this->input->post('email');
                $password = $this->input->post('password');
                $roleId = $this->input->post('role');
                $mobile = $this->input->post('mobile');
                
                $userInfo = array('email'=>$email, 'password'=>getHashedPassword($password), 'roleId'=>$roleId, 'name'=> $name,
                                    'mobile'=>$mobile, 'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:s'));
                
                $result = $this->user_model->addNewUser($userInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New User created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'User creation failed');
                }
                
                redirect('addNew');
            }
        
    }

    
    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOld($userId = NULL)
    {
       
            if($userId == null)
            {
                redirect('userListing');
            }
            
            $data['roles'] = $this->user_model->getUserRoles();
            $data['userInfo'] = $this->user_model->getUserInfo($userId);
            
            $this->global['pageTitle'] = 'Expect11 : Edit User';
            
            $this->loadViews("editOld", $this->global, $data, NULL);
        
    }
    
    
    /**
     * This function is used to edit the user information
     */
    function editUser()
    {
        
            $this->load->library('form_validation');
            
            $userId = $this->input->post('userId');
            
            $this->form_validation->set_rules('fname','Full Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean|max_length[128]');
            $this->form_validation->set_rules('password','Password','matches[cpassword]|max_length[20]');
            $this->form_validation->set_rules('cpassword','Confirm Password','matches[password]|max_length[20]');
            $this->form_validation->set_rules('role','Role','trim|required|numeric');
            $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->editOld($userId);
            }
            else
            {
                $name = ucwords(strtolower($this->input->post('fname')));
                $email = $this->input->post('email');
                $password = $this->input->post('password');
                $roleId = $this->input->post('role');
                $mobile = $this->input->post('mobile');
                
                $userInfo = array();
                
                if(empty($password))
                {
                    $userInfo = array('email'=>$email, 'roleId'=>$roleId, 'name'=>$name,
                                    'mobile'=>$mobile, 'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
                }
                else
                {
                    $userInfo = array('email'=>$email, 'password'=>getHashedPassword($password), 'roleId'=>$roleId,
                        'name'=>ucwords($name), 'mobile'=>$mobile, 'updatedBy'=>$this->vendorId, 
                        'updatedDtm'=>date('Y-m-d H:i:s'));
                }
                
                $result = $this->user_model->editUser($userInfo, $userId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'User updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'User updation failed');
                }
                
                redirect('userListing');
            }
        
    }

    
    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deleteUser()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $userId = $this->input->post('userId');
            $userInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            
            $result = $this->user_model->deleteUser($userId, $userInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
    
    /**
     * This function is used to load the change password screen
     */
    function loadChangePass()
    {
        $this->global['pageTitle'] = 'Expect11 : Change Password';
        
        $this->loadViews("changePassword", $this->global, NULL, NULL);
    }
    
    
    /**
     * This function is used to change the password of the user
     */
    function changePassword()
    {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('oldPassword','Old password','required|max_length[20]');
        $this->form_validation->set_rules('newPassword','New password','required|max_length[20]');
        $this->form_validation->set_rules('cNewPassword','Confirm new password','required|matches[newPassword]|max_length[20]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->loadChangePass();
        }
        else
        {
            $oldPassword = $this->input->post('oldPassword');
            $newPassword = $this->input->post('newPassword');
            
            $resultPas = $this->user_model->matchOldPassword($this->vendorId, $oldPassword);
            
            if(empty($resultPas))
            {
                $this->session->set_flashdata('nomatch', 'Your old password not correct');
                redirect('loadChangePass');
            }
            else
            {
                $usersData = array('password'=>getHashedPassword($newPassword), 'updatedBy'=>$this->vendorId,
                                'updatedDtm'=>date('Y-m-d H:i:s'));
                
                $result = $this->user_model->changePassword($this->vendorId, $usersData);
                
                if($result > 0) { $this->session->set_flashdata('success', 'Password updation successful'); }
                else { $this->session->set_flashdata('error', 'Password updation failed'); }
                
                redirect('loadChangePass');
            }
        }
    }

    function pageNotFound()
    {
        $this->global['pageTitle'] = 'Expect11 : 404 - Page Not Found';
        
        $this->loadViews("404", $this->global, NULL, NULL);
    }

    function showTransaction(){
         $user_id= $this->input->post('user_id');
        $txn_type=$this->input->post('txn_type');
        $all_transaction = $this->transaction_model->getAllTransaction($user_id,$txn_type);
        
        $i=1;
        echo "<center><tr>
                       <th> Sr No</th>
                        <th>Transaction Date</th>
                        <th>Transaction Id</th>
                        <th> Transaction Amount</th>
                        <th>Transaction Msg</th>
                        <th>Txn Status</th>

                       
                      </tr></center>";
        foreach($all_transaction as $row1)
        {
            echo  "<center>
            <table border='0' style='width:88%;' class='table table-hover' id='appUserTbl1'> 

                    <tr>
                        <td class='print-clean' style='width:70px;'><center>$i</center></td>"; ?>
                        <td style='width:120px;' class='print-clean'><center><?php echo date("d-m-Y H:i:s", strtotime($row1['txn_dt']));?></center></td>
                        <td width='100px;'><center><?php echo $row1['txn_id'];?></center></td>
                        
                        <td width='140px;' class='print-clean'><center><?php echo $row1['txn_amt'];?></center></td>
                        <td width='150px;' class='print-clean'><center><?php echo strtoupper($row1['txn_msg']);?></center></td>
                        <td width='150px;' class='print-clean'><center><?php echo strtoupper($row1['txn_status']);?></center></td>
                    <?php echo "</tr>
                    </table>
                </center>";
                $i=$i+1;
        }
        //redirect('viewAppUser/'.$user_id);
    }
     

}

?>