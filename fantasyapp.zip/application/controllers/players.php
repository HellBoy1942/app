<?php 

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Match (PlayersController)
 * Players Class to manage all match related operations.
 */
class Players extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn(); 
        $this->load->model('players_model');
    }

    /**
     * This function is used to load the player list
     */
    function playerListing()
    {

       
        
            $country = $this->input->post('country');
            if ($country) {
                $data['country'] = $country;   
                $country = ucfirst($country);
                $player_records = $this->players_model->getPlayersByCountry($country);
                $data['player_records'] = $player_records;
            } else {
                $data['country'] = '';
                $data['player_records'] = array();
            }

            $player_country = $this->players_model->getCountryList();
            $data['country_list'] = $player_country;

            $this->global['pageTitle'] = 'Expect11 : Player Listing';
            
            $this->loadViews("players", $this->global, $data, NULL);
       
    }

/** add new players**/
function addNewPlayer()
    {
        
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('name','Players Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('p_id','Player Id','trim|required|xss_clean');
            $this->form_validation->set_rules('credit','Credit','trim|required|xss_clean|callback_compareDate');
            
            
            if($this->form_validation->run() == FALSE)
            {
                $this->newPlayer();
            }
            else
            {
                $name = ucwords(strtolower($this->input->post('name')));
                $p_id = $this->input->post('p_id');
                $credit = $this->input->post('credit');
                $country = $this->input->post('country');
                $playing_role = $this->input->post('playing_role');
             
               if($this->players_model->checkPlayerIdExists($p_id))
                {
                     $data = array(
                        'name' => $name, 
                        'credit'=>$credit,
                        'country'=>$country,
                        'playing_role' => $playing_role
                    );
                   
                    $result = $this->players_model->updatePlayer($data,$p_id); 
                }
                else{
                
                    $data = array(
                        'name' => $name, 
                        'credit'=>$credit,
                        'country'=>$country,
                        'p_id'=>$p_id,
                        'playing_role' => $playing_role
                    );
                    
                    
                    
                    $result = $this->players_model->addNewPlayers($data);
                    
                    if($result > 0)
                    {
                        $this->session->set_flashdata('success', 'New Playerss added successfully');
                    }
                    else
                    {
                        $this->session->set_flashdata('error', 'Players addition failed');
                    }
                }
                redirect('playerListing');
            }
        //}
    }
    /**
     * This function is used load player edit information
     * @param number $id : Optional : This is player id
     */
    function editPlayercredits($id = NULL)
    {
        
            if($id == null)
            {
                redirect('upcommingMatches');
            }

            

            $playerInfo = $this->players_model->getPlayersByPid($id);
            $data['player_info'] = $playerInfo;

            $player_country = $this->players_model->getCountryList();
            $data['country_list'] = $player_country;
            
            $this->global['pageTitle'] = 'Expect11 : Edit Player Credits';
            
            $this->loadViews("editPlayercredits", $this->global, $data, NULL);
        
    }

    /** this function is used to edit player credits**/
    function editPlayerpoint(){

        
            if($id == null)
            {
                redirect('upcommingMatches');
            }

            

            $playerInfo = $this->players_model->getPlayersByPid($id);
            $data['player_info'] = $playerInfo;

            $player_country = $this->players_model->getCountryList();
            $data['country_list'] = $player_country;
            
            $this->global['pageTitle'] = 'Expect11 : Edit Player Credits';
            
            $this->loadViews("editPlayerpoints", $this->global, $data, NULL);
        
    }


    /**
     * This function is used to edit the player information
     */
    function editPlayer()
    {
        
            $this->load->library('form_validation');
            
              
                 $id = $_GET['id']; 
                 $credit = $_GET['credit'];
                  $playing_role = $_GET['playing_role'];
                //print_r($playing_role);
                
                $data = array(
                    'credit' => $credit,
                   
                    'playing_role' => $playing_role
                );
                                
               
                $result = $this->players_model->editPlayer($data, $id);
                //print_r($result);
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Player updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Player updation failed');
                }
                
                //redirect('playerListing');
            
        
    }

    /**
     * This function is used to delete old player
     * @param number $pid : This is player id
     */
    function deleteOldPlayer ($pid = null) {
        
            if ($pid == null) {
                redirect('playerListing');
            }

           
            $id = $this->players_model->deletePlayer($pid);

            if ($id) {
                $this->session->set_flashdata('success', 'Player deleted successfully');
            } else {
                $this->session->set_flashdata('error', 'Player deletion failed');
            }
            redirect('playerListing');
        
    }

    function playerListingAjax(){
        
         $country = $_GET['country'];
         //print_r($country);
        if ($country) {
                $data['country'] = $country;   
                $country = ucfirst($country);
                $player_records = $this->players_model->getPlayersByCountry($country);
                //print_r($player_records);
                $data['player_records']=$player_records;

              //print_r($data['player_records']);
            }

            $this->load->view('ajax_player',$data);
    }
    
    function playerSearchAjax(){
        
         $name = $_POST['name'];
        
        if ($name) {
            $data['name'] = $name;  
             $this->config->load('config');

             $data['match_api_key'] = $this->config->item('match_api_key');

                $data = array(
                    'apikey' => $data['match_api_key'],
                    'name' => $data['name']

                );

                $data_string = json_encode($data);

                $curl = curl_init('http://cricapi.com/api/playerFinder');

                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data_string))
                );

                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);  // Make it so the data coming back is put into a string
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);  // Insert the data
                // Send the request
                $result = curl_exec($curl);

                // Free up the resources $curl is using
                curl_close($curl);
                 $players_name = json_decode($result); 
                      
                 $allPlayers = $players_name->data;
                 $data['player_records1'] = $allPlayers;
                
                    
                 $i=1;
                 
           echo "<center><tr>
                        <th style='font-weight:bold;'>Sr No</th>
                        <th style='font-weight:bold;' >Player ID</th>
                        <th style='font-weight:bold;' >Player Name</th>
                       
                        
                      </tr></center>";
            foreach($allPlayers as $row1)
            { 
                echo  "<center>
                <table border='0' style='width:100%;' class='table table-hover' id='appUserTbl1'> 
                   
                    <tr>
                        <td class='print-clean' style='width:70px;'><center>$i</center></td>"; ?>
                        <td width='100px;'><center><?php echo $row1->pid;?></center></td>
                        <td style='width:120px;' class='print-clean'><center><?php echo $row1->name;?></center></td>
                      
                       
                        <?php echo "</tr>
                    </table>
                </center>";
                $i=$i+1;
            } 
        }

            
    }

}

?>