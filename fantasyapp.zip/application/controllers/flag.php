<?php 

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Flag (FlagController)
 * Flag Class to manage all flag related operations.
 */
class Flag extends BaseController
{
    // helo world sadsad
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();
        $this->load->model('flag_list_model');
    }
    

    /**
     * This function is used to load the flag list
     */
    function flagListing()
    {
        
             
            $flaglist = $this->flag_list_model->flagdetaillist();
            $data['flaglist'] = $flaglist;

            $this->global['pageTitle'] = 'Expect11 : Team Flag';            
            $this->loadViews("flag", $this->global, $data, NULL);
       
    }

    /**
     * This function is used to load the add new league form
     */
    function newflag()
    {
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {*/
            
            
            

            $this->global['pageTitle'] = 'Expect11 : Add New Flag';

            $this->loadViews("newFlag", $this->global,  NULL);
        //}
    }

   
    /**
     * This function is used to add new flag to the system
     */
    function addNewFlag()
    {
        
       
             $config = array();
                    $config['upload_path'] = './uploads/';
                    $config['allowed_types'] = 'gif|jpg|png';
                    $config['max_size']      = '0';
                    $config['overwrite']     = FALSE;
           
            $this->load->library('form_validation', $config);
       

            $this->form_validation->set_rules('team_name','Team Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('short_name','Short Name','trim|required|max_length[128]|xss_clean');
              if ($this->form_validation->run() == FALSE)
               {
                $this->newFlag();
               } 
                else 
                {
                        $this->load->library('upload', $config);

                       
                        if($_FILES)
                        {
                            //print_r($_FILES);
                            $files = $_FILES;
                            $_FILES['image_name']['name'];
                           
                            
                            $this->upload->initialize($config);
                            $this->upload->do_upload('image_name');
                            $dataInfo = $this->upload->data();
                            $image= $dataInfo['file_name'];

                        }
                    
                        $data =array(
                            'image_name'=>$image,
                            'team_name'=>$this->input->post('team_name'),
                            'short_name'=>$this->input->post('short_name')
                        );
                        //print_r($data);die;
                }
          
                        
                        $flag_id = $this->flag_list_model->addNewFlag($data);
                        if($flag_id > 0)
                        {
                            $this->session->set_flashdata('success', 'New Flag added successfully');
                        }
                        else
                        {
                            $this->session->set_flashdata('error', 'Flag addition failed');
                        }
                
                    redirect('flagListing');

            
            //}
        
    }
    private function set_upload_options()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']      = '500';
        $config['overwrite']     = FALSE;


        return $config;
    }

    /**
     * This function is used load league edit information
     * @param number $id : Optional : This is league id
     */
    function editOldFlag($id = NULL)
    {
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {*/
            if($id == null)
            {
                redirect('flagListing');
            }
            
            

            $flagInfo_edit = $this->flag_list_model->getflagInfo($id);
            $data['flag_info_edit'] = $flagInfo_edit;

           


            $this->global['pageTitle'] = 'Expect11 : Edit Flag';
            
            $this->loadViews("editOldFlag", $this->global, $data, NULL);
        //}
    }

    function editFlag() {
        /*if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {*/
            $this->load->library('form_validation');

            $id = $this->input->post('flag_id');

            $this->form_validation->set_rules('team_name', 'Team Name', 'trim|required|xss_clean');
            
           

            if ($this->form_validation->run() == FALSE) {
                $this->editOldFlag($id);
            } else {

                $image_name_data = json_decode($this->do_upload('image_name'));
                

                $team_name = $this->input->post('team_name');
                $short_name = $this->input->post('short_name');

                $data = array(
                    'team_name' => $team_name,
                    'short_name' =>$short_name
                    
                );

                if (isset($image_name_data->status->file_name) && !empty($image_name_data->status->file_name)) {
                    $data['image_name'] = $image_name_data->status->file_name;
                    //print $image_name_data->status->full_path;
                }

               
                
                $result = $this->flag_list_model->editflag($data, $id);

                if ($result > 0) {
                    $this->session->set_flashdata('success', 'Flag updated successfully');
                } else {
                    $this->session->set_flashdata('error', 'Flag updation failed');
                }

                redirect('editOldFlag');
            }
        //}
    }


    function deleteOldFlag($id = NULL) {
       
            
            if($id == NULL)
            {
                redirect('flagListing');
            }
           
            $id = $this->flag_list_model->deleteFlag($id);

            if ($id) {
                $this->session->set_flashdata('success', 'Flag deleted successfully');
            } else {
                $this->session->set_flashdata('error', 'Flag deletion failed');
            }
            redirect('flagListing');
      
    }
    
    function do_upload($file_name = "") {

        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|gif|png';
        $config['overwrite'] = TRUE;
        $config['max_size'] = '8048';

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload($file_name)) {
            $status = 'error';
            $msg = $this->upload->display_errors('', '');
        } else {
            $status = 'success';
            $image_data = $this->upload->data(); //get image data          
            $msg = $image_data;
        }
        if ($status == 'success') {
            $config = array(
                'source_image' => $image_data['full_path'], //get original image
                'new_image' => './uploads/', //save as new image //need to create thumbs first
                'overwrite' => TRUE,
                'maintain_ratio' => TRUE,
                'width' => 630,
                'height' => 340,
            );
        
        }

        return json_encode(array(
            'status' => $msg
        ));
    }
  }  
?>