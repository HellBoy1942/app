<?php 
error_reporting(0);

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Series (SeriesController)
 * Series Class to manage all series related operations.
 */
class Contest extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn(); 
        $this->load->model('contest_model');
    }

    /**
     * This function is used to load the series list
     */
    function typeListing()
    {

       
            
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->contest_model->typeListingCount($searchText);

			$returns = $this->paginationCompress ( "typeListing/", $count, 10 );

            
            $typeRecords = $this->contest_model->typeListing($searchText, $returns["page"], $returns["segment"]);
             
           
            $data['typeRecords'] = $typeRecords;
            //print_r( $data['typeRecords']);
            
            
            $this->global['pageTitle'] = 'play11 :Contest Type Listing';
            
            $this->loadViews("contesttype", $this->global, $data, NULL);
       
    }

    /**
     * This function is used to load the add new form
     */
    function newcontestType()
    {
       
            $data = array();
            $this->global['pageTitle'] = 'play11 : Add New Contest Type';

            $this->loadViews("newcontestType", $this->global, $data, NULL);
       
    }
    
   

     /**
     * This function is used to add new series to the system
     */       
    function addnewcontestType()
    {
        
           $config = array();
                    $config['upload_path'] = './uploads/';
                    $config['allowed_types'] = 'gif|jpg|png';
                    $config['max_size']      = '0';
                    $config['overwrite']     = FALSE;
           
            $this->load->library('form_validation', $config);
       

            
            $this->form_validation->set_rules('league_type','Type','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('status','Status','trim|required|xss_clean');
             $this->form_validation->set_rules('arrange','Arrange','trim|required|xss_clean');
            $this->form_validation->set_rules('type','Name','trim|required|max_length[128]|xss_clean');
           
            $this->form_validation->set_rules('slug','Slug','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->newcontesttype();
            }
            else
            {
                 $this->load->library('upload', $config);

                       
                        if($_FILES)
                        {
                           
                            $files = $_FILES;
                            $_FILES['logo']['name'];
                           
                            
                            $this->upload->initialize($config);
                            $this->upload->do_upload('logo');
                            $dataInfo = $this->upload->data();
                            $image= $dataInfo['file_name'];
                            

                        }
                    
               
                
                $data = array(
                    'league_name' =>ucwords($this->input->post('type')), 
                    'slug' =>$this->input->post('slug'), 
                    'arrange' =>$this->input->post('arrange'),
                   'image'=>$image,
                    'status' =>$this->input->post('status'),
                     'type' =>$this->input->post('league_type')
                );
               
                
                
                
                $result = $this->contest_model->addnewcontesttype($data);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Contest Type added successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Contest Type addition failed');
                }
                
                redirect('typeListing');
            }
        
    }

 private function set_upload_options()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']      = '500';
        $config['overwrite']     = FALSE;


        return $config;
    }
    
     function do_upload($file_name = "") {

        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|gif|png';
        $config['overwrite'] = TRUE;
        $config['max_size'] = '8048';

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload($file_name)) {
            $status = 'error';
            $msg = $this->upload->display_errors('', '');
        } else {
            $status = 'success';
            $image_data = $this->upload->data(); //get image data          
            $msg = $image_data;
        }
        if ($status == 'success') {
            $config = array(
                'source_image' => $image_data['full_path'], //get original image
                'new_image' => './uploads/', //save as new image //need to create thumbs first
                'overwrite' => TRUE,
                'maintain_ratio' => TRUE,
                'width' => 630,
                'height' => 340,
            );
            //$this->load->library('image_lib', $config); //load library
            //$this->image_lib->resize(); //do whatever specified in config
            // $data = array(
            //     'type'  => 'banner',
            //     'created'   => date("Y-m-d H:i:s", now()),
            //     'status'    => 'active',
            //     'banner'    => $image_data['file_name'] 
            // );
            // $id = $this->Banners_model->save($data);
        }



        return json_encode(array(
            'status' => $msg
        ));
    }
    /**
     * This function is used load series edit information
     * @param number $id : Optional : This is series id
     */
    function editOldType($id = NULL)
    {
        
            if($id == null)
            {
                redirect('typeListing');
            }
            
            
            $typeInfo = $this->contest_model->getTypeInfo($id);
            $data['type_Info'] = $typeInfo;
            
            
            $this->global['pageTitle'] = 'play11 : Edit Type';
            
            $this->loadViews("editOldType", $this->global, $data, NULL);
       
    }

    

    

    /**
     * This function is used to edit the series information
     */
    function editType()
    {
        
            $this->load->library('form_validation');
            
            $id = $this->input->post('id');
            
          
            $this->form_validation->set_rules('status','Status','trim|required|xss_clean');
            $this->form_validation->set_rules('arrange','Arrange','trim|required|xss_clean');
            
            $this->form_validation->set_rules('slug','Slug','trim|required|xss_clean');
            if($this->form_validation->run() == FALSE)
            {
                $this->editOldType($id);
            }
            else
            {
                 $image_name_data = json_decode($this->do_upload('logo'));
                
                $league_name = ucwords($this->input->post('type'));
                $slug = $this->input->post('slug');
                $arrange = $this->input->post('arrange');
                $status = $this->input->post('status');
                
                $data = array(
                    'league_name' => $league_name, 
                    'slug'=>$slug, 
                    'arrange'=>$arrange,
                    'status' => $status
                );
            
                 if (isset($image_name_data->status->file_name) && !empty($image_name_data->status->file_name)) {
                    $data['image'] = $image_name_data->status->file_name;
                   
                }

                
                
                $result = $this->contest_model->editType($data, $id);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Contest Type updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Contest Type updation failed');
                }
                
                redirect('typeListing');
            }
       
    }
    function delType($value='')
    {
        if ($value == NULL) {
            redirect('typeListing');
        }
        if($this->contest_model->deltype($value)){
             $this->session->set_flashdata('success', 'League Type deleted successfully');
        } else {
            $this->session->set_flashdata('error', 'League Type deletion failed');
        }
        redirect('typeListing');

    }

}

?>