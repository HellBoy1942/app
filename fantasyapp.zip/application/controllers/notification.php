<?php 

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Match (NotificationController)
 * Players Class to manage notification related operations.
 */
class Notification extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();
         $this->load->model('user_model');
            $this->load->model('notification_model');
        $this->config->load('config');
        $this->_url = $this->config->item('notify_url');
    }

    /**
     * This function is used to load send notification form
     */
    function send_notification()
    {
           
            $users = $this->user_model->getUsers();
            $notification_list = $this->notification_model->notificationListing();
        	$data['notification_list'] = $notification_list;
        	$data['users'] = $users;
            $this->global['pageTitle'] = 'Expect11 : Send Notification';            
            $this->loadViews("notification", $this->global, $data, NULL);
       
    }

    /**
     * This function is used to send notification
     */
    function notify_user()
    {
    
    	$data = $this->input->post();
        $userids =  $data['user'];
        $output_data=array();
        $output='';
   
    
    	if (!empty($userids)) {
    		foreach ($userids as $i => $userid) {
              
    			$postData = '';
    			$params = array(
    				'title' => $data['title'],
    				'msg' => $data['message'],
    				'image' => null,
    				'user_id' => $userid
    			);
    			$postData = http_build_query($params);

    		    $ch = curl_init();
    		    curl_setopt($ch, CURLOPT_URL,$this->_url);
    		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    		    curl_setopt($ch, CURLOPT_HEADER, false); 
    		    curl_setopt($ch, CURLOPT_POST, count($postData));
    		    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    

    		    $output = curl_exec($ch);
    		    $output_data [] = json_decode($output);
    		    curl_close($ch);
                
                
                $params = array(
                    'title' => $data['title'],
                    'message' => $data['message'],
                    'user_id' => $userid
                );
                
                $nid = $this->notification_model->addNewNotification($params);
    		}
    	}
    	if (!empty($output_data)) {
    		$this->session->set_flashdata('success', 'Notification sent successfully ');
    	} else {
    		$this->session->set_flashdata('error', 'Notification sent failed');
    	}
    	redirect('send_notification');
    	
    }

}

?>