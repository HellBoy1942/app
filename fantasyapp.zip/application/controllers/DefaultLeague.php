<?php 

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : DefaultLeague (LeagueController)
 * League Class to manage all league related operations.
 */
class DefaultLeague extends BaseController
{
    // helo world sadsad
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();   
    }
    

    /**
     * This function is used to load the league list
     */
    function defaultleagueListing()
    {

        
            $this->load->model('defaultleague_model');

            $this->load->model('match_model');
            $match_list = $this->match_model->getMatchList();
            $data['match_list'] = $match_list;
            $all_match_list = $this->match_model->getAllMatch();
            $data['all_match_list'] = $all_match_list;

            $match_id = (isset($_GET['match_id']) ? $_GET['match_id'] : null);
            
            if ($match_id != "") {
                $searchText = $match_id;
            } else {
                $searchText = $this->input->post('searchText');    
            }
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');

            
            $count = $this->defaultleague_model->defaultleagueListingCount($searchText);

            $returns = $this->paginationCompress ( "defaultleagueListing/", $count, 5 );
            
            $leagueRecords = $this->defaultleague_model->defaultleagueListing($searchText);
            
            
            $data['leagueRecords'] = $leagueRecords;
            //print_r($data['leagueRecords']);
            

            $join_team_count = array();
            foreach ($leagueRecords as $league) {
                $this->load->model('joined_league_model');
                $teams_list = $this->joined_league_model->getByLeague($league->id);
                $join_team_count[$league->id] = count($teams_list);
            }

            $data['join_team_count'] = $join_team_count;

            $this->global['pageTitle'] = 'Expect11 : Default League Listing';
            
            $this->loadViews("defaultleague", $this->global, $data, NULL);
       
    }

    /**
     * This function is used to load the add new league form
     */
    function newdefaultLeague()
    {
        
            $data = array();
            
            $this->load->model('match_model');
            $match_list = $this->match_model->getMatchList('UPCOMING');
            $data['match_list'] = $match_list;

            $this->global['pageTitle'] = 'Expect11 : Add New Default League';

            $this->loadViews("newLeague", $this->global, $data, NULL);
        
    }

    /**
     * This function is used to get matchlist by type
     */
    function getMatchList()
    {
       
            $type = $this->input->post('match_type');
            $match_list = array();
            $this->load->model('match_model');
            if (!empty($type)) {                
                $match_list = $this->match_model->getMatchList($type);
            } else {
                $match_list = $this->match_model->getMatchList();
            }
            echo json_encode(array("type" => $type, "match_list" => $match_list));
            die();
        
    }
    
    /**
     * This function is used to add new league to the system
     */
   function addNewdefaultLeague()
    {
        
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('name','League Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('league_type','League Type','trim|required|xss_clean');
            $this->form_validation->set_rules('match','Match','required');

            $this->form_validation->set_rules('win_amount','Winning Amount','trim|xss_clean');
            $this->form_validation->set_rules('size','Size','trim|xss_clean');
            $this->form_validation->set_rules('margin','Margin','trim|xss_clean');
            $this->form_validation->set_rules('entry_fees','Entry Fees','trim|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->newLeague();
            }
            else
            {
                
                $name = ucwords(strtolower($this->input->post('name')));
                $league_type = $this->input->post('league_type');
                $match = $this->input->post('match');
                $win_amount = $this->input->post('win_amount');
                $size = $this->input->post('size');
                $margin = $this->input->post('margin');
                $entry_fees = $this->input->post('entry_fees');
                $set_of_winners = $this->input->post('set_of_winners');

                $data = array(
                    'name' => $name,
                    'match_id' => $match, 
                    'type' => $league_type, 
                    'winning_amount' => $win_amount,
                    'contest_size' => $size,
                    'commission' => $margin,
                    'entry_fees' => $entry_fees,
                    'winner' => $set_of_winners,
                    'is_default'=>'yes'
                );
                
                $this->load->model('league_model');
                $leage_id = $this->league_model->addNewLeague($data);

                if (!empty($set_of_winners) && $leage_id) {

                    $this->load->model('winners_model');

                    $ranks_per = array();
                    $rank_amounts = array();
                    $i = $set_of_winners;
                    for ( $i = 0; $i <= $set_of_winners; $i++) {
                        $rank = $i + 1; 
                        $rank_per_name = 'percen_' . $i;
                        $rank_amt_name = 'rank_amt_' . $i;
                        if ($rank <= $set_of_winners) {
                            $ranks_per[$rank] = $this->input->post($rank_per_name);
                            $rank_amounts[$rank] = $this->input->post($rank_amt_name);
                        }
                    }
                    

                    // $rank_amt = ($win_amount/$set_of_winners);
                    // $rank_percentage = ($rank_amt * 100) / $win_amount;
                    if (!empty($ranks_per) && !empty($rank_amounts)) {
                        for($i=0; $i < $set_of_winners; $i++) {
                            $rank = $i + 1;
                            if ($rank <= $set_of_winners) {
                                $wdata = array(
                                    'contest_id' => $leage_id,
                                    'rank' => $rank,
                                    'set_of_winners' => $set_of_winners, 
                                    'winning_percent' => $ranks_per[$rank],
                                    'winning_amount' => $rank_amounts[$rank]
                                );

                                $winner_id = $this->winners_model->addWinnerList($wdata);
                            }
                        }
                    }
                }
                
                if($leage_id > 0)
                {
                    $this->session->set_flashdata('success', 'New Default League added successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', ' Default League addition failed');
                }
                
                redirect('newLeague');
            }
        
    }

    /**
     * This function is used load league edit information
     * @param number $id : Optional : This is league id
     */
    function editOldLeague($id = NULL)
    {
        
            if($id == null)
            {
                redirect('leagueListing');
            }
            $this->load->model('league_model');
            $this->load->model('winners_model');

            $winnersInfo = $this->winners_model->getWinnersByLeague($id);
            $data['winners_info'] = $winnersInfo;

            $leagueInfo = $this->league_model->getLegueInfo($id);
            $data['league_info'] = $leagueInfo;

            $this->load->model('match_model');
            $match_list = $this->match_model->getMatchList('UPCOMING');
            $data['match_list'] = $match_list;


            $this->global['pageTitle'] = 'Expect11 : Edit League';
            
            $this->loadViews("editOldLeague", $this->global, $data, NULL);
        
    }

    /**
     * This function is used to display joined teams of specified league
     * @param number $id : This is league id
     */
    function joined_teams ($id) {

        if($id == null)
        {
            $this->session->set_flashdata('error', 'Please choose a league');
            redirect('leagueListing');
        }
        $this->load->model('joined_league_model');
        $teams_list = $this->joined_league_model->getByLeague($id);
        //$data['teams_list'] = $teams_list;
        
        $this->load->model('league_model');
        $league_info = $this->league_model->getLegueInfo($id);

        $joined_teams = array();
        if (!empty($teams_list)) {

            $this->load->model('teams_model');
            $this->load->model('user_model');
            $this->load->model('winners_model');
            
            foreach ($teams_list as $i => $teams) {
                $team_info = $this->teams_model->getByTeamId($teams->team_id);
                $team_info = $team_info[0];
                $user_info = $this->user_model->getUser($team_info->user_id);
                $joined_teams[$i]['id'] = $team_info->id;
                $joined_teams[$i]['team_name'] = $team_info->team_name;
                $joined_teams[$i]['joining_date'] = $team_info->created;
                $joined_teams[$i]['name'] = $user_info[0]->name;
                $joined_teams[$i]['user_id'] = $team_info->user_id;
                $joined_teams[$i]['rank'] = $team_info->rank;
                $joined_teams[$i]['points'] = $team_info->points;
                $winners_list = $this->winners_model->getWinnersByTeam($id, $team_info->rank);
                if(!empty($winners_list)) {
                    $joined_teams[$i]['winning_amount'] = $winners_list[0]->winning_amount;
                } else {
                    $joined_teams[$i]['winning_amount'] = 0;
                }
            }
        }
        $data['settled'] = $league_info[0]->settled;
        $data['league_id'] = $id;
        $data['joined_teams'] = $joined_teams;
        $this->global['pageTitle'] = 'Expect11 : Joined Teams';
        
        $this->loadViews("joined_teams", $this->global, $data, NULL);
    }


    /**
     * This function is used to display joined teams of specified league
     * @param number $id : This is league id
     */
    function winners_list ($id) {

        if($id == null)
        {
            $this->session->set_flashdata('error', 'Please choose a league');
            redirect('leagueListing');
        }
        $this->load->model('joined_league_model');
        $this->load->model('winners_model');
        $teams_list = $this->joined_league_model->getByLeague($id);
        //$winners_list = $this->winners_model->getWinnersByLeague($id);
        //$data['teams_list'] = $teams_list;
        
        $this->load->model('league_model');
        $league_info = $this->league_model->getLegueInfo($id);

        $joined_teams = array();
        if (!empty($teams_list)) {

            $this->load->model('teams_model');
            $this->load->model('user_model');
            
            foreach ($teams_list as $i => $teams) {
                $team_info = $this->teams_model->getByTeamId($teams->team_id);
                $team_info = $team_info[0];
                $user_info = $this->user_model->getUser($team_info->user_id);
                $winners_list = $this->winners_model->getWinnersByTeam($id, $team_info->rank);
                if(!empty($winners_list)) {
                    if ($winners_list[0]->winning_amount > 0) {
                        $joined_teams[$i]['id'] = $team_info->id;
                        $joined_teams[$i]['team_name'] = $team_info->team_name;
                        $joined_teams[$i]['joining_date'] = $team_info->created;
                        $joined_teams[$i]['name'] = $user_info[0]->name;
                        $joined_teams[$i]['user_id'] = $team_info->user_id;
                        $joined_teams[$i]['rank'] = $team_info->rank;
                        $joined_teams[$i]['points'] = $team_info->points;
                        $joined_teams[$i]['winning_amount'] = $winners_list[0]->winning_amount;
                    }
                }
            }
        }
        $data['settled'] = $league_info[0]->settled;
        $data['league_id'] = $id;
        $data['joined_teams'] = $joined_teams;
        $this->global['pageTitle'] = 'Expect11 : Winners List';
        
        $this->loadViews("winners_list", $this->global, $data, NULL);
    }


    /**
     * This function is used load players by team
     * @param number $id : Optional : This is team id
     */
    function viewPlayers($id = NULL) {
        /*if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {*/
            if ($id == null) {
                redirect('upcommingMatches');
            }
            $this->load->model('teams_model');
            $this->load->model('players_model');

            $teamInfo = $this->teams_model->getByTeamId($id);

            $players = array();
            $player_details = array();
            $player_pc_details = array();
            $players_data = array();
            $crew_data = array();

            foreach ($teamInfo as $team) {
                $players = explode(',', $team->player_id);
                $crew_data ['captain'] = $team->captain;
                $crew_data ['vc'] = $team->vice_captain;
            }
            if (!empty($players)) {
                foreach ($players as $pid) {
                    $player_details[] = $this->players_model->getPlayersByPid($pid)[0];                    
                    $player_pc_details[] = $this->players_model->getPcPlayersByPid($pid,$team->match_id)[0];
                }   
            }
            
            if (!empty($player_details)) {
                foreach ($player_details as $i => $player) {
                    $players_data [$i]['pid'] = $player->p_id;

                    $players_data [$i]['name'] = $player->name;
                    $players_data [$i]['country'] = $player->country;
                    // $playing_role = "";
                    // if ($player->playing_role == 'AR') {
                    //     $players_data [$i] = 'All Rounder';
                    // }
                    // if ($player->playing_role == 'AR') {
                    //     $players_data [$i] = 'All Rounder';
                    // }
                    // if ($player->playing_role == 'AR') {
                    //     $players_data [$i] = 'All Rounder';
                    // }
                    $players_data [$i]['role'] = $player->playing_role;
                    if ($player->p_id == $crew_data ['captain']) {
                        $players_data [$i]['points'] = $player_pc_details [$i]->points *2;
                    } else if ($player->p_id == $crew_data ['vc']) {
                        $players_data [$i]['points'] = $player_pc_details [$i]->points *1.5;
                    } else {
                        $players_data [$i]['points'] = $player_pc_details [$i]->points;
                    }

                }
            }
            $data['crew_data'] = $crew_data;
            $data['players_data'] = $players_data;
            $this->global['pageTitle'] = 'Expect11 : View Players';

            $this->loadViews("viewPlayers", $this->global, $data, NULL);
        //}
    }


    function getmicrotime() {
        list($usec, $sec) = explode(" ",microtime()); 
        return ((float)$usec + (float)$sec); 
    }

    /**
     * This function is used to settle match
     * @param number $id : This is league id
     */
    function settledMatch () {

        $id = $this->input->post('league_id');
        if($id == null)
        {
            $this->session->set_flashdata('error', 'Please choose a league');
            redirect('leagueListing');
        }
        $this->load->model('joined_league_model');
        $teams_list = $this->joined_league_model->getByLeague($id);
        //$data['teams_list'] = $teams_list;

        $joined_teams = array();
        if (!empty($teams_list)) {

            $this->load->model('teams_model');
            $this->load->model('user_model');
            $this->load->model('winners_model');
            $this->load->model('transaction_model');
            
            $trn_data = array();
            $trn_ids = array();
            foreach ($teams_list as $i => $teams) {

                $team_info = $this->teams_model->getByTeamId($teams->team_id);
                $team_info = $team_info[0];
                $user_info = $this->user_model->getUser($team_info->user_id);
                $winners_list = $this->winners_model->getWinnersByTeam($id, $team_info->rank);
                if (!empty($winners_list)) {
                    if ($winners_list[0]->winning_amount > 0) {
                        $trn_data = array(
                            'txn_id' => $this->getmicrotime(),
                            'user_id' => $team_info->user_id,
                            'txn_amt' => $winners_list[0]->winning_amount,
                            'txn_status' => 'SUCCESS',
                            'txn_type' => 'WINNING_AMOUNT'
                        );
                        $user_data = array(
                            'cash_winning' => $winners_list[0]->winning_amount + $user_info[0]->cash_winning
                        );
                        $trn_ids[] = $this->transaction_model->addTrans($trn_data);
                        $ud = $this->user_model->editAppUser($user_data, $team_info->user_id);
                    }
                }

                // $user_data = array(
                //     'wallet_amount' => $winners_list[0]->winning_amount + $user_info[0]->wallet_amount
                // );
                
            }
            if (count($trn_ids) > 0) {
                $this->load->model('league_model');
                $league_data = array(
                    'settled' => TRUE
                );
                $this->league_model->editLeague($league_data, $id);
                $this->session->set_flashdata('success', 'Settlement successfully completed');
            } else {
                $this->session->set_flashdata('error', 'Settlement Failed!');
            }
            redirect('leagueListing');
        } else {
           $this->session->set_flashdata('error', 'Insufficient Data');
           redirect('leagueListing'); 
        }
    }

    /**
     * This function is used to edit old league to the system
     */
    function editLeague()
    {
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {*/
            $this->load->library('form_validation');

            $id = $this->input->post('id');
            
            $this->form_validation->set_rules('name','League Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('league_type','League Type','trim|required|xss_clean');
            $this->form_validation->set_rules('match','Match','required');
            $this->form_validation->set_rules('win_amount','Winning Amount','trim|required|xss_clean');
            $this->form_validation->set_rules('size','Size','trim|required|xss_clean');
            $this->form_validation->set_rules('margin','Margin','trim|required|xss_clean');
            $this->form_validation->set_rules('entry_fees','Entry Fees','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->newLeague();
            }
            else
            {
                $name = ucwords(strtolower($this->input->post('name')));
                $league_type = $this->input->post('league_type');
                $match = $this->input->post('match');
                $win_amount = $this->input->post('win_amount');
                $size = $this->input->post('size');
                $margin = $this->input->post('margin');
                $entry_fees = $this->input->post('entry_fees');
                $set_of_winners = $this->input->post('set_of_winners');


                $edit_league = $this->input->post('edit_league');
                $delete_league = $this->input->post('delete_league');

                if (isset($edit_league) && !empty($edit_league)) {
                    $data = array(
                        'name' => $name,
                        'match_id' => $match, 
                        'type' => $league_type, 
                        'winning_amount' => $win_amount,
                        'contest_size' => $size,
                        'commission' => $margin,
                        'entry_fees' => $entry_fees
                    );
                
                    $this->load->model('league_model');
                    $result = $this->league_model->editLeague($data, $id);
                    
                    $this->load->model('league_model');
                    $leage_id = $this->league_model->addNewLeague($data);

                    if (!empty($set_of_winners) && $leage_id) {

                        $this->load->model('winners_model');
                        $delete_winners = $this->winners_model->deleteWinnersByLeague($id);
                        $ranks_per = array();
                        $rank_amounts = array();
                        $i = $set_of_winners;
                        for ( $i = 0; $i <= $set_of_winners; $i++) {
                            $rank = $i + 1; 
                            $rank_per_name = 'percen_' . $i;
                            $rank_amt_name = 'rank_amt_' . $i;
                            if ($rank <= $set_of_winners) {
                                $ranks_per[$rank] = $this->input->post($rank_per_name);
                                $rank_amounts[$rank] = $this->input->post($rank_amt_name);
                            }
                        }
                        

                        // $rank_amt = ($win_amount/$set_of_winners);
                        // $rank_percentage = ($rank_amt * 100) / $win_amount;
                        if (!empty($ranks_per) && !empty($rank_amounts)) {
                            for($i=0; $i < $set_of_winners; $i++) {
                                $rank = $i + 1;
                                if ($rank <= $set_of_winners) {
                                    $wdata = array(
                                        'contest_id' => $leage_id,
                                        'rank' => $rank,
                                        'set_of_winners' => $set_of_winners, 
                                        'winning_percent' => $ranks_per[$rank],
                                        'winning_amount' => $rank_amounts[$rank]
                                    );
                                    if ($delete_winners) {
                                        $winner_id = $this->winners_model->addWinnerList($wdata);
                                    }                                    
                                }
                            }
                        }
                    }


                    if($result > 0)
                    {
                        $this->session->set_flashdata('success', 'Updated League successfully');
                    }
                    else
                    {
                        $this->session->set_flashdata('error', 'League updation failed');
                    }
                }

                if (isset($delete_league) && !empty($delete_league)) {
                    $this->load->model('joined_league_model');
                    $teams_list = $this->joined_league_model->getByLeague($id);
                    if (empty($teams_list)) {
                        $this->load->model('league_model');
                        $deleted = $this->league_model->deleteLeague($id);                    
                        if ($deleted) {
                            $this->session->set_flashdata('success', 'League deleted successfully');
                        } else {
                            $this->session->set_flashdata('error', 'League deletion failed');
                        }
                    } else {
                        $this->session->set_flashdata('error', 'This league can not be deleted as it contains teams associated with it.');
                    }

                }                
                redirect('defaultleagueListing');
            //}
        }
    }

}
 function deleteOldLeague($id = NULL) {

        if ($id == NULL) {
            redirect('defaultleagueListing');
        }
        
        $this->load->model('defaultleague_model');
        $id = $this->defaultleague_model->deleteLeague($id);
       
        if ($id) {
            $this->session->set_flashdata('success', 'Default League deleted successfully');
        } else {
            $this->session->set_flashdata('error', 'Default League deletion failed');
        }
        redirect('defaultleagueListing');
        
    }

/*function leagueListingId($id = NULL){
     if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {
            if ($id == null) {
                redirect('upcommingMatches');
            }
            
            //print "<pre>" . print_r($player1, true) . "</pre>";
            //print "<pre>" . print_r($player2, true) . "</pre>";

           
            

            $leage_list = $this->league_model->getLegueByMatch($id);
            $leage_list_count = count($leage_list);
            $data['leage_list_count'] = $leage_list_count;

          

            $this->loadViews("league", $this->global, $data, NULL);
        }
}*/
?>