<?php 
error_reporting(0);

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Banner (BannerController)
 * Banner Class to manage all flag related operations.
 */
class Banner extends BaseController
{
    // helo world sadsad
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();  
        $this->load->model('banner_model');
    }
    

    /**
     * This function is used to load the flag list
     */
    function bannerListing()
    {

       
            
            $bannerlist_info = array();
            $bannerlist = $this->banner_model->bannerdetaillist();
            $data['bannerlist_info'] = $bannerlist;

            $this->global['pageTitle'] = 'Expect11 : Banner Management';            
            $this->loadViews("banner", $this->global, $data, NULL);
       
    }

    /**
     * This function is used to load the add new league form
     */
    function newbanner()
    {
           $this->global['pageTitle'] = 'Expect11 : Add New Banner';

            $this->loadViews("newBanner", $this->global,  NULL);
        
    }

   
    /**
     * This function is used to add new flag to the system
     */
    function addNewBanner()
    {
        
       
             $config = array();
                    $config['upload_path'] = './banners/';
                    $config['allowed_types'] = 'gif|jpg|png';
                   
                    $config['max_width']     = 1280;
                $config['max_height']         = 720;
                    $config['overwrite']     = FALSE;
           
            $this->load->library('form_validation', $config);
       

            $this->form_validation->set_rules('banner_type','Banner Type','trim|required|max_length[128]|xss_clean');
              if ($this->form_validation->run() == FALSE)
               {
                $this->newbanner();
               } 
                else 
                {
                        $this->load->library('upload', $config);

                       
                        if($_FILES)
                        {
                           
                            $files = $_FILES;
                            $_FILES['banner_name']['name'];
                           
                            
                            $this->upload->initialize($config);
                            $this->upload->do_upload('banner_name');
                            $dataInfo = $this->upload->data();
                            $image= $dataInfo['file_name'];

                        }
                    
                        $data =array(
                            'name'=>$image,
                            'banner_type'=>$this->input->post('banner_type')
                        );
                        
                }
          
                       
                        $banner_id = $this->banner_model->addNewBanner($data);
                        if($banner_id > 0)
                        {
                            $this->session->set_flashdata('success', 'New Banner added successfully');
                        }
                        else
                        {
                            $this->session->set_flashdata('error', 'Banner addition failed');
                        }
                
                    redirect('bannerListing');

            
            //}
        
    }
    private function set_upload_options()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = './banners/';
        $config['allowed_types'] = 'gif|jpg|png';
        
        $config['max_width']            = 1280;
         $config['max_height']           = 720;
        $config['overwrite']     = FALSE;


        return $config;
    }

    /**
     * This function is used load league edit information
     * @param number $id : Optional : This is league id
     */
    function editOldBanner($id = NULL)
    {
        
            if($id == null)
            {
                redirect('bannerListing');
            }
           
            $bannerInfo_edit = $this->banner_model->getbannerInfo($id);
            
    }

    function editBanner() {
        
            $this->load->library('form_validation');

            $id = $this->input->post('bn_id');
           $this->form_validation->set_rules('banner_type', 'Banner Type', 'trim|required|xss_clean');
            
           

            if ($this->form_validation->run() == FALSE) {
                $this->editOldBanner($id);
            } else 

            {
               
                $image_name_data = json_decode($this->do_upload('banner_name'));
                $banner_type = $this->input->post('banner_type');

                $data = array(
                    'banner_type' => $banner_type,
                    
                );
                
                if (isset($image_name_data->status->file_name) && !empty($image_name_data->status->file_name)) {
                    $data['name'] = $image_name_data->status->file_name;
                }

               
                $result = $this->banner_model->editBanner($data, $id);
                   
                if ($result>0) {
                    $this->session->set_flashdata('success', 'Banner updated successfully');
                } else {
                    $this->session->set_flashdata('error', 'Banner updation failed');
                }

                redirect('bannerListing');
            }
       
    }
    
    function statusChange(){

    
                $id = $this->input->post('id');
                 $status = $this->input->post('status');
                
                if ($status == 'ACTIVE') {
                      $data = array(
                        'status' => $status
                    ); 
                          
                $result = $this->banner_model->editBanner($data, $id); 
                   }
                else if($status == 'INACTIVE') { 
                $data = array(
                    'status' => $status
                );
                
              
                $result = $this->banner_model->editBanner($data, $id);

                }

               
                if ($result) {
                $this->session->set_flashdata('success', 'Thank you for you request. We will get back to you shortly.');
                } else {
                $this->session->set_flashdata('error', 'Something goes wrong. Please try again later.');
                } 
             redirect('bannerListing');

          
              
    }
    function deleteOldBanner($id = NULL) {
      
            if($id == NULL)
            {
                redirect('bannerListing');
            }
           
           
            $id = $this->banner_model->deletebanner($id);

            if ($id) {
                $this->session->set_flashdata('success', 'Banner deleted successfully');
            } else {
                $this->session->set_flashdata('error', 'Banner deletion failed');
            }
            redirect('bannerListing');
       
    }

    function do_upload($file_name = "") {

        $config['upload_path'] = './banners/';
        $config['allowed_types'] = 'jpg|jpeg|gif|png';
        $config['overwrite'] = TRUE;
        
        $config['max_width']  = 1280;
        $config['max_height'] = 720;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload($file_name)&& $height>720 && $width>1280) {
            $status = 'error';
            $msg = $this->upload->display_errors('', '');
        } else {
            $status = 'success';
            $image_data = $this->upload->data(); //get image data          
            $msg = $image_data;
        }
        if ($status == 'success') {
            $config = array(
                'source_image' => $image_data['full_path'], //get original image
                'new_image' => './banners/', //save as new image //need to create thumbs first
                'overwrite' => TRUE,
                'maintain_ratio' => TRUE,
                'width' => 1280,
                'height' => 720,
            );
            //$this->load->library('image_lib', $config); //load library
            //$this->image_lib->resize(); //do whatever specified in config
            // $data = array(
            //     'type'  => 'banner',
            //     'created'   => date("Y-m-d H:i:s", now()),
            //     'status'    => 'active',
            //     'banner'    => $image_data['file_name'] 
            // );
            // $id = $this->Banners_model->save($data);
        }



        return json_encode(array(
            'status' => $msg
        ));
    }
  }  
?>