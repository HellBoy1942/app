<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Bankverify (BankverifyController)
 * Bankverify Class to display bank verification related operations.
 */
class Bankverify extends BaseController {

    /**
     * This is default constructor of the class
     */
    public function __construct() {
        parent::__construct();
        $this->isLoggedIn();
        $this->load->model('bank_details_model');
        $this->load->model('user_model');
        $this->load->model('transaction_model');
        $this->load->model('notification_model');
        $this->config->load('config');
        $this->_url = $this->config->item('notify_url');
    }

    /**
     * This function is used to load send bank details list
     */
    function bankVerification() {


        
        $bankDetailList = $this->bank_details_model->bankDetailList();
        $data['bankDetailList'] = $bankDetailList;

        $this->global['pageTitle'] = 'Expect11 : Bank Verification';
        $this->loadViews("bankverify", $this->global, $data, NULL);
        //}
    }
    function bankVerification2() {


        
        $bankDetailList = $this->bank_details_model->bankDetailList2();
        $data['bankDetailList'] = $bankDetailList;

        $this->global['pageTitle'] = 'Expect11 : Bank Verification';
        $this->loadViews("bankverify", $this->global, $data, NULL);
        //}
    }

    /**
     * This function is used load bank detail edit information
     * @param number $id : Optional : This is the id
     */
    function bankVerifyEdit($id = NULL) {
        if ($id == null) {
            redirect('bankVerification');
        }
       

        $bankDetail = $this->bank_details_model->getById($id);
        $data['bankDetail'] = $bankDetail;
        $panVerify = $this->bank_details_model->getPanverifybonus();
        $data['panVerify'] = $panVerify;
        $bankVerify = $this->bank_details_model->getBankdetailbonus();
        $data['bankVerify'] = $bankVerify;

        $this->global['pageTitle'] = 'Expect11 : Bank Detail Verification';

        $this->loadViews("bankVerifyEdit", $this->global, $data, NULL);
        //}
    }

    /**
     * This function is used to edit the bank details
     */
    function bankEdit() {
      
         
        $this->load->library('form_validation');
         
       
        $postData = '';
        //
        $bank_id = $this->input->post('id');
        $user_id = $this->input->post('user_id');
        $bank_op = $this->input->post('bank_op');
        $pan_op = $this->input->post('pan_op');

        $this->form_validation->set_rules('pan_no', 'Pan Number', 'trim|xss_clean');
        $this->form_validation->set_rules('pan_name', 'Pan Name', 'trim|xss_clean');
        $this->form_validation->set_rules('pan_dob', 'Pan DOB', 'trim|xss_clean');
        $this->form_validation->set_rules('pan_state', 'Pan State', 'trim|xss_clean');
        $this->form_validation->set_rules('pan_reject_msg', 'Pan Reject Message', 'trim|xss_clean');
        $this->form_validation->set_rules('bank_name', 'Bank Name', 'trim|xss_clean');
        $this->form_validation->set_rules('account_no', 'Account Number', 'trim|xss_clean');
        $this->form_validation->set_rules('ifsc', 'IFSC', 'trim|xss_clean');
        $this->form_validation->set_rules('account_type', 'Account Type', 'trim|xss_clean');
        $this->form_validation->set_rules('bank_reject_msg', 'Bank Reject Message', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $this->bankVerifyEdit($id);
        } else {
              if ($pan_op == 'Accept') {
                $pan_name = ucwords(strtolower($this->input->post('pan_name')));
                $pan_dob = $this->input->post('pan_dob');
                $pan_verify_bonus = $this->input->post('pan_verify_bonus');
                $pan_state = $this->input->post('pan_state');
                $pan_no = $this->input->post('pan_no');

                $cash_bonuses = $this->user_model->getUser($user_id);
              
                $cash_bonus = $cash_bonuses[0]->cash_bonus + $pan_verify_bonus;
                $referral_bonus = $cash_bonuses[0]->referral_bonus;
                $add_cash = $cash_bonuses[0]->add_cash;
                 $wallet_amount = $cash_bonuses[0]->cash_winning+$cash_bonuses[0]->add_cash+$cash_bonuses[0]->cash_bonus+$cash_bonuses[0]->referral_bonus;
                $cashbonus = array(
                    'cash_bonus' => $cash_bonus
                );
                $this->user_model->updateCashbonus($cashbonus, $user_id);

                $txn_type = array(
                    'txn_amt' => $pan_verify_bonus,
                    'add_cash' =>$add_cash,
                    'cash_bonus' =>$cash_bonus,
                    'referral_bonus' =>$referral_bonus,
                    'wallet_amount' =>$wallet_amount,
                 'winning_amount' =>$cash_bonuses[0]->cash_winning
                   
                );
               
                $this->transaction_model->editTransStatus($txn_type,$bank_id);
                $pan_msg = 'Your pan details have verified successfully';
                $params = array(
                    'title' => 'PAN Card Verification Success',
                    'msg' => $pan_msg,
                    'image' => null,
                    'user_id' => $user_id
                );
                $postData = http_build_query($params);
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $this->_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_POST, count($postData));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                $output = curl_exec($ch);
                $output_data [] = json_decode($output);
                curl_close($ch);

                if (!empty($output_data)) {
                    $params = array(
                        'title' => 'PAN Card Verification Success',
                        'message' => $pan_msg,
                        'image' => null,
                        'user_id' => $user_id
                    );
                    $this->notification_model->addNewNotification($params);
                }
                $data = array(
                    'pan_name' => $pan_name,
                    'pan_dob' => $pan_dob,
                    'pan_state' => $pan_state,
                    'pan_no' => $pan_no,
                    'pan_is_verify' => 'SUCCESS'
                );
                $result = $this->bank_details_model->editBankDetails($data, $bank_id);
                if ($result > 0) {
                    $this->session->set_flashdata('success', 'PAN Detail update successfully');
                } else {
                    $this->session->set_flashdata('error', 'PAN Detail updation failed');
                }

                redirect('bankVerifyEdit/'.$bank_id);
            }

            if ($bank_op == 'Accept') {
                $bank_name = $this->input->post('bank_name');
                $account_no = $this->input->post('account_no');
                $bank_verify_bonus = $this->input->post('bank_verify_bonus');
                $ifsc = $this->input->post('ifsc');
                $account_type = $this->input->post('account_type');
                $bank_photo = '';

                $cash_bonuses = $this->user_model->getUser($user_id);
                $cash_bonus = $cash_bonuses[0]->cash_bonus + $bank_verify_bonus;
                 $referral_bonus = $cash_bonuses[0]->referral_bonus;
                $add_cash = $cash_bonuses[0]->add_cash;
                $wallet_amount = $cash_bonuses[0]->cash_winning+$cash_bonuses[0]->add_cash+$cash_bonuses[0]->cash_bonus+$cash_bonuses[0]->referral_bonus;
                $cashbonus = array(
                    'cash_bonus' => $cash_bonus
                );
                $this->user_model->updateCashbonus($cashbonus, $user_id);

                $txn_type = array(
                    'txn_amt' => $bank_verify_bonus,
                     'add_cash' =>$add_cash,
                    'cash_bonus' =>$cash_bonus,
                    'referral_bonus' =>$referral_bonus,
                    'wallet_amount' =>$wallet_amount,
                    'winning_amount' =>$cash_bonuses[0]->cash_winning
                );

                
               $this->transaction_model->editTransStatus($txn_type,$bank_id);
                $bank_msg = 'Your Bank details have verified successfully';
                
                $postData = '';
                $params = array(
                    'title' => 'Bank Verification Success',
                    'msg' => $bank_msg,
                    'image' => null,
                    'user_id' => $user_id
                );
                $postData = http_build_query($params);
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $this->_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_POST, count($postData));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                $output = curl_exec($ch);
                $output_data [] = json_decode($output);
                curl_close($ch);

                if (!empty($output_data)) {

                    $params = array(
                        'title' => 'Bank Verification Success',
                        'message' => $bank_msg,
                        'image' => null,
                        'user_id' => $user_id
                    );
                    $this->notification_model->addNewNotification($params);
                }

                $data = array(
                    'bank_name' => $bank_name,
                    'account_no' => $account_no,
                    'account_type' => $account_type,
                    'ifcs' => $ifsc,
                    'is_bank_verify' => 'SUCCESS'
                );
                $result = $this->bank_details_model->editBankDetails($data, $bank_id);
                if ($result > 0) {
                    $this->session->set_flashdata('success', 'Bank Detail updated successfully');
                } else {
                    $this->session->set_flashdata('error', 'Bank Detail updation failed');
                }
                redirect('bankVerifyEdit/'.$bank_id);
            }

            if ($pan_op == 'Reject') {
                $pan_msg = $this->input->post('pan_reject_msg');
                $params = array(
                    'title' => 'PAN Verification Reject',
                    'msg' => $pan_msg,
                    'image' => null,
                    'user_id' => $user_id
                );
                $postData = http_build_query($params);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $this->_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_POST, count($postData));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                $output = curl_exec($ch);
                $output_data [] = json_decode($output);
                curl_close($ch);

                if (!empty($output_data)) {
                    $params = array(
                        'title' => 'PAN Verification Reject',
                        'message' => $pan_msg,
                        'image' => null,
                        'user_id' => $user_id
                    );
                    $nid = $this->notification_model->addNewNotification($params);
                }

                $data = array(
                    'pan_is_verify' => 'FAILED'
                );

                $result = $this->bank_details_model->editBankDetails($data, $bank_id);

                if ($result > 0) {
                    $this->session->set_flashdata('success', 'PAN Detail Rejected successfully');
                } else {
                    $this->session->set_flashdata('error', 'PAN Detail Rejection failed');
                }

                redirect('bankVerifyEdit/'.$bank_id);
            }

            if ($bank_op == 'Reject') {
                $bank_msg = $this->input->post('bank_reject_msg');

                $params = array(
                    'title' => 'Bank Verification Reject',
                    'msg' => $bank_msg,
                    'image' => null,
                    'user_id' => $user_id
                );
                $postData = http_build_query($params);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $this->_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_POST, count($postData));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                $output = curl_exec($ch);
                $output_data [] = json_decode($output);
                curl_close($ch);

                if (!empty($output_data)) {
                    $params = array(
                        'title' => 'Bank Verification Reject',
                        'message' => $bank_msg,
                        'image' => null,
                        'user_id' => $user_id
                    );
                    $nid = $this->notification_model->addNewNotification($params);
                }

                $data = array(
                    'is_bank_verify' => 'FAILED'
                );

                $result = $this->bank_details_model->editBankDetails1($data, $bank_id);

                if ($result > 0) {
                    $this->session->set_flashdata('success', 'Bank Detail Rejeted successfully');
                } else {
                    $this->session->set_flashdata('error', 'Bank Detail Rejection failed');
                }

                redirect('bankVerifyEdit/'.$bank_id);
            }
        }
        //}
    }

}

?>