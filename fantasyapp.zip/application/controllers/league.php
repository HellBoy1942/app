<?php
error_reporting(0);

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : League (LeagueController)
 * League Class to manage all league related operations.
 */
class League extends BaseController {

    // helo world sadsad
    /**
     * This is default constructor of the class
     */
   
    private $headers;
    private $subject;
    private $message;
    private $_url;

    public function __construct() {
        parent::__construct();
        $this->isLoggedIn();
        $this->config->load('config');
        $this->_url = $this->config->item('notify_url');
        $from = $this->config->item('email');
        $this->headers = 'MIME-Version: 1.0' . "\r\n";
        $this->headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $this->headers .= 'From:' . $from;
    }

    /**
     * This function is used to load the league list
     */
    function leagueListing() {


        $this->load->model('league_model');

        $this->load->model('match_model');
        $match_list = $this->match_model->getMatchList();
        $data['match_list'] = $match_list;
        $all_match_list = $this->match_model->getAllMatch();
        $data['all_match_list'] = $all_match_list;

        $match_id = (isset($_GET['match_id']) ? $_GET['match_id'] : null);

        if ($match_id != "") {
            $searchText = $match_id;
        } else {
            $searchText = $this->input->post('searchText');
        }
        $data['searchText'] = $searchText;

        $this->load->library('pagination');


        $count = $this->league_model->leagueListingCount($searchText);

        $returns = $this->paginationCompress("leagueListing/", $count, 5);

        $leagueRecords = $this->league_model->leagueListing($searchText);
        $data['leagueRecords'] = $leagueRecords;
        $this->load->model('series_model');
        $matchInfo = $this->series_model->getseries();
        $data['matchInfo'] = $matchInfo;

        $join_team_count = array();
        foreach ($leagueRecords as $league) {
            $this->load->model('joined_league_model');
            $teams_list = $this->joined_league_model->getByLeague($league->id);
            $join_team_count[$league->id] = count($teams_list);
        }

        $data['join_team_count'] = $join_team_count;
        $this->global['pageTitle'] = 'expect11 : League Listing';

        $this->loadViews("league", $this->global, $data, NULL);
    }

    /**
     * This function is used to load the add new league form
     */
    function newLeague() {

        $data = array();

        $this->load->model('match_model');

        $this->load->model('contest_model');
        $match_list = $this->match_model->getMatchList('UPCOMING');
        $type_list = $this->contest_model->getType();
        $data['match_list'] = $match_list;
        $data['type_list'] = $type_list;
        


        $this->global['pageTitle'] = 'expect11 : Add New League';

        $this->loadViews("newLeague", $this->global, $data, NULL);
    }

    /**
     * This function is used to get matchlist by type
     */
    function getMatchList() {

        $type = $this->input->post('match_type');
        $match_list = array();
        $this->load->model('match_model');
        if (!empty($type)) {
            $match_list = $this->match_model->getMatchList($type);
        } else {
            $match_list = $this->match_model->getMatchList();
        }
        echo json_encode(array("type" => $type, "match_list" => $match_list));
        die();
    }

   

    /**
     * This function is used to add new league to the system
     */
    function addNewLeague() {
        $abc='';
        if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('name', 'League Name', 'trim|required|max_length[128]|xss_clean');
          
            $this->form_validation->set_rules('match', 'Match', 'required');
            $this->form_validation->set_rules('win_amount', 'Winning Amount', 'trim|xss_clean');
            $this->form_validation->set_rules('size', 'Size', 'trim|xss_clean');
            $this->form_validation->set_rules('margin', 'Margin', 'trim|xss_clean');
            $this->form_validation->set_rules('entry_fees', 'Entry Fees', 'trim|xss_clean');
            $this->form_validation->set_rules('set_of_winners', 'Set No of Winners ', 'trim|xss_clean');

            if ($this->form_validation->run() == FALSE) {
                $this->newLeague();
            } else {
                $post_data = $this->input->post();
                // print "<pre>" . print_r($post_data, true) . "</pre>";
                // die
                $is_default = $this->input->post('is_default');
                $name = ucwords(strtolower($this->input->post('name')));
                $league_type = $this->input->post('league_type');
                $match = $this->input->post('match');
                $win_amount = $this->input->post('win_amount');
                $size = $this->input->post('size');
                $total_margin = $this->input->post('total_margin');
                $entry_fees = $this->input->post('fees');
                $commission = $this->input->post('total_per');
                $fresh_margin = $this->input->post('fresh_margin');
                $gst_amount = $this->input->post('gst_amount');
                
                $set_of_winners = $this->input->post('set_of_winners');
                $multi_joined = $this->input->post('multi_joined');
                $cancel_contest = $this->input->post('cancel_contest');
                $is_default = $this->input->post('is_default');
                if ($is_default == "1") {
                    $data = array(
                        'name' => $name,
                        'match_id' => $match,
                        'type_id' => $league_type,
                        'is_default' => "YES",
                        'winning_amount' => $win_amount,
                        'contest_size' => $size,
                        'commission' => $commission,
                        'gst_amount' => $gst_amount,
                        'fresh_margin' => $fresh_margin,
                        'total_margin' => $total_margin,
                        'entry_fees' => $entry_fees,
                        'winner' => $set_of_winners,
                        'multi_joined' => $multi_joined,
                        'cancel_contest' => $cancel_contest
                    );
                } else {
                    $data = array(
                        'name' => $name,
                        'match_id' => $match,
                        'type_id' => $league_type,
                        'winning_amount' => $win_amount,
                        'contest_size' => $size,
                         'commission' => $commission,
                        'gst_amount' => $gst_amount,
                        'fresh_margin' => $fresh_margin,
                        'total_margin' => $total_margin,
                        'entry_fees' => $entry_fees,
                        'winner' => $set_of_winners,
                        'multi_joined' => $multi_joined,
                        'cancel_contest' => $cancel_contest
                    );
                }
              


                $this->load->model('league_model');
                $leage_id = $this->league_model->addNewLeague($data);
                if($this->input->post('auto_repeat') or $this->input->post('bonus1'))
                {
                    $args=array(
                        'league_id'=>$leage_id,
                        'auto_repeat'=>$this->input->post('auto_repeat'),
                        'bonus_per'=>$this->input->post('bonus1')
                    );
                    if($this->league_model->auto($args))
                        $abc=' with Automatic Repeat.';
                    else
                        $abc='';

                }
                if($this->input->post('template'))
                {
                    if($this->league_model->svtemplate($leage_id))
                        $abc.='<br>Template Saved.';
                    else
                        $abc=$abc;
                }

                if (!empty($set_of_winners) && $leage_id) {

                    $this->load->model('winners_model');
                    $rank = array();
                    $ranks_per = array();
                    $rank_amounts = array();
                    $minRanks = array();
                    $maxRanks = array();
                    $pers = array();
                    $rankAmounts = array();

                    $i = $set_of_winners;
                    $j = 1;
                    while ($j > 0) {
                        $min_rank = 'min_rank' . $j;
                        $max_rank = 'max_rank' . $j;
                        $rank_peercent = 'rank_peercent' . $j;
                        $rank_amt = 'rank_amt' . $j;

                        // if (isset($post_data[$min_rank]) && !empty($post_data[$min_rank])) {
                        if (isset($post_data[$min_rank]) && !empty($post_data[$min_rank])) {
                            //$rank = $j;
                            $minRank = $post_data[$min_rank];
                            $maxRank = $post_data[$max_rank];
                            $minRanks [] = $minRank;
                            $maxRanks [] = $maxRank;
                            $pers [] = $post_data[$rank_peercent];
                            $rankAmounts [] = $post_data[$rank_amt];
                            $rank_amounts[] = $post_data[$rank_amt];
                            // if(!$maxRank)
                            //     $maxRank=$minRank;

                            for ($i = $minRank; $i <= $maxRank; $i++) {

                                $rank_div = ($maxRank - $minRank) + 1;
                                $rankAmt = $post_data[$rank_amt];

                                $ranks_per [$i] = $post_data[$rank_peercent] / $rank_div;
                                // $rank_amounts[$i] = $rankAmt / $rank_div;
                                $rank_amounts[$i-1] = $rankAmt;
                            }
                            

                        } else {
                            break;
                        }
                        $j++;
                    }
                       

                    // if (!empty($ranks_per) && !empty($rank_amounts)) {
                    if (!empty($rank_amounts)) {
                        for ($i = 0; $i < $set_of_winners; $i++) {
                            $rank = $i + 1;
                            if ($rank <= $set_of_winners) {
                                $wdata = array(
                                    'contest_id' => $leage_id,
                                    'rank' => $rank,
                                    'set_of_winners' => $set_of_winners,
                                    // 'winning_percent' => $ranks_per[$rank],
                                    'winning_amount' => $rank_amounts[$rank-1]
                                );
                                

                                $winner_id = $this->winners_model->addWinnerList($wdata);
                            }
                        }
                    }
                }

                if ($leage_id > 0) {
                    if (!empty($minRanks) && !empty($rankAmounts)) {
                        $count = count($minRanks);
                        for ($i = 0; $i < $count; $i++) {
                            $diff = ($maxRanks [$i] - $minRanks [$i]) + 1;

                            // $user_per = number_format($pers [$i] / $diff, 2, '.', '');
                            // $user_amount = number_format($rankAmounts [$i] / $diff, 2, '.', '');
                            $user_amount = number_format($rankAmounts [$i], 2, '.', '');

                            $data = array(
                                'match_id' => $match,
                                'contest_id' => $leage_id,
                                'min' => $minRanks [$i],
                                'max' => $maxRanks [$i],
                                'percent' => $pers [$i],
                                'amount' => $rankAmounts [$i],
                                // 'user_percent' => $user_per,
                                'user_amount' => $user_amount
                            );
                            $insert_id = $this->league_model->addWinnerConfig($data);
                        }
                    }

                    $this->session->set_flashdata('success', 'New League added successfully'.$abc);
                } else {
                    $this->session->set_flashdata('error', 'League addition failed');
                }

                redirect('newLeague');
            }
        }
    }

    /**
     * This function is used load league edit information
     * @param number $id : Optional : This is league id
     */
    function editOldLeague($id = NULL) {

        if ($id == null) {
            redirect('leagueListing');
        }
        $this->load->model('league_model');
        $this->load->model('winners_model');

        $winnersInfo = $this->winners_model->getWinnersByLeague($id);
        $data['winners_info'] = $winnersInfo;

        $leagueInfo = $this->league_model->getLegueInfo($id);
        $data['league_info'] = $leagueInfo;
        $repeatinfo=$this->league_model->getrepeats($id);
        $data['repeat_info']=$repeatinfo;

        $this->load->model('match_model');
        $match_list = $this->match_model->getMatchList('UPCOMING');
        $data['match_list'] = $match_list;


        $this->global['pageTitle'] = 'expect11 : Edit League';

        $this->loadViews("editOldLeague", $this->global, $data, NULL);
    }

    /**
     * This function is used to disexpect joined teams of specified league
     * @param number $id : This is league id
     */
    function joined_teams($id) {

        if ($id == null) {
            $this->session->set_flashdata('error', 'Please choose a league');
            redirect('leagueListing');
        }
        $this->load->model('league_model');
        $league_list = $this->league_model->getLegueInfo($id);
        $match_id = $league_list[0]->match_id;
        $this->load->model('match_model');
        $match_list = $this->match_model->getMatch($match_id);

        $status = $match_list[0]->status;
        $data['status'] = $status;

        $this->load->model('joined_league_model');
        $teams_list = $this->joined_league_model->getByLeague($id);
        //$data['teams_list'] = $teams_list;

        $this->load->model('league_model');
        $league_info = $this->league_model->getLegueInfo($id);

        $joined_teams = array();
        if (!empty($teams_list)) {

            $this->load->model('teams_model');
            $this->load->model('user_model');
            $this->load->model('winners_model');
            //$this->load->model('league_model');


            foreach ($teams_list as $i => $teams) {
                $team_info = $this->teams_model->getByTeamId($teams->team_id);
                $team_info = $team_info[0];
                $user_info = $this->user_model->getUser($team_info->user_id);
                $joined_teams[$i]['id'] = $team_info->id;
                $joined_teams[$i]['user_id'] = $team_info->user_id;
                $joined_teams[$i]['team_name'] = $team_info->team_name;
                $joined_teams[$i]['joining_date'] = $team_info->created;
                $joined_teams[$i]['name'] = $user_info[0]->name;
                $joined_teams[$i]['user_id1'] = $team_info->user_id;
                $joined_teams[$i]['rank'] = $teams->rank;
                $joined_teams[$i]['points'] = $team_info->points;
                $winners_list = $this->winners_model->getWinnersByTeam($id, $teams->rank);
                // echo $id." = ".$teams->rank."<hr>";
                // print_r($winners_list);
                if (!empty($winners_list)) {
                    $joined_teams[$i]['winning_amount'] = $winners_list[0]->winning_amount;
                } else {
                    $joined_teams[$i]['winning_amount'] = 0;
                }
            }
        }
        $data['refund'] = $league_info[0]->refund;
        $data['status'] = $league_info[0]->status;
        $data['status'] = $status;
        $data['league_id'] = $id;
        $data['joined_teams'] = $joined_teams;
        // print_r($joined_teams);

        $this->global['pageTitle'] = 'expect11 : Joined Teams';

        $this->loadViews("joined_teams", $this->global, $data, NULL);
    }



function viewPlayers($id = NULL) {
        if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {
            if ($id == null) {
                redirect('upcommingMatches');
            }
            $this->load->model('teams_model');
            $this->load->model('players_model');

            $teamInfo = $this->teams_model->getByTeamId($id);

            $players = array();
            $player_details = array();
            $player_pc_details = array();
            $players_data = array();
            $crew_data = array();

            foreach ($teamInfo as $team) {
                $players = explode(',', $team->player_id);
                $crew_data ['captain'] = $team->captain;
                $crew_data ['vc'] = $team->vice_captain;
            }
            if (!empty($players)) {
                foreach ($players as $pid) {
                    $player_details[] = $this->players_model->getPlayersByPid($pid)[0];                    
                    $player_pc_details[] = $this->players_model->getPcPlayersByPid($pid,$team->match_id)[0];
                }   
            }
            
            if (!empty($player_details)) {
                foreach ($player_details as $i => $player) {
                    $players_data [$i]['pid'] = $player->p_id;

                    $players_data [$i]['name'] = $player->name;
                    $players_data [$i]['country'] = $player->country;
                    // $playing_role = "";
                    // if ($player->playing_role == 'AR') {
                    //     $players_data [$i] = 'All Rounder';
                    // }
                    // if ($player->playing_role == 'AR') {
                    //     $players_data [$i] = 'All Rounder';
                    // }
                    // if ($player->playing_role == 'AR') {
                    //     $players_data [$i] = 'All Rounder';
                    // }
                    $players_data [$i]['role'] = $player->playing_role;
                    if ($player->p_id == $crew_data ['captain']) {
                        $players_data [$i]['points'] = $player_pc_details [$i]->points *2;
                    } else if ($player->p_id == $crew_data ['vc']) {
                        $players_data [$i]['points'] = $player_pc_details [$i]->points *1.5;
                    } else {
                        $players_data [$i]['points'] = $player_pc_details [$i]->points;
                    }

                }
            }
            $data['crew_data'] = $crew_data;
            $data['players_data'] = $players_data;
            $this->global['pageTitle'] = 'play11 : View Players';

            $this->loadViews("viewPlayers", $this->global, $data, NULL);
        }
    }
    /**
     * This function is used to disexpect joined teams of specified league
     * @param number $id : This is league id
     */
    function winners_list($id) {

        if ($id == null) {
            $this->session->set_flashdata('error', 'Please choose a league');
            redirect('leagueListing');
        }
        $this->load->model('league_model');
        $league_list = $this->league_model->getLegueInfo($id);
        $match_id = $league_list[0]->match_id;
        $league_status=$league_list[0]->status;
        $this->load->model('match_model');
        $match_list = $this->match_model->getMatch($match_id);

        $status = $match_list[0]->status;
        $data['status'] = $status;
        $data['league_status'] =$league_status;
        $this->load->model('joined_league_model');
        $this->load->model('winners_model');
        $teams_list = $this->joined_league_model->getByLeague($id);
        
        $this->load->model('league_model');
        $league_info = $this->league_model->getLegueInfo($id);

        $joined_teams = array();
        if (!empty($teams_list)) {

            $this->load->model('teams_model');
            $this->load->model('user_model');

            foreach ($teams_list as $i => $teams) {
                $team_info = $this->teams_model->getByTeamId($teams->team_id);
                 
                $team_info = $team_info[0];
                $user_info = $this->user_model->getUser($team_info->user_id);
                $winners_list = $this->winners_model->getWinnersByTeam($id, $teams->rank);
                
                if (!empty($winners_list)) {
                    if ($winners_list[0]->winning_amount > 0) {
                        $joined_teams[$i]['id'] = $team_info->id;
                        $joined_teams[$i]['team_name'] = $team_info->team_name;
                        $joined_teams[$i]['joining_date'] = $team_info->created;
                        $joined_teams[$i]['name'] = $user_info[0]->name;
                        $joined_teams[$i]['user_id'] = $team_info->user_id;
                        $joined_teams[$i]['rank'] = $teams->rank;
                        $joined_teams[$i]['points'] = $team_info->points;
                        $joined_teams[$i]['winning_amount'] = $winners_list[0]->winning_amount;
                    }
                }
            }
        }
        $data['settled'] = $league_info[0]->settled;
        $data['status'] = $status;
        $data['league_status'] =$league_status;
        $data['league_id'] = $id;
        $data['joined_teams'] = $joined_teams;
        $this->global['pageTitle'] = 'expect11 : Winners List';

        $this->loadViews("winners_list", $this->global, $data, NULL);
    }

    /**
     * This function is used load expecters by team
     * @param number $id : Optional : This is team id
     */
    function viewexpecters($id = NULL) {
        if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {
            if ($id == null) {
                redirect('upcommingMatches');
            }
            $this->load->model('teams_model');
            $this->load->model('expecters_model');

            $teamInfo = $this->teams_model->getByTeamId($id);

            $expecters = array();
            $expecter_details = array();
            $expecter_pc_details = array();
            $expecters_data = array();
            $crew_data = array();

            foreach ($teamInfo as $team) {
                $expecters = explode(',', $team->expecter_id);
                $crew_data ['captain'] = $team->captain;
                $crew_data ['vc'] = $team->vice_captain;
            }
            if (!empty($expecters)) {
                foreach ($expecters as $pid) {
                    $expecter_details[] = $this->expecters_model->getexpectersByPid($pid)[0];
                    $expecter_pc_details[] = $this->expecters_model->getPcexpectersByPid($pid, $team->match_id)[0];
                }
            }

            if (!empty($expecter_details)) {
                foreach ($expecter_details as $i => $expecter) {
                    $expecters_data [$i]['pid'] = $expecter->p_id;

                    $expecters_data [$i]['name'] = $expecter->name;
                    $expecters_data [$i]['country'] = $expecter->country;
                    // $expecting_role = "";
                    // if ($expecter->expecting_role == 'AR') {
                    //     $expecters_data [$i] = 'All Rounder';
                    // }
                    // if ($expecter->expecting_role == 'AR') {
                    //     $expecters_data [$i] = 'All Rounder';
                    // }
                    // if ($expecter->expecting_role == 'AR') {
                    //     $expecters_data [$i] = 'All Rounder';
                    // }
                    $expecters_data [$i]['role'] = $expecter->expecting_role;
                    if ($expecter->p_id == $crew_data ['captain']) {
                        $expecters_data [$i]['points'] = $expecter_pc_details [$i]->points * 2;
                    } else if ($expecter->p_id == $crew_data ['vc']) {
                        $expecters_data [$i]['points'] = $expecter_pc_details [$i]->points * 1.5;
                    } else {
                        $expecters_data [$i]['points'] = $expecter_pc_details [$i]->points;
                    }
                }
            }
            $data['crew_data'] = $crew_data;
            $data['expecters_data'] = $expecters_data;
            $this->global['pageTitle'] = 'expect11 : View expecters';

            $this->loadViews("viewexpecters", $this->global, $data, NULL);
        }
    }

    function getmicrotime() {
        list($usec, $sec) = explode(" ", microtime());
        return ((float) $usec + (float) $sec);
    }

   /**
     * This function is used to settle match
     * @param number $id : This is league id
     */
    function settledMatch() {

        $id = $this->input->post('league_id');
      
        
        if ($id == null) {
            $this->session->set_flashdata('error', 'Please choose a league');
            redirect('leagueListing');
        }
        $this->load->model('league_model');

        $match_id = $this->league_model->getMatchIdByLeague($id);
        $match = $match_id[0]->match_id;
        $league_status=$match_id[0]->status;
        $this->load->model('joined_league_model');
        $teams_list = $this->joined_league_model->getByLeague($id);
        
        $this->load->model('match_model');
        $MatchInfo = $this->match_model->getMatchByLeague($match);
        $team1 = $MatchInfo[0]->team1;
        $team2 = $MatchInfo[0]->team2;
        $teamdata = $team1 . ' vs ' . $team2;
        $match_name = $teamdata;

        $joined_teams = array();
        if (!empty($teams_list)) {

            $this->load->model('teams_model');
            $this->load->model('user_model');
            $this->load->model('winners_model');
            $this->load->model('transaction_model');
            $this->load->model('notification_model');

            $trn_data = array();
            $trn_ids = array();
            foreach ($teams_list as $i => $teams) {

                $team_info = $this->teams_model->getByTeamId($teams->team_id);
                $team_info = $team_info[0];
               
                $user_info = $this->user_model->getUser($team_info->user_id);
                
                $winners_list = $this->winners_model->getWinnersByTeam($id, $teams->rank);
                 
                if (!empty($winners_list)) {
                    if ($winners_list[0]->winning_amount > 0) {

                        $match_name = $teamdata;
                        $name = $user_info[0]->name;
                        $amount = $winners_list[0]->winning_amount;
                        $to = $user_info[0]->email;
                        $teams_bw = $match_name;
                        $date = date();
                        $userid = $user_info[0]->id;
                        $settle_msg = 'your winning amount  Rs. ' . $amount . ' transfer to your wallet successfully';
                        $postData = '';
                        $params = array(
                            'title' => 'Your Winning Amount settled successfully',
                            'msg' => $settle_msg,
                            'image' => null,
                            'user_id' => $userid
                        );
                        $postData = http_build_query($params);

                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, $this->_url );
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                        curl_setopt($ch, CURLOPT_HEADER, false);
                        curl_setopt($ch, CURLOPT_POST, count($postData));
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                        $output = curl_exec($ch);
                        $output_data [] = json_decode($output);
                        curl_close($ch);

                        $params = array(
                            'title' => 'Your Winning Amount settled successfully',
                            'message' => $settle_msg,
                            'user_id' => $userid
                        );
                        
                        $nid = $this->notification_model->addNewNotification($params);
                        $this->subject = "Settled Amount confirmation!";
                        $date = date("d-m-Y");
                        $msg ="Congratulation, The ' . $teams_bw . ' on ' . $date . ' has been finished and you have won Rs ' . $amount . ' & This winning amount is deposit to your Wallet.";
                                             $email_data =array(
                                                 'name' =>$name,
                                                 'msg' =>$msg,
                                                 
                                             );
                                             
                                              $message = $this->load->view('emailView',$email_data,TRUE);
                                               // echo $message;die;
                        mail($to, $this->subject, $message, $this->headers);
                     $wallet_amount = $user_info[0]->cash_bonus + $user_info[0]->referral_bonus + $user_info[0]->add_cash + $user_info[0]->cash_winning;
                        $trn_data = array(
                            'txn_id' => $this->getmicrotime(),
                            'user_id' => $team_info->user_id,
                            'txn_amt' => $winners_list[0]->winning_amount,
                            'txn_status' => 'SUCCESS',
                            'txn_type' => 'WINNING_AMOUNT',
                            'cash_bonus'=>$user_info[0]->cash_bonus,
                            'referral_bonus'=>$user_info[0]->referral_bonus,
                            'add_cash'=>$user_info[0]->add_cash,
                            'winning_amount'=>$user_info[0]->cash_winning,
                            'wallet_amount'=>$wallet_amount
                        );
                        
                        
                        $user_data = array(
                            'cash_winning' => $winners_list[0]->winning_amount + $user_info[0]->cash_winning
                        );
                        $trn_ids[] = $this->transaction_model->addTrans($trn_data);
                       
                        $ud = $this->user_model->editAppUser($user_data, $team_info->user_id);
                    }
                }

                // $user_data = array(
                //     'wallet_amount' => $winners_list[0]->winning_amount + $user_info[0]->wallet_amount
                // );
            }
            if (count($trn_ids) > 0) {
                $this->load->model('league_model');
                $league_data = array(
                    'settled' => TRUE
                );
               
                $this->league_model->editLeague($league_data, $id);
                $this->session->set_flashdata('success', 'Settlement successfully completed');
            } else {
                $this->session->set_flashdata('error', 'Settlement Failed!');
            }
            redirect('leagueListing');
        } else {
            $this->session->set_flashdata('error', 'Insufficient Data');
            redirect('leagueListing');
        }
    }

 /**
     * This function is used to refundAmount
     * @param number $id : This is league id
     */
   
function refundAmount($league_id, $match_id) {
      
        $this->load->model('teams_model');
        $this->load->model('user_model');
        $this->load->model('match_model');
        $this->load->model('transaction_model');
        $this->load->model('joined_league_model');
        $this->load->model('notification_model');
        $this->load->model('league_model');
        
        // Match Informtion
        $matchInfo = $this->match_model->getMatch($match_id);
        $team1 = $matchInfo[0]->team1;
        $team2 = $matchInfo[0]->team2;
        $match_name = $team1 . ' vs ' . $team2;
        
        
        // League Information
        $league_info = $this->league_model->getLegueInfo($league_id);
        $entry_fees= $league_info[0]->entry_fees;
        $league_status= $league_info[0]->status;
        
        // User Joined List regarding this league 
        $contestJoinedUserLIst = $this->league_model->getContestJoinedUserList($league_id);
        
         // Transsaction id
        $txn_id = round(microtime(true) * 1000);
        
        if (!empty($contestJoinedUserLIst)) {
            
            if($league_status =='CANCEL'){
                foreach($contestJoinedUserLIst as $joinedList){
                    $used_cash_bonus = $joinedList->used_cash_bonus;
                    $used_referral_binus = $joinedList->used_referral_binus;
                    $used_add_cash = $joinedList->used_add_cash;
                    $used_winning_amount = $joinedList->used_winning_amount;
                    // print_r($joinedList);
                    
                    $userid = $joinedList->user_id;
                    
                    $trn_data = array();
                    $trn_ids = array();
                    
                    $user_info = $this->user_model->getUser($userid);
                   
                    $refund_msg = 'Your Entry Fees  Rs. ' . $entry_fees . ' has been refunded to your Wallet';
                    $postData = '';
                    $params = array(
                        'title' => 'Your Entry Fees refund successfully',
                        'msg' => $refund_msg,
                        'image' => null,
                        'user_id' => $userid
                    );
                  
                    $postData = http_build_query($params);
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $this->_url );
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                    curl_setopt($ch, CURLOPT_HEADER, false);
                    curl_setopt($ch, CURLOPT_POST, count($postData));
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

                    $output = curl_exec($ch);
                    $output_data [] = json_decode($output);
                    curl_close($ch);
                        
                    $params = array(
                        'title' => 'Your Entry Fees refund successfully',
                        'message' => $refund_msg,
                        'user_id' => $userid
                    );
                    $nid = $this->notification_model->addNewNotification($params);
                    
                    $name = $user_info[0]->name;
                    $to = $user_info[0]->email;
                    $cash_bonus = $user_info[0]->cash_bonus;
                    $add_cash = $user_info[0]->add_cash;
                    $referral_bonus = $user_info[0]->referral_bonus;
                    $wallet_amount = $user_info[0]->wallet_amount;
                    $teams_bw = $match_name;
                    $date = date("d-m-Y");
                    $this->subject = "Refund Amount confirmation!";
                    // $msg ="The ". " $teams_bw "." on ". " $date ". "has been abandoned & your entry fee Rs.". "$entry_fees ". "has been refunded to your Wallet.";
                    
                    $msg = "Your entry fee has been refunded for the Rs.". "$entry_fees ". "contest. The contest you joined had to be cancelled as all the slots were not filled or match is Abandoned.";
                    
                     $email_data =array(
                         'name' =>$name,
                         'msg' =>$msg,
                         
                     );
                                             
                    $message = $this->load->view('emailView',$email_data,TRUE);
                    $this->message = $this->message . $this->message_footer;
                    mail($to, $this->subject, $message, $this->headers);
                     $wallet_amount = $user_info[0]->cash_bonus + $user_info[0]->referral_bonus + $user_info[0]->add_cash + $user_info[0]->cash_winning;
                    $trn_data = array(
                        'txn_id' => $txn_id,
                        'user_id' => $userid,
                        'txn_amt' => $entry_fees,
                        'txn_status' => 'SUCCESS',
                        'txn_type' => 'REFUND_AMT',
                        'txn_msg' => $msg,
                        'cash_bonus'=>$user_info[0]->cash_bonus,
                        'referral_bonus'=>$user_info[0]->referral_bonus,
                        'add_cash'=>$user_info[0]->add_cash,
                        'winning_amount'=>$user_info[0]->cash_winning,
                        'wallet_amount'=>$wallet_amount
                    );
                   
                    $user_data = array(
                        'cash_bonus' => $user_info[0]->cash_bonus +  $used_cash_bonus,
                         'referral_bonus' => $user_info[0]->referral_bonus +  $used_referral_binus,
                         'add_cash' => $user_info[0]->add_cash +  $used_add_cash,
                         'cash_winning' => $user_info[0]->cash_winning   +  $used_winning_amount
                    );
                           
                    $trn_ids[] = $this->transaction_model->addTrans($trn_data);
                    $ud = $this->user_model->editAppUser($user_data, $userid);
                }
                
            if (count($trn_ids) > 0) {
                
                $league_data = array(
                    'refund' => TRUE
                );
                $this->load->model('league_model');
                $this->league_model->editLeague($league_data, $id);
                $this->session->set_flashdata('success', 'Refund amount successfully completed');
            } else {
                $this->session->set_flashdata('error', 'Refund amount Failed!');
            }
            }
        }
    }  
   
    /**
     * This function is used to edit old league to the system
     */
    function editLeague() {

        $this->load->library('form_validation');

        $id = $this->input->post('id');

        $this->form_validation->set_rules('name', 'League Name', 'trim|required|max_length[128]|xss_clean');
        $this->form_validation->set_rules('league_type', 'League Type', 'trim|required|xss_clean');
        $this->form_validation->set_rules('match', 'Match', 'required');
        $this->form_validation->set_rules('win_amount', 'Winning Amount', 'trim|required|xss_clean');
        $this->form_validation->set_rules('size', 'Size', 'trim|required|xss_clean');
        $this->form_validation->set_rules('margin', 'Margin', 'trim|required|xss_clean');
        $this->form_validation->set_rules('entry_fees', 'Entry Fees', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $this->newLeague();
        } else {
            $name = ucwords(strtolower($this->input->post('name')));
            $league_type = $this->input->post('league_type');
            $match = $this->input->post('match');
            $win_amount = $this->input->post('win_amount');
            $size = $this->input->post('size');
            $margin = $this->input->post('margin');
            $entry_fees = $this->input->post('entry_fees');
            $set_of_winners = $this->input->post('set_of_winners');


            $edit_league = $this->input->post('edit_league');
            $delete_league = $this->input->post('delete_league');

            if (isset($edit_league) && !empty($edit_league)) {
                $data = array(
                    'name' => $name,
                    'match_id' => $match,
                    'type' => $league_type,
                    'winning_amount' => $win_amount,
                    'contest_size' => $size,
                    'commission' => $margin,
                    'entry_fees' => $entry_fees
                );
                if($this->input->post('aid')){
                    $abng=array('auto_repeat'=>$this->input->post('auto_repeat'),'bonus_per'=>$this->input->post('bonus1'));
                    if($this->league_model->updrepeat($this->input->post('aid'),$abng))
                        $fd="updated.";
                    else
                        $fd="failed";
                }

                $this->load->model('league_model');
                $result = $this->league_model->editLeague($data, $id);

                $this->load->model('league_model');
                $leage_id = $this->league_model->addNewLeague($data);

                if (!empty($set_of_winners) && $leage_id) {

                    $this->load->model('winners_model');
                    $delete_winners = $this->winners_model->deleteWinnersByLeague($id);
                    $ranks_per = array();
                    $rank_amounts = array();
                    $i = $set_of_winners;
                    for ($i = 0; $i <= $set_of_winners; $i++) {
                        $rank = $i + 1;
                        $rank_per_name = 'percen_' . $i;
                        $rank_amt_name = 'rank_amt_' . $i;
                        if ($rank <= $set_of_winners) {
                            // $ranks_per[$rank] = $this->input->post($rank_per_name);
                            $rank_amounts[$rank] = $this->input->post($rank_amt_name);
                        }
                    }


                    // $rank_amt = ($win_amount/$set_of_winners);
                    // $rank_percentage = ($rank_amt * 100) / $win_amount;
                    // if (!empty($ranks_per) && !empty($rank_amounts)) {
                    if (!empty($rank_amounts)) {
                        for ($i = 0; $i < $set_of_winners; $i++) {
                            $rank = $i + 1;
                            if ($rank <= $set_of_winners) {
                                $wdata = array(
                                    'contest_id' => $leage_id,
                                    'rank' => $rank,
                                    'set_of_winners' => $set_of_winners,
                                    'winning_percent' => $ranks_per[$rank],
                                    'winning_amount' => $rank_amounts[$rank]
                                );
                                if ($delete_winners) {
                                    $winner_id = $this->winners_model->addWinnerList($wdata);
                                }
                            }
                        }
                    }
                }


                if ($result > 0) {
                    $this->session->set_flashdata('success', 'Updated League successfully');
                } else {
                    $this->session->set_flashdata('error', 'League updation failed');
                }
            }

            if (isset($delete_league) && !empty($delete_league)) {
                $this->load->model('joined_league_model');
                $teams_list = $this->joined_league_model->getByLeague($id);
                if (empty($teams_list)) {
                    $this->load->model('league_model');
                    $deleted = $this->league_model->deleteLeague($id);
                    if ($deleted) {
                        $this->session->set_flashdata('success', 'League deleted successfully');
                    } else {
                        $this->session->set_flashdata('error', 'League deletion failed');
                    }
                } else {
                    $this->session->set_flashdata('error', 'This league can not be deleted as it contains teams associated with it.');
                }
            }
            redirect('leagueListing');
        }
    }

     function editStatus() {
        $id = $this->input->post('l_id');
        $cancel_desc = $this->input->post('cancel_desc');
        $data = array(
            'status' => 'CANCEL',
            'cancel_desc' => $cancel_desc,
          
        );
        
        $this->load->model('league_model');
        $this->league_model->editStatus_league($data, $id);
        $match_id = $this->league_model->getMatchIdByLeague($id);
        $match_id = $match_id[0]->match_id; 
        $this->refundAmount($id,$match_id);
        redirect('leagueListing');
    }

    function deleteOldLeague($id = NULL) {

        if ($id == NULL) {
            redirect('defaultleagueListing');
        }
        
        $this->load->model('defaultleague_model');
        $id = $this->defaultleague_model->deleteLeague($id);
       
        if ($id) {
            $this->session->set_flashdata('success', 'DefaultLeague deleted successfully');
        } else {
            $this->session->set_flashdata('error', 'DefaultLeague deletion failed');
        }
        redirect('defaultleagueListing');
        
    }
    function deleteOldLeague2($id = NULL) {

        if ($id == NULL) {
            redirect('leagueListing');
        }
        
        $this->load->model('defaultleague_model');
        $id = $this->defaultleague_model->deleteleague2($id);
       
        if ($id) {
            $this->session->set_flashdata('success', 'League deleted successfully');
        } else {
            $this->session->set_flashdata('error', 'League deletion failed');
        }
        redirect('leagueListing');
        
    }
    function addtemplate($value='')
    {
        $data = array();
        $skd=array();
        $this->load->model('match_model');

        $this->load->model('league_model');
        $this->load->model('contest_model');
        $match_list = $this->match_model->getMatchList('UPCOMING');
        $type_list = $this->league_model->gettemp();
        $data['match_list'] = $match_list;
        $data['type_list'] = $type_list;
        $type_list2 = $this->contest_model->getType();
        foreach($type_list2 as $ks)
        {
            $skd[$ks->id]=$ks->league_name;
        }
        $data['skd'] = $skd;

        if($this->input->post('league_type') && $this->input->post('match'))
        {
            $rs=$this->league_model->gettempbyid($this->input->post('league_type'));
            
            if($rs->num_rows()>0)
            {
                $aa=$rs->result();
                $tmpdata=(array)$aa[0];
                unset($tmpdata['tid']);

                if($this->league_model->svcontest($tmpdata,$this->input->post('match')))
                {
                    $this->session->set_flashdata('success','Contest Created Successfully.');
                    redirect(base_url().'addTemp');                
                }
                else
                    $this->session->set_flashdata('error','Error!!! Unable to create Contest.');
            }
            
        }
        


        $this->global['pageTitle'] = 'expect11 : Add New League';

        $this->loadViews("newLeague2", $this->global, $data, NULL);
        
    }
    public function gettempo($value='')
    {
        $skd=array();
        $this->load->model('league_model');
        
        $rs=$this->league_model->gettempbyid($value);
        $this->load->model('contest_model');
        $type_list2 = $this->contest_model->getType();
        foreach($type_list2 as $ks)
        {
            $skd[$ks->id]=$ks->league_name;
        }
        

        // $data['skd'] = $skd;
        if($rs->num_rows()>0)
        {
            echo "<table class='table table-striped table-hover'>";
            $rs2=$rs->result();
            $rs2=$rs2[0];
            echo "<thead><tr><th>Template ID </th><th>".$rs2->tid."</th></tr></thead><tbody>";
            echo "<tr><td>Type </td><td>".$skd[$rs2->type_id]."</td></tr>";
            echo '<tr><td>Name </td><td>'.$rs2->name.'</td></tr>';
            echo '<tr><td>Winning Amount </td><td>'.$rs2->winning_amount.'</td></tr>';
            echo '<tr><td>Contest Size</td><td>'.$rs2->contest_size.'</td></tr>';
            echo '<tr><td>Winner Size</td><td>'.$rs2->winner.'</td></tr>';
            echo '<tr><td>Entry Fees</td><td>'.$rs2->entry_fees.'</td></tr>';
            echo '<tr><td>Commission %</td><td>'.$rs2->commission.'</td></tr>';
            echo '<tr><td>Total Margin</td><td>'.$rs2->total_margin.'</td></tr>';
            echo '<tr><td>Fresh Margin</td><td>'.$rs2->fresh_margin.'</td></tr>';
            echo '<tr><td>Multi Joined</td><td>'.$rs2->multi_joined.'</td></tr>';
            echo '<tr><td>Cancel contest</td><td>'.$rs2->cancel_contest.'</td></tr>';
            // echo '<tr><td></td><td>'.$rs2->.'</td></tr>';
            // echo '<tr><td></td><td>'.$rs2->.'</td></tr>';
            // echo '<tr><td></td><td>'.$rs2->.'</td></tr>';
            // echo '<tr><td></td><td>'.$rs2->.'</td></tr>';
            echo '</tbody></table>';

            // tid     type    type_id     is_default  name    winning_amount  contest_size    settled     refund  winner winner size  entry_fees  commission in %     total_margin    fresh_margin    gst_amount  created     status  multi_joined    cancel_contest  cancel_desc     invite_code     user_id
        }
    }
     public function getmatcho($value='')
    {
        $skd=array();
        $this->load->model('league_model');
        
        $rs=$this->league_model->getmatchbyid($value);
        // $this->load->model('contest_model');
        // $type_list2 = $this->contest_model->getType();
        // foreach($type_list2 as $ks)
        // {
        //     $skd[$ks->id]=$ks->league_name;
        // }
        

        // $data['skd'] = $skd;
        if($rs->num_rows()>0)
        {
            echo "<table class='table table-striped table-hover'>";
            $rs2=$rs->result();
            $rs2=$rs2[0];
            echo "<thead><tr><th>Match ID </th><th>".$rs2->match_id."</th></tr></thead><tbody>";
            echo "<tr><td>Start Date </td><td>".$rs2->start_dt."</td></tr>";
            echo '<tr><td>End Date </td><td>'.$rs2->end_dt.'</td></tr>';
            echo '<tr><td>Series </td><td>'.$rs2->series.'</td></tr>';
            echo '<tr><td>Team 1 </td><td>'.$rs2->team1.'</td></tr>';
            echo '<tr><td>Team 2</td><td>'.$rs2->team2.'</td></tr>';
            echo '<tr><td>Status</td><td>'.$rs2->status.'</td></tr>';
            echo '<tr><td>Match Type</td><td>'.$rs2->match_type.'</td></tr>';
            // echo '<tr><td>Total Margin</td><td>'.$rs2->total_margin.'</td></tr>';
            // echo '<tr><td>Fresh Margin</td><td>'.$rs2->fresh_margin.'</td></tr>';
            // echo '<tr><td>Multi Joined</td><td>'.$rs2->multi_joined.'</td></tr>';
            // echo '<tr><td>Cancel contest</td><td>'.$rs2->cancel_contest.'</td></tr>';
            // echo '<tr><td></td><td>'.$rs2->.'</td></tr>';
            // echo '<tr><td></td><td>'.$rs2->.'</td></tr>';
            // echo '<tr><td></td><td>'.$rs2->.'</td></tr>';
            // echo '<tr><td></td><td>'.$rs2->.'</td></tr>';
            echo '</tbody></table>';

            //id  match_id    created modified    start_dt    end_dt  series  team1   team1_logo  team1_short_name    team2   team2_logo  team2_short_name    status Descending 1 admin_status    match_type  matchStarted    squad   score   cancel_desc

            // tid     type    type_id     is_default  name    winning_amount  contest_size    settled     refund  winner winner size  entry_fees  commission in %     total_margin    fresh_margin    gst_amount  created     status  multi_joined    cancel_contest  cancel_desc     invite_code     user_id
        }
    }
}
?>