<?php 
error_reporting(0);

if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Banner (BannerController)
 * Banner Class to manage all flag related operations.
 */
class Setting extends BaseController
{
    // helo world sadsad
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();
         
            $this->load->model('setting_model');
    }
    

    
    function settingList()
    {
            $bonusInfo = $this->setting_model->getBonusInfo();
            $data['bonus_info'] = $bonusInfo;
            $this->global['pageTitle'] = 'play11 : Setting';
            
            $this->loadViews("editOldBonus", $this->global, $data, NULL);
      
    }
    function editSetting(){

                    $withdraw_request_limit =$this->input->post('withdraw_request_limit');
                        $register_bonus =$this->input->post('register_bonus');
                          $referral_bonus =$this->input->post('referral_bonus');
                           $pan_verify_bonus =$this->input->post('pan_verify_bonus');
                            $bank_verify_bonus =$this->input->post('bank_verify_bonus');
                            $email_verify_bonus =$this->input->post('email_verify_bonus');
                            $mobile_verify_bonus =$this->input->post('mobile_verify_bonus');
                             $cash_bonus_used =$this->input->post('cash_bonus_used');
                              $referral_bonus_used =$this->input->post('referral_bonus_used');
                               
                   $id=$this->input->post('b_id');
                   
                   $data=array(
                        'withdraw_request_limit'=>$withdraw_request_limit,
                        'register_bonus'=>$register_bonus,
                        'referral_bonus'=>$referral_bonus,
                        'pan_verify_bonus'=>$pan_verify_bonus,
                        'bank_verify_bonus'=>$bank_verify_bonus,
                        'email_verify_bonus'=>$email_verify_bonus,
                        'mobile_verify_bonus'=>$mobile_verify_bonus,
                        'cash_bonus_used'=>$cash_bonus_used,
                        'referral_bonus_used'=>$referral_bonus_used
                        );

                        $bonus_id = $this->setting_model->editData($data,$id);
                        if($bonus_id > 0)
                        {
                            $this->session->set_flashdata('success', 'Bonus update successfully');
                        }
                        else
                        {
                            $this->session->set_flashdata('error', 'Bonus updation failed');
                        }
                
                    redirect('settingList');
        }
   
  }  
?>