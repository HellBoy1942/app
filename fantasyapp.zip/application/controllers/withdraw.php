<?php 
error_reporting(0);
if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Withdraw (WithdrawController)
 * Withdraw Class to manage all withdraw request related operations.
 */
class Withdraw extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn(); 
        $this->config->load('config');
        $from = $this->config->item('email');
        $this->_url = $this->config->item('notify_url');
        
        $this->headers = 'MIME-Version: 1.0' . "\r\n";
        $this->headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $this->headers .= 'From:' . $from;  
    }


    /**
     * This function is used to load the withdraw list
     */
    function newListing()
    {

            //$this->load->model('user_model');
            $this->load->model('withdraw_request_model');
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
             $count = $this->withdraw_request_model->withdrawListingCount($searchText);

             $returns = $this->paginationCompress ( "withdrawListing/", $count, 10 );

            
             $data['withdrawRecords'] = $this->withdraw_request_model->withdrawListing($searchText, $returns["page"], $returns["segment"]);
            $withdraw_list = $this->withdraw_request_model->getWithdrawRequest();
           
            $data['withdraw_list'] = $withdraw_list;   
             $this->global['pageTitle'] = 'Expect11 : Withdraw Request List';
            
            $this->loadViews("newRequest", $this->global, $data, NULL);
        //}
    }

    function pendingListing()
    {

        
             $this->load->model('withdraw_request_model');
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
             $count = $this->withdraw_request_model->withdrawListingCount($searchText);

             $returns = $this->paginationCompress ( "withdrawListing/", $count, 10 );

            
             $data['withdrawRecords'] = $this->withdraw_request_model->withdrawListing($searchText, $returns["page"], $returns["segment"]);
            $withdraw_list = $this->withdraw_request_model->getpendingRequest();
           
              $data['withdraw_list'] = $withdraw_list;   
             $this->global['pageTitle'] = 'Expect11 : Withdraw Request List';
            
            $this->loadViews("pendingRequest", $this->global, $data, NULL);         
            
    }
     function completeListing()
    {

        
            $this->load->model('withdraw_request_model');
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
             $count = $this->withdraw_request_model->withdrawListingCount($searchText);

             $returns = $this->paginationCompress ( "withdrawListing/", $count, 10 );

            
             $data['withdrawRecords'] = $this->withdraw_request_model->withdrawListing($searchText, $returns["page"], $returns["segment"]);
            $withdraw_list = $this->withdraw_request_model->getcompleteRequest();
           
              $data['withdraw_list'] = $withdraw_list;   
             $this->global['pageTitle'] = 'Expect11 : Withdraw Request List';
            
            $this->loadViews("completeRequest", $this->global, $data, NULL);
    }
    
    function rejectedListing()
    {

        
            $this->load->model('withdraw_request_model');
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
             $count = $this->withdraw_request_model->withdrawListingCount($searchText);

             $returns = $this->paginationCompress ( "withdrawListing/", $count, 10 );

            
             $data['withdrawRecords'] = $this->withdraw_request_model->withdrawListing($searchText, $returns["page"], $returns["segment"]);
            $withdraw_list = $this->withdraw_request_model->getrejectRequest();
           
              $data['withdraw_list'] = $withdraw_list;   
             $this->global['pageTitle'] = 'Expect11 : Withdraw Request List';
            
            $this->loadViews("rejectRequest", $this->global, $data, NULL);
    }
   
      
function changestatus() {
        $this->load->model('withdraw_request_model');
        $id = $this->input->post('t_id');
        $user_id = $this->input->post('user_id');
        $status = $this->input->post('status');
        $amount = $this->input->post('amount');
        $txn_msg = $this->input->post('txn_msg');
        
        if ($status == 'ACCEPT') {
            $this->load->model('user_model');
            $user_info = $this->user_model->getUser($user_id);
           
            $wallet_amount = $user_info[0]->cash_winning+$user_info[0]->add_cash+$user_info[0]->referral_bonus+$user_info[0]->cash_bonus;
           
            $name = $user_info[0]->name;
            $to = $user_info[0]->email;
            $userid = $user_info[0]->id;
            $refund_msg = 'Your withdraw request of Rs. ' . $amount . ' is accpected and your winning amount deposited to your wallet';
            $postData = '';
            $params = array(
                'title' => 'Your Withdraw  Request Accept successfully',
                'msg' => $refund_msg,
                'image' => null,
                'user_id' => $userid
            );
            $postData = http_build_query($params);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_POST, count($postData));
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

            $output = curl_exec($ch);
            $output_data [] = json_decode($output);
            curl_close($ch);

            $params = array(
                'title' => 'Your Withdraw  Request Accept successfully',
                'message' => $refund_msg,
                'user_id' => $userid
            );

            $this->load->model('notification_model');
            $nid = $this->notification_model->addNewNotification($params);
            
            $trans = array(
                'txn_status' => 'SUCCESS',
                'cash_bonus' =>$user_info[0]->cash_bonus,
                'referral_bonus' =>$user_info[0]->referral_bonus,
                'wallet_amount' =>$wallet_amount,
                'add_cash' =>$user_info[0]->add_cash,
                'txn_msg' =>  $refund_msg,
                'winning_amount' => $user_info[0]->cash_winning
                
            );
            
            $this->load->model('transaction_model');
            $tid = $this->transaction_model->editTransStatus($trans, $id);
            $this->subject = "Withdraw Accept confirmation!";
            $msg = "Congratulation, Your withdraw request is accpected and your Rs ' . $amount . ' deposited to your wallet.";
            $email_data = array(
                'name' => $name,
                'msg' => $msg,
            );

            $message = $this->load->view('emailView', $email_data, TRUE);
            mail($to, $this->subject, $message, $this->headers);
            $data = array(
                'status' => $status
            );
             $td = $this->withdraw_request_model->editstatus($data, $id);
         if ($tid || $td) {
                $this->session->set_flashdata('success', 'Thank you for you request. We will get back to you shortly.');
            } else {
                $this->session->set_flashdata('error', 'Something goes wrong. Please try again later.');
            }
            redirect('newListing');
        } else if ($status == 'REJECT') {
            $txn_msg = $this->input->post('txn_msg');
            $amount = $this->input->post('amount');

            $user_id = $this->input->post('user_id');

            $this->load->model('user_model');
            $user_info = $this->user_model->getUser($user_id);

            $update_amt = $user_info[0]->cash_winning + $amount;
              $wallet_amount = $user_info[0]->cash_winning+$user_info[0]->add_cash+$user_info[0]->referral_bonus+$user_info[0]->cash_bonus;
           

            if ($update_amt < 0) {
                $update_amt = 0;
            }
            $user_data = array(
                'cash_winning' => $update_amt
            );
            $name = $user_info[0]->name;
            $to = $user_info[0]->email;

            $userid = $user_info[0]->id;

            $postData = '';
            $params = array(
                'title' => 'Your Withdraw  Request Rejected successfully',
                'msg' => $txn_msg,
                'image' => null,
                'user_id' => $user_id
            );


            $postData = http_build_query($params);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_POST, count($postData));
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

            $output = curl_exec($ch);
            $output_data [] = json_decode($output);
            curl_close($ch);

            $params = array(
                'title' => 'Your Withdraw  Request Rejected successfully',
                'message' => $txn_msg,
                'user_id' => $user_id
            );



            $this->load->model('notification_model');
            $nid = $this->notification_model->addNewNotification($params);
            $txn_id = round(microtime(true) * 1000);
            $trans = array(
                'txn_status' => 'FAILED',
                'cash_bonus' =>$user_info[0]->cash_bonus,
                'referral_bonus' =>$user_info[0]->referral_bonus,
                'wallet_amount' =>$wallet_amount,
                'add_cash' =>$user_info[0]->add_cash,
                'txn_msg' =>  $txn_msg ,
                 'winning_amount' => $user_info[0]->cash_winning
                
            );

            $this->load->model('transaction_model');
            $tid = $this->transaction_model->editTransStatus($trans, $id);
            $this->subject = "Withdraw Reject confirmation!";
            $msg = "Sorry, Your withdraw request is rejected on this below reason.<br>Reason:'.$txn_msg.'";
            $email_data = array(
                'name' => $name,
                'msg' => $msg,
            );
            $message = $this->load->view('emailView', $email_data, TRUE);
            mail($to, $this->subject, $message, $this->headers);
            $data = array(
                'status' => $status,
                'msg' => $txn_msg
            );
            $td = $this->withdraw_request_model->editstatus($data, $id);
            $ud = $this->user_model->editAppUser($user_data, $user_id);
        }
        if ($td || $ud) {
            $this->session->set_flashdata('success', 'Thank you for you request. We will get back to you shortly.');
        } else {
            $this->session->set_flashdata('error', 'Something goes wrong. Please try again later.');
        }
        redirect('newListing');
    }

    /** function for pending request* */
    function changestatus1() {

        $this->load->model('withdraw_request_model');
        $id = $this->input->post('t_id');
        $user_id = $this->input->post('user_id');
        $status = $this->input->post('status');
        $payBy = $this->input->post('payBy');
        $amount = $this->input->post('amount');

        $txn_msg = $this->input->post('txn_msg');
        if ($status == 'ACCEPT') {
            $this->load->model('user_model');
            $user_info = $this->user_model->getUser($user_id);
            $name = $user_info[0]->name;
            $to = $user_info[0]->email;
            $userid = $user_info[0]->id;
            $refund_msg = 'Your withdraw request of Rs. ' . $amount . 'is accepted and credited to your bank account.';
            $postData = '';
            $params = array(
                'title' => 'Your Withdraw  Request Accept successfully',
                'msg' => $refund_msg,
                'image' => null,
                'user_id' => $userid
            );

            $postData = http_build_query($params);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_POST, count($postData));
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

            $output = curl_exec($ch);
            $output_data [] = json_decode($output);
            curl_close($ch);

            $params = array(
                'title' => 'Your Withdraw  Request Accept successfully',
                'message' => $refund_msg,
                'user_id' => $userid
            );

            $this->load->model('notification_model');
            $nid = $this->notification_model->addNewNotification($params);
            $txn_id = round(microtime(true) * 1000);
            $trans = array(
                'txn_status' => 'SUCCESS',
            );
            $this->load->model('transaction_model');
            $tid = $this->transaction_model->editTransStatus($trans,$id);
           
            $this->subject = "Withdraw Accept confirmation!";
            $msg = "Congratulation, Your withdraw request is accpected and your Rs ' . $amount . ' deposited to your wallet.";
            $email_data = array(
                'name' => $name,
                'msg' => $msg,
            );

            $message = $this->load->view('emailView', $email_data, TRUE);

            mail($to, $this->subject, $message, $this->headers);

            mail($to, $this->subject, $message, $this->headers);
            $data = array(
                'status' => 'COMPLETED',
                'payBy' => $payBy
            );

            $td = $this->withdraw_request_model->editstatus($data, $id);
        }

        if ($td) {
            $this->session->set_flashdata('success', 'Thank you for you request. We will get back to you shortly.');
        } else {
            $this->session->set_flashdata('error', 'Something goes wrong. Please try again later.');
        }
        redirect('pendingListing');
    }

}
?>