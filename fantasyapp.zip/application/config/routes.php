<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "login";
$route['404_override'] = 'error';


/*********** USER DEFINED ROUTES *******************/

$route['loginMe'] = 'login/loginMe';
$route['dashboard'] = 'user';
$route['logout'] = 'user/logout';
$route['userListing'] = 'user/userListing';
$route['userListing/(:num)'] = "user/userListing/$1";
$route['addNew'] = "user/addNew";
$route['appUserListing'] = 'user/appUserListing';
$route['viewAppUser/(:num)'] = 'user/viewAppUser/$1';
$route['showTransaction'] = "user/showTransaction";

$route['seriesListing'] = 'series/seriesListing';
$route['seriesListing/(:num)'] = "series/seriesListing/$1";
$route['newSeries'] = "series/newSeries";
$route['addNewSeries'] = "series/addNewSeries";
$route['editOldSeries'] = "series/editOldSeries";
$route['editOldSeries/(:num)'] = "series/editOldSeries/$1";
$route['editSeries'] = "series/editSeries";
$route['getallMatchesBySeries/(:num)'] = "series/getallMatchesBySeries/$1";
$route['testSite'] = "test";

$route['fetchNewMatches'] = 'match/newMatchCron';
$route['addMatch'] = 'match/addMatch';
$route['liveMatchCron'] = 'match/liveMatchCron';

$route['upcommingMatches'] = 'match/matchListing/upcomming';
$route['liveMatches'] = 'match/matchListing/live';
$route['resultMatches'] = 'match/matchListing/result';
$route['cancelMatches'] = 'match/matchListing/cancel';
$route['upcommingMatches/(:num)'] = "match/matchListing/upcomming/$1";
$route['liveMatches/(:num)'] = "match/matchListing/live/$1";
$route['resultMatches/(:num)'] = "match/matchListing/result/$1";
$route['cancelMatches/(:num)'] = "match/matchListing/cancel/$1";
$route['editOldMatch'] = "match/editOldMatch";
$route['addDefaultLeague'] = "match/addDefaultLeague";
$route['editOldMatch/(:num)'] = "match/editOldMatch/$1";
$route['playerInfo/(:num)'] = "match/playerInfo/$1";
//$route['editPlayercredits/(:num)/(:any)'] = "match/editPlayercredits/$1";
$route['editMatch'] = "match/editMatch";
$route['deleteOldMatch/(:num)'] = "match/deleteOldMatch/$1";
$route['viewResultMatch/(:num)'] = "match/viewResultMatch/$1";
$route['addNewPlayer1'] = "match/addNewPlayer1";

$route['editPlayer'] = "match/editPlayer";
$route['setPlayer'] = "match/setPlayer";
$route['setPlayer1'] = "match/setPlayer1";
$route['deletePlayer'] = "match/deletePlayer";

$route['newLeague'] = "league/newLeague";
$route['addNewLeague'] = "league/addNewLeague";
$route['leagueListing'] = 'league/leagueListing';

$route['leagueListing/(:num)'] = "league/leagueListing/$1";
$route['editOldLeague'] = "league/editOldLeague";
$route['editOldLeague/(:num)'] = "league/editOldLeague/$1";
$route['editLeague'] = "league/editLeague";
$route['joinedTeams/(:num)'] = "league/joined_teams/$1";
$route['settledMatch'] = "league/settledMatch";
$route['refundAmount'] = "league/refundAmount";
$route['viewPlayers/(:num)'] = "league/viewPlayers/$1";
$route['winners/(:num)'] = "league/winners_list/$1";
$route['getMatchList'] = "league/getMatchList";
$route['showLeague'] = "league/showLeague";
$route['editStatus'] = "league/editStatus";
$route['deleteOldLeague/(:num)'] = "league/deleteOldLeague/$1";
$route['deleteOldLeague2/(:num)'] = "league/deleteOldLeague2/$1";
$route['addTemp'] = "league/addtemplate";

$route['newcontestType'] = "contest/newcontestType";
$route['addnewcontestType'] = "contest/addnewcontestType";
$route['typeListing'] = "contest/typeListing";
$route['editOldType'] = "contest/editOldType";
$route['editOldType/(:num)'] = "contest/editOldType/$1";
$route['editType'] = "contest/editType";
$route['delType/(:num)'] = "contest/delType/$1";

$route['playerListing'] = 'players/playerListing';
$route['addNewPlayer'] = "players/addNewPlayer";
$route['playerListing/(:num)'] = "players/playerListing/$1";
$route['editOldPlayer'] = "players/editOldPlayer";
$route['editOldPlayer/(:num)'] = "players/editOldPlayer/$1";
$route['editPlayer'] = "players/editPlayer";
$route['withdrawListing'] = 'Withdraw/withdrawListing';
$route['newListing'] = 'withdraw/newListing';
$route['pendingListing'] = 'withdraw/pendingListing';
$route['completeListing'] = 'withdraw/completeListing';
$route['rejectedListing'] = 'withdraw/rejectedListing';
$route['withdrawListing/(:num)'] = "Withdraw/withdrawListing/$1";
$route['withdrawRequestListing'] = "withdraw/withdrawRequestListing";
$route['withdrawChange'] = "withdraw/withdrawChange";
$route['deleteOldPlayer/(:num)'] = "players/deleteOldPlayer/$1";

$route['send_notification'] = 'notification/send_notification';
$route['notify_user'] = 'notification/notify_user';

$route['bankVerification'] = 'bankverify/bankVerification';
$route['bankVerification2'] = 'bankverify/bankVerification2';
$route['bankVerifyEdit/(:num)'] = 'bankverify/bankVerifyEdit/$1';
$route['bankEdit'] = 'bankverify/bankEdit';

$route['storePoints'] = 'match/getPoints';
$route['storePoints2/(:num)'] = 'match/getPoints2/$1';

$route['addNewUser'] = "user/addNewUser";
$route['editOld'] = "user/editOld";
$route['editOld/(:num)'] = "user/editOld/$1";
$route['editUser'] = "user/editUser";
$route['deleteUser'] = "user/deleteUser";
$route['loadChangePass'] = "user/loadChangePass";
$route['changePassword'] = "user/changePassword";
$route['pageNotFound'] = "user/pageNotFound";
$route['checkEmailExists'] = "user/checkEmailExists";

$route['forgotPassword'] = "login/forgotPassword";
$route['resetPasswordUser'] = "login/resetPasswordUser";
$route['resetPasswordConfirmUser'] = "login/resetPasswordConfirmUser";
$route['resetPasswordConfirmUser/(:any)'] = "login/resetPasswordConfirmUser/$1";
$route['resetPasswordConfirmUser/(:any)/(:any)'] = "login/resetPasswordConfirmUser/$1/$2";
$route['createPasswordUser'] = "login/createPasswordUser";

$route['flagListing'] = "flag/flagListing";
$route['addNewFlag'] = "flag/addNewFlag";
$route['newflag'] = "flag/newflag";
$route['flagListing/(:num)'] = "flag/flagListing/$1";
$route['editOldFlag'] = "flag/editOldFlag";
$route['editOldFlag/(:num)'] = "flag/editOldFlag/$1";
$route['editFlag'] = "flag/editFlag";
$route['deleteOldFlag/(:num)'] = "flag/deleteOldFlag/$1";
$route['testEmaail'] = 'SendEmail/testEmaail';


$route['newdefaultLeague'] = "DefaultLeague/newdefaultLeague";
$route['addNewdefaultLeague'] = "DefaultLeague/addNewdefaultLeague";
$route['defaultleagueListing'] = 'DefaultLeague/defaultleagueListing';
$route['defaultleagueListing/(:num)'] = "DefaultLeague/defaultleagueListing/$1";

$route['newbanner'] = "banner/newbanner";
$route['bannerListing'] = "banner/bannerListing";
$route['addNewBanner'] = "banner/addNewBanner";
$route['bannerListing/(:num)'] = "banner/bannerListing/$1";
$route['editOldBanner'] = "banner/editOldBanner";
$route['editOldBanner/(:num)'] = "banner/editOldBanner/$1";
$route['editBanner'] = "banner/editBanner";
$route['deleteOldBanner/(:num)'] = "banner/deleteOldBanner/$1";
$route['editOldstatus/(:num)'] = "banner/editOldstatus/$1";
$route['statusChange'] = "banner/statusChange";

$route['newUser'] = "admin/newUser";
$route['adminListing'] = "admin/adminListing";
$route['addNewUser'] = "admin/addNewUser";
$route['editOldUser'] = "admin/editOldUser";
$route['editOldUser/(:num)'] = "admin/editOldUser/$1";
$route['editUser'] = "admin/editUser";
$route['deleteOldUser/(:num)'] = "admin/deleteOldUser/$1";
$route['settingList'] = "setting/settingList";

$route['editSetting'] = "setting/editSetting";
//$route['newbanner'] = "referrals/newbanner";
//$route['referralListing'] = "referrals/referralListing";
/* End of file routes.php */
/* Location: ./application/config/routes.php */