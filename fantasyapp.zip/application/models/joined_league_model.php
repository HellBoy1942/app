<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Joined_league_model extends CI_Model
{
    /**
     * This function is used to get the joined team listing
     * @return array $result : This is result
     */
    function joinedTeamList()
    {
        $this->db->select();
        $this->db->from('contest_joined as BaseTbl');
        $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function used to get joined teamsby league id
     * @param number $id : This is league id
     * @return array $result : This is joined teams
     */
    function getByLeague($id)
    {
        $this->db->select();
        $this->db->from('contest_joined as BaseTbl');
        $this->db->where('BaseTbl.league_id', $id);
        
        //$this->db->order_by("BaseTbl.rank", "Asc");
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to delete the joined info
     * @param number $id : This is league id
     */
    function deleteByLeague($id)
    {
        $this->db->where('league_id', $id);
        $this->db->delete('contest_joined', $data);
        
        return TRUE;
    }

}

  