<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Notification_model extends CI_Model
{
    /**
     * This function is used to get the league listing count
     * @return number $count : This is row count
     */
    function notificationListing()
    {
        $this->db->select();
        $this->db->from('notification as BaseTbl');
        $this->db->order_by("BaseTbl.created_dt", "desc");
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to add new notification to system
     * @param array $data : This is notification data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addNewNotification($data)
    {
        $this->db->trans_start();
        $this->db->insert('notification', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get notification information by id
     * @param number $id : This is id
     * @return array $result : This is notification information
     */
    function getNotificationInfo($id)
    {
        $this->db->select();
        $this->db->from('notification');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }

}

  