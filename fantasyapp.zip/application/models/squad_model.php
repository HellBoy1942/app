<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Squad_model extends CI_Model
{
    
    
    /**
     * This function is used to add new squads to system
     * @param array $data : This is squad data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addSquad($data)
    {
        $this->db->trans_start();
        $this->db->insert('squad', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get all squads
     * @return array $result : This is squad data
     */
    function getAllSquads()
    {
        $this->db->select();
        $this->db->from('squad as BaseTbl');
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * This function used to get squad information by match_id
     * @param number $id : This is match id
     * @return array $result : This is squad information
     */
    function getSquadByMatch($id)
    {
        $this->db->select();
        $this->db->from('squad');
        $this->db->where('match_id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    function updateSquad($data, $id) {
        $this->db->set('players1',$data);
        $this->db->where('match_id', $id);
        $this->db->update('squad');

        return TRUE;
    }

    function updateSquad1($data, $id) {
        $this->db->set('players2',$data);
        $this->db->where('match_id', $id);
        $this->db->update('squad');

        return TRUE;
    }

}

  