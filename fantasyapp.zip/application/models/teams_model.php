<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Teams_model extends CI_Model
{
    /**
     * This function is used to get teams list
     * @return array $result : This is result
     */
    function teamListing()
    {
        $this->db->select();
        $this->db->from('teams as BaseTbl');
        $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function used to get teams info by team id
     * @param number $id : This is team id
     * @return array $result : This is team object
     */
    function getByTeamId($id)
    {
        $this->db->select();
        $this->db->from('teams as BaseTbl');
        $this->db->where('BaseTbl.id', $id);
        $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->get();
        
        return $query->result();
    }

}

  