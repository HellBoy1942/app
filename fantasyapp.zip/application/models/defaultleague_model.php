<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class DefaultLeague_model extends CI_Model
{
    /**
     * This function is used to get the league listing count
     * @return number $count : This is row count
     */
    function defaultleagueListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.id');
        $this->db->from('contests as BaseTbl');
        if(!empty($searchText)) {
            // //$likeCriteria = "(BaseTbl.id  LIKE '%".$searchText."%' OR BaseTbl.name  LIKE '%".$searchText."%')";
            // $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%')";
            // $this->db->where($likeCriteria);
            // $this->db->like('BaseTbl.id',$searchText);
            $this->db->or_like('BaseTbl.name',$searchText);
            $this->db->or_like('BaseTbl.type',$searchText);
            $this->db->or_like('BaseTbl.match_id',$searchText); 
        }
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the league listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function defaultleagueListing($searchText = '')
    {
        $this->db->select('contests.*,league_type.league_name');
        $this->db->from('contests');
        $this->db->join('league_type ', 'contests.type_id = league_type.id', 'inner');
        //SELECT C.*,L.league_name FROM `contests` as C INNER JOIN league_type as L where C.type_id = L.id
        if (!empty($searchText)) {
            // //$likeCriteria = "(BaseTbl.id  LIKE '%".$searchText."%' OR BaseTbl.name  LIKE '%".$searchText."%')";
            // $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%')";

            $this->db->or_like('contests.name', $searchText);
            $this->db->or_like('contests.type', $searchText);
            $this->db->or_like('contests.match_id', $searchText);
            
            }

        //$this->db->limit($page, $segment);
        $this->db->order_by("contests.created", "desc");
        $this->db->where('is_default','yes');
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    
    
    /**
     * This function is used to add new matches to system
     * @param array $data : This is match data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addNewLeague($data)
    {
        $this->db->trans_start();
        $this->db->insert('contests', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get league information by id
     * @param number $id : This is id
     * @return array $result : This is league information
     */
    function getLegueInfo($id)
    {
        $this->db->select();
        $this->db->from('contests');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function used to get league information by match id
     * @param number $id : This is match id
     * @return array $result : This is league information
     */
    function getLegueByMatch($id)
    {
        $this->db->select();
        $this->db->from('contests as BaseTbl');
        $this->db->where('BaseTbl.match_id', $id);
        $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * This function is used to update the league information
     * @param array $data : This is league data to be updated
     * @param number $id : This is id
     */
    function editLeague($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('contests', $data);
        
        return TRUE;
    }

    /**
     * This function is used to delete the league
     * @param number $id : This is id
     */
    function deleteLeague($id)
    {
           $this->db->query("update  contests set is_default='NO' WHERE id = $id");
       return true;

    }
    function deleteleague2($value='')
    {
        if($this->db->where(array('id'=>$value))->delete('contests'))
            return true;
        else
            return false;

    }

}

  