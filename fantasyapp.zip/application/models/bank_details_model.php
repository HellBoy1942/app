<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Bank_details_model extends CI_Model
{
    /**
     * This function is used to get the bank detail listing
     * @return array $result : This is result
     */
    function bankDetailList()
    {
        // $this->db->select();
        // $this->db->from('bank_details as BaseTbl')->where("'BaseTbl.is_bank_verify Rlike 'FAILED|SUCCESS'");
        // //->not_like(array('BaseTbl.is_bank_verify'=>'FAILED'))->or_not_like(array('BaseTbl.is_bank_verify'=>'SUCCESS'));
        // $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->query("SELECT * FROM `bank_details` WHERE `is_bank_verify` not Rlike 'FAILED|SUCCESS' ORDER BY `created` desc");
        
        $result = $query->result();        
        return $result;
    }
    function bankDetailList2()
    {
        $this->db->select();
        $this->db->from('bank_details as BaseTbl');
        $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }


    /**
     * This function is used to update the bank detail information
     * @param array $data : This is bank detail data to be updated
     * @param number $id : This is the id
     */
    function editBankDetails($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('bank_details', $data);
        
        return TRUE;
    }

  function editBankDetails1($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('bank_details', $data);
        
        return TRUE;
    }
    /**
     * This function used to get bank details by id
     * @param number $id : This is league id
     * @return array $result : This is joined teams
     */
    function getById($id)
    {
        $this->db->select();
        $this->db->from('bank_details as BaseTbl');
        $this->db->where('BaseTbl.id', $id);
        $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to delete bank detail
     * @param number $id : This is league id
     */
    function deleteById($id)
    {
        $this->db->where('league_id', $id);
        $this->db->delete('bank_details', $data);
        
        return TRUE;
    }
    
    function getPanverifybonus(){

       $this->db->select('pan_verify_bonus');
        $this->db->from('app_settings as BaseTbl');
        $query = $this->db->get();
        
        return $query->result();  
    }
    function getBankdetailbonus(){

       $this->db->select('bank_verify_bonus');
        $this->db->from('app_settings as BaseTbl');
        $query = $this->db->get();
        
        return $query->result();  
    }

}

  