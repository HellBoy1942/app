<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    /**
     * This function is used to get the bank detail listing
     * @return array $result : This is result
     */
    function admindetaillist()
    {
        $this->db->select();
        $this->db->from('tbl_users as BaseTbl');
        $this->db->order_by("BaseTbl.createdBy", "asc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }


    /**get role from tbl_role**/
    function getMenu(){
         $this->db->select();
        $this->db->from('tbl_menu as BaseTbl');
        $this->db->where('sub_menu_id','0');
        $this->db->order_by("BaseTbl.menu_id", "asc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    

    /** add new flag**/
    function addNewuser($data)
    {
        
        /*$this->db->insert('team_flags', $data);
        return true;
            */    

        $this->db->trans_start();
        $this->db->insert('tbl_users', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get flag information by id
     * @param number $id : This is flag id
     * @return array $result : This is flag information
     */
    function getuserInfo($id)
    {
        $this->db->select();
        $this->db->from('tbl_users');
        $this->db->where('userId', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
     


    /**
     * This function is used to update the bank detail information
     * @param array $data : This is bank detail data to be updated
     * @param number $id : This is the id
     */
    function editUser($data, $id)
    {
        $this->db->where('userId', $id);
        $this->db->update('tbl_users', $data);
        
        return TRUE;
    }

    /**
     * This function used to get bank details by id
     * @param number $id : This is league id
     * @return array $result : This is joined teams
     */
    function getById($id)
    {
        $this->db->select();
        $this->db->from('tbl_users as BaseTbl');
        $this->db->where('BaseTbl.id', $id);
        $this->db->order_by("BaseTbl.date_time", "desc");
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to delete flag
     * @param number $id : This is flag id
     */
    function deleteUser($id)
    {
        $this->db->where('userId', $id);
        $this->db->delete('tbl_users');
        
        return TRUE;
    }


}

  