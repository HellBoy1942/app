<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class League_model extends CI_Model {

    /**
     * This function is used to get the league listing count
     * @return number $count : This is row count
     */
    function leagueListingCount($searchText = '') {
        $this->db->select('BaseTbl.id');
        $this->db->from('contests as BaseTbl');
        
        if (!empty($searchText)) {
            // //$likeCriteria = "(BaseTbl.id  LIKE '%".$searchText."%' OR BaseTbl.name  LIKE '%".$searchText."%')";
            // $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%')";
            // $this->db->where($likeCriteria);
            // $this->db->like('BaseTbl.id',$searchText);
            $this->db->or_like('BaseTbl.name', $searchText);
            $this->db->or_like('BaseTbl.type', $searchText);
            $this->db->or_like('BaseTbl.match_id', $searchText);
        }
        $query = $this->db->get();

        return count($query->result());
    }

    /**
     * This function is used to get the league listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function leagueListing($searchText = '') {
        $this->db->select('contests.*,league_type.league_name');
        $this->db->from('contests');
        $this->db->join('league_type ', 'contests.type_id = league_type.id', 'inner');
        //SELECT C.*,L.league_name FROM `contests` as C INNER JOIN league_type as L where C.type_id = L.id
        if (!empty($searchText)) {
            // //$likeCriteria = "(BaseTbl.id  LIKE '%".$searchText."%' OR BaseTbl.name  LIKE '%".$searchText."%')";
            // $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%')";

            $this->db->or_like('contests.name', $searchText);
            $this->db->or_like('contests.type', $searchText);
            $this->db->or_like('contests.match_id', $searchText);
        }

        
        $this->db->order_by("contests.created", "desc");
        $query = $this->db->get();


        $result = $query->result();
        return $result;
    }

    function leagueInfo($id) {
        $this->db->select();
        $this->db->from('contests as BaseTbl');
        $this->db->where('match_id', $id);
        $query = $this->db->get();

        $result = $query->result_array();
        return $result;
    }

    /**
     * This function is used to add new matches to system
     * @param array $data : This is match data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addNewLeague($data) {
        $this->db->trans_start();
        $this->db->insert('contests', $data);

        $insert_id = $this->db->insert_id();

        $this->db->trans_complete();

        return $insert_id;
    }

    /**
     * This function used to get league information by id
     * @param number $id : This is id
     * @return array $result : This is league information
     */
    function getLegueInfo($id) {

        $this->db->select();
        $this->db->from('contests');
        $this->db->where('id', $id);
        $query = $this->db->get();

        return $query->result();
    }
    function getContestJoinedUserList($league_id) {

        $this->db->select();
        $this->db->from('contest_joined');
        $this->db->where('league_id', $league_id);
        $query = $this->db->get();
        return $query->result();
    }


    function getLegueInfobyId($id)
    {

        $this->db->select();
        $this->db->from('contests');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result_array();
    }
    function getleagueInfobyId($id) {

        $this->db->select();
        $this->db->from('contest_joined');
        $this->db->where('league_id', $id);
        $query = $this->db->get();

        return $query->result();
    }

    function getLeagueByContest($id) {
        $where = array(
            'match_id' => $id,
            'cancel_contest' => '1'
        );
        $this->db->select();
        $this->db->from('contests as BaseTbl');
        $this->db->where($where);
        

        $query = $this->db->get();

        $result = $query->result_array();
        return $result;
    }

    function getCountOfLeague($league_id) {
        $this->db->select();
        $this->db->from('contest_joined');
        $this->db->where('league_id', $league_id);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;
    }

    function updateStatus($data, $id) {
        $this->db->where('id', $id);
        $this->db->update('contests', $data);

        return TRUE;
    }

    /**
     * This function is used to add winner configs to system
     * @param array $data : This is config data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addWinnerConfig($data) {
        $this->db->trans_start();
        $this->db->insert('winner_breakup', $data);

        $insert_id = $this->db->insert_id();

        $this->db->trans_complete();

        return $insert_id;
    }

    /**
     * This function used to get league information by match id
     * @param number $id : This is match id
     * @return array $result : This is league information
     */
    function getLegueByMatch($id) {
        $this->db->select();
        $this->db->from('contests as BaseTbl');
        $this->db->where('BaseTbl.match_id', $id);
        $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * This function is used to update the league information
     * @param array $data : This is league data to be updated
     * @param number $id : This is id
     */
    function editLeague($data, $id) {
        $this->db->where('id', $id);
        $this->db->update('contests', $data);

        return TRUE;
    }

    function getdefaultLeague() {
        $this->db->select();
        $this->db->from('contests');
        
        $this->db->where('is_default', 'YES');
        $query = $this->db->get();

        return $query->result_array();
    }

   
    function getMatchIdByLeague($id) {
        $this->db->select('match_id');
        $this->db->from('contests');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * This function is used to update the league information
     * @param array $data : This is league data to be updated
     * @param number $id : This is id
     */
    function editLeaguestatus($status, $id) {
        $this->db->set('status', $status);
        $this->db->where('id', $id);
        $this->db->update('contests');

        return TRUE;
    }

    function editStatus_league($data, $id) {

        $this->db->where('id', $id);
        $this->db->update('contests', $data);

        return TRUE;
    }

    function deleteLeague($id) {
         $this->db->query("DELETE contests, winners, winner_breakup FROM contests INNER JOIN winners ON contests.id = winners.contest_id INNER JOIN winner_breakup ON contests.id = winner_breakup.contest_id WHERE contests.id = $id");
       return true;
    }
    function auto($value='')
    {
        if($this->db->insert('autorepeat',$value))
            return true;
        else
            return false;        
    }
    function getrepeats($value='')
    {
        $ab=$this->db->get('autorepeat');
        return $ab->result();
    }
    function updrepeat($value='',$v2='')
    {
        $ab=$this->db->where(array('aid'=>$value))->update('autorepeat',$v2);
        if($ab)
            return true;
        else
            return false;
    }
    function svtemplate($value='')
    {
        $tps='insert into                 template(                    type,type_id,is_default,name,winning_amount,contest_size,settled,refund,winner,entry_fees,commission,total_margin,fresh_margin,gst_amount,status,multi_joined,cancel_contest,cancel_desc,invite_code,user_id                ) select                  type,type_id,is_default,name,winning_amount,contest_size,settled,refund,winner,entry_fees,commission,total_margin,fresh_margin,gst_amount,status,multi_joined,cancel_contest,cancel_desc,invite_code,user_id                 from contests                 where contests.id='.$value;
        $ab=$this->db->query($tps);
        if($ab)
            return true;
        else
            return false;
    }
    function gettemp($value='')
    {
        $ab=$this->db->get('template');
        return $ab->result();
    }
    function svcontest($value='',$v2='')
    {
        $ary=array('match_id'=>$v2);
        $ary=array_merge($ary,$value);
        $ab=$this->db->insert('contests',$ary);
        if($ab)
            return true;
        else
            return false;
    }
    function gettempbyid($value='')
    {
        $ab=$this->db->where(array('tid'=>$value))->get('template');
        return $ab;
    }
    function getmatchbyid($value='')
    {
        $ab=$this->db->where(array('match_id'=>$value))->get('matches');
        return $ab;
    }

}
