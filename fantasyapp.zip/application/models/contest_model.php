<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Contest_model extends CI_Model
{
    /**
     * This function is used to get the series listing count
     * @return number $count : This is row count
     */
    function typeListingCount()
    {
        $this->db->select('BaseTbl.id');
        $this->db->from('league_type as BaseTbl');
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the series listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function typeListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id, BaseTbl.league_name,BaseTbl.type,BaseTbl.arrange,BaseTbl.created,BaseTbl.image, BaseTbl.slug,  BaseTbl.status');
        $this->db->from('league_type as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->limit($page, $segment);
        $this->db->order_by("BaseTbl.created", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

   

    /**
     * This function is used to add new series to system
     * @param array $data : This is series data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addnewcontestType($data)
    {
        $this->db->trans_start();
        $this->db->insert('league_type', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    function getType(){
        $this->db->select();
        $this->db->from('league_type as BaseTbl');
        $this->db->order_by("BaseTbl.created", "desc");
        $this->db->where('league_name != ','Private Contest');
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    
    function getTypeInfo($id){
        $this->db->select('id, league_name, created, slug, image,type, status,arrange');
        $this->db->from('league_type');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
    /**
     * This function is used to update the series information
     * @param array $data : This is series data to be updated
     * @param number $id : This is series id
     */
    function editType($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('league_type', $data);
        
        return TRUE;
    }
    function deltype($value='')
    {
        if($this->db->where(array('id'=>$value))->delete('league_type'))
            return true;
        else
            return false;
    }

     
}

  