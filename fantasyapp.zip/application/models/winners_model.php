<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Winners_model extends CI_Model
{
    
    
    /**
     * This function is used to add winners to system
     * @param array $data : This is winners data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addWinnerList($data)
    {
        $this->db->trans_start();
        $this->db->insert('winners', $data);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return $insert_id;
    }
     function getWinnerByLeague($id){
      $this->db->select();
        $this->db->from('winners as BaseTbl');
        $this->db->where('BaseTbl.contest_id', $id);
       
        $query = $this->db->get();
        return $query->result_array();  
    }
    

    /**
     * This function used to get all winners
     * @return array $result : This is winner data
     */
    function getAllWinners()
    {
        $this->db->select();
        $this->db->from('winners as BaseTbl');
        $query = $this->db->get();
        return $query->result();
    }
     function getwinnerbymatchid($league_id){
                                         // print_r($value1['id']);
         $this->db->select();
        $this->db->from('winner_breakup');
        $this->db->where('contest_id', $league_id);
        $query = $this->db->get();
        return $query->result_array(); 
    }
    /**
     * This function used to get all winners
     * @param number $id : This is league id
     * @return array $result : This is winner data
     */
    function getWinnersByLeague($id)
    {
        $this->db->select();
        $this->db->from('winners as BaseTbl');
        $this->db->where('BaseTbl.contest_id', $id);
        $this->db->order_by('BaseTbl.rank', 'asc');
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * This function used to get all winners
     * @param number $id : This is league id
     * @param number $rank : This is rank
     * @return array $result : This is winner data
     */
    function getWinnersByTeam($id, $rank)
    {
        $this->db->select();
        $this->db->from('winners as BaseTbl');
        $this->db->where('BaseTbl.contest_id', $id);
        $this->db->where('BaseTbl.rank', $rank);
        $query = $this->db->get();
        return $query->result();
    }
    /**
     * This function used to get all winners
     * @param number $id : This is league id
     * @return array $result : This is winner data
     */
    function deleteWinnersByLeague($id)
    {
        $this->db->where('contest_id', $id);
        $this->db->delete('winners');
        return TRUE;
    }

}

  