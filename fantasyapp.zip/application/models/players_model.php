<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Players_model extends CI_Model {

    /**
     * This function is used to add new player to system
     * @param array $data : This is player data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addPlayer($data, $player_info, $pints_data) {
        $this->db->trans_start();
        if (empty($player_info)) {
            $this->db->insert('players', $data);
        }
        else{
         
         //$this->editPlayer($data, $data['p_id']);
        }
        $this->db->insert('points_calculation', $pints_data);
        $insert_id = $this->db->insert_id();

        $this->db->trans_complete();

        return $insert_id;
    }

    function addPlayerInPointsCalculation($pints_data) {
        $this->db->trans_start();
        $this->db->insert('points_calculation', $pints_data);
        $insert_id = $this->db->insert_id();

        $this->db->trans_complete();

        return $insert_id;
    }
    
    function addNewPlayers($data)
    {
        $this->db->trans_start();
        $this->db->insert('players', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get all players
     * @return array $result : This is player data
     */
    function getAllPlayers() {
        $this->db->select();
        $this->db->from('players as BaseTbl');
        $query = $this->db->get();
        return $query->result();
    }
    
     /**
     * This function used to check player id exists or not
     * @param {string} $p_id : This is users email id
     * @return {boolean} $result : TRUE/FALSE
     */
    function checkPlayerIdExists($p_id)
    {
        $this->db->select('p_id');
        $this->db->where('p_id', $p_id);
        $query = $this->db->get('players');

        if ($query->num_rows() > 0){
            return true;
        } else {
            return false;
        }
    }
    
    
    
    function getplayersByPlayerId($p_id) {
        $this->db->select();
        $this->db->from('players');
        $this->db->where('p_id', $p_id);
       
        $query = $this->db->get();

        return $query->result();
    }
    
     function getplayer1ByMatch($id,$team1)
    {
        $this->db->select();
        $this->db->from('points_calculation');
        $this->db->where('match_id', $id);
        $this->db->where('country', $team1);
        $query = $this->db->get();
        
        return $query->result();
    }
    function getplayer2ByMatch($id,$team2)
    {
        $this->db->select();
        $this->db->from('points_calculation');
        $this->db->where('match_id', $id);
        $this->db->where('country', $team2);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function used to get country list
     * @return array $result : This is country list
     */
    function getCountryList() {
        $this->db->select('DISTINCT(`country`)');
        $this->db->from('players');
        $query = $this->db->get();
        $data[''] = '-- Select Country Name --';
        foreach ($query->result_array() as $row) {
            $data[$row['country']] = $row['country'];
        }
        return $data;
    }

    /**
     * This function used to get players information by country
     * @param string $id : This is country
     * @return array $result : This is player information
     */
    function getPlayersByCountry($country) {
        $this->db->select();
        $this->db->from('players');
        $this->db->where('country', $country);
        $query = $this->db->get();

        return $query->result();
    }

    /**
     * This function used to get players information by p_id
     * @param string $id : This is the p_id
     * @return array $result : This is player information
     */
    function getPlayersByPid($pid) {
        $this->db->select();
        $this->db->from('players');
        $this->db->where('p_id', $pid);
        $query = $this->db->get();

        return $query->result();
    }
    function getPlayersByMatchId($match_id) {
        $this->db->select('players1');
        $this->db->from('squad');
        $this->db->where('match_id', $match_id);
       
        $query = $this->db->get();

        return $query->result();
    }
    
    function getPlayersByMatchId1($match_id) {
        $this->db->select('players2');
        $this->db->from('squad');
        $this->db->where('match_id', $match_id);
       
        $query = $this->db->get();

        return $query->result();
    }

    /**
     * This function is used to update the player information
     * @param array $data : This is player data to be updated
     * @param number $id : This is player id
     */
    function editPlayer($data, $id) {
        $ab=$this->db->where('player_id', $id)
        ->update('points_calculation', $data);
        return TRUE;
    }
    
    
    /**
     * This function is used to store the player information 
     * in point calculation table
     * @param array $data : This is player data to be updated
     * @param number $id : This is match id
     * @param number $pid : This is player id
     */
    function storePointsCalc($data, $id, $pid) {
        $this->db->where('player_id', $pid);
        $this->db->where('match_id', $id);
        $this->db->update('points_calculation', $data);
        return TRUE;
    }

    /**
     * This function is used to get the player information 
     * from point calculation table
     * @param number $pid : This is player id
     * @return array $result : This is player information
     */
    function getPcPlayersByPid($pid, $match_id) {
        $this->db->select();
        $this->db->from('points_calculation');
        $this->db->where('player_id', $pid);
        $this->db->where('match_id', $match_id);
        $query = $this->db->get();

        return $query->result();
    }
    /**
     * This function is used to delete the player
     * @param number $id : This is player id
     */
    function deletePlayer($id)
    {
        $this->db->where('p_id', $id);
        $this->db->delete('players');
        
        return TRUE;
    }
    
    
     function deletePlayerfromPoints($player_id)
    {
        
        $this->db->where('player_id', $player_id);
        $this->db->delete('points_calculation');
        
        return TRUE;
    }
    
    /** update player when player id exist**/
     function updatePlayer($data,$id) {
       
        $this->db->where('p_id', $id);
        $this->db->update('players',$data);
        return TRUE;
    }

    /**
     * This function is used to update the player credit
     * @param array $credit : This is player credit to be updated
     * @param number $id : This is player id
     */
    function editCredit($credit,$id) {
        $this->db->set('credit',$credit);
        $this->db->where('p_id', $id);
        $this->db->update('players');
        return TRUE;
    }
    
    /**
     * This function is used to update the player point
     * @param array $points : This is player points to be updated
     * @param number $id : This is player id
     */
    function editPoints($points,$id) {
        $this->db->set('points',$points);
        $this->db->where('p_id', $id);
        $this->db->update('players');
        return TRUE;
    }
    
}
