<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Banner_model extends CI_Model
{
    /**
     * This function is used to get the bank detail listing
     * @return array $result : This is result
     */
    function bannerdetaillist()
    {
        $this->db->select();
        $this->db->from('banners as BaseTbl');
        $this->db->order_by("BaseTbl.create_dt", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }


    /** add new flag**/
    function addNewBanner($data)
    {
        
        /*$this->db->insert('team_flags', $data);
        return true;
            */    

        $this->db->trans_start();
        $this->db->insert('banners', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get flag information by id
     * @param number $id : This is flag id
     * @return array $result : This is flag information
     */
    function getbannerInfo($id)
    {
        $this->db->select();
        $this->db->from('banners');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
     /**
     * This function used to get flag information by id
     * @param number $id : This is flag id
     * @return array $result : This is flag information
     */
    /*function getflag_team1($team1)
    {
        $this->db->select();
        $this->db->from('team_flags');
        $this->db->like('team_name', $team1);
        $query = $this->db->get();
        
        return $query->result();
    }*/
    /**
     * This function used to get flag information by id
     * @param number $id : This is flag id
     * @return array $result : This is flag information
     */
   /* function getflag_team2($team2)
    {
        $this->db->select();
        $this->db->from('banners');
        $this->db->like('team_name', $team2);
        $query = $this->db->get();
        
        return $query->result();
    }*/


    /**
     * This function is used to update the banner detail information
     * @param array $data : This is bank detail data to be updated
     * @param number $id : This is the id
     */
    function editBanner($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('banners', $data);
        
        return TRUE;
    }
    


    /**
     * This function used to get bank details by id
     * @param number $id : This is league id
     * @return array $result : This is joined teams
     */
    function getById($id)
    {
        $this->db->select();
        $this->db->from('banners as BaseTbl');
        $this->db->where('BaseTbl.id', $id);
        $this->db->order_by("BaseTbl.date_time", "desc");
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to delete flag
     * @param number $id : This is flag id
     */
    function deletebanner($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('banners');
        
        return TRUE;
    }


}

  