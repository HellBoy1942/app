<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Transaction_model extends CI_Model
{
    /**
     * This function is used to get the series listing count
     * @return number $count : This is row count
     */
    function withdrawListingCount()
    {
        $this->db->select('BaseTbl.id');
        $this->db->from('transaction as BaseTbl');
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the transaction listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function withdrawListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.txn_id,BaseTbl.id,BaseTbl.txn_msg, BaseTbl.user_id, BaseTbl.txn_amt, BaseTbl.txn_dt,  BaseTbl.txn_status,BaseTbl.txn_type');
        $this->db->from('transaction as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->limit($page, $segment);
        $this->db->order_by("BaseTbl.txn_dt", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    
    /**
     * This function is used to add winners to system
     * @param array $data : This is winners data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addTrans($data)
    {
        $this->db->trans_start();
        $this->db->insert('transaction', $data);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return $insert_id;
    }

    /**
     * This function used to get transactions info
     * @return array $result : This is transaction object
     */
    function getWithdrawRequests()
    {
        $this->db->select();
        $this->db->from('transaction as BaseTbl');
        $this->db->where('txn_type', 'WITHDRAW_REQUEST');
        $this->db->order_by("BaseTbl.txn_dt", "desc");
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function used to get transactions info
     * @return array $result : This is transaction object
     */
    function getWithdrawRequestsById($id)
    {
        $this->db->select();
        $this->db->from('transaction as BaseTbl');
        $this->db->where('txn_type', 'WITHDRAW_REQUEST');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to update the transaction information
     * @param array $data : This is transaction data to be updated
     * @param number $id : This is id
     */
    function editTrans($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('transaction', $data);
        
        return TRUE;
    }
    
    
    function editTransStatus($data, $txn_id)
    {
        $this->db->where('txn_id', $txn_id);
        $this->db->update('transaction', $data);
        
        return TRUE;
    }
    
    function updateStatus($txn_type,$user_id){
      $this->db->where('user_id', $user_id);
        $this->db->update('transaction', $txn_type);
        
        return TRUE;   
    }
     function updateStatus1($txn_type,$user_id){
      $this->db->where('user_id', $user_id);
        $this->db->update('transaction', $txn_type);
        
        return TRUE;   
    }

    /** transcartion information for referral bonus**/
     function getTransaction($user_id){
        $txn_type='REFERRAL_BONUS';
        $data=array(
            'user_id'=>$user_id,
            'txn_type'=> $txn_type
        );
        $this->db->select();
        $this->db->from('transaction');
        //$this->db->where_in('txn_type','REFERRAL_BONUS');
        $this->db->where($data);
        $query = $this->db->get();
        
        return $query->result_array();
        //SELECT txn_amt FROM transaction WHERE txn_type='REFERRAL_BONUS' AND user_id='8'
    }

    /** transcartion information for all user**/
     function getAllTransaction($user_id,$txn_type){
        //$txn_type='REFERRAL_BONUS';
        $data=array(
            'user_id'=>$user_id,
            'txn_type'=> $txn_type
        );
        $this->db->select();
        $this->db->from('transaction');
        //$this->db->where_in('txn_type','REFERRAL_BONUS');
        $this->db->where($data);
        $query = $this->db->get();
        
        return $query->result_array();
        //SELECT txn_amt FROM transaction WHERE txn_type='REFERRAL_BONUS' AND user_id='8'
    }

     /** transcartion information for referral bonus**/
     function getsumAmount($user_id){
        $txn_type='REFERRAL_BONUS';
        //$txn_status='SUCCESS';
        $data=array(
            'user_id'=>$user_id,
            'txn_type'=> $txn_type
            //'txn_status'=>$ $txn_status
        );
        $this->db->select_sum('txn_amt');
        $this->db->from('transaction');
        //$this->db->where_in('txn_type','REFERRAL_BONUS');
        $this->db->where($data);
        $query = $this->db->get();
        
        return $query->result_array();
        //SELECT txn_amt FROM transaction WHERE txn_type='REFERRAL_BONUS' AND user_id='8'
    }

}

  