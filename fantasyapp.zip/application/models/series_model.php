<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Series_model extends CI_Model
{
    /**
     * This function is used to get the series listing count
     * @return number $count : This is row count
     */
    function seriesListingCount()
    {
        $this->db->select('BaseTbl.id');
        $this->db->from('series as BaseTbl');
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the series listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function seriesListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id, BaseTbl.name, BaseTbl.created, BaseTbl.start_dt, BaseTbl.end_dt, BaseTbl.status');
        $this->db->from('series as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->limit($page, $segment);
        $this->db->order_by("BaseTbl.start_dt", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    function getSeriesList()
    {
        $this->db->select('DISTINCT(`name`), BaseTbl.id, BaseTbl.name');
        $this->db->from('series as BaseTbl');
        $this->db->where('status', 'ACTIVE');
        $this->db->order_by("BaseTbl.name", "asc");
        $query = $this->db->get();
        $data[''] = 'Select Series';
        foreach ($query->result_array() as $row) {
            $data[$row['id']] = $row['name'];
        }
        return $data;
    }

    function getSeriesById($id)
    {
        $this->db->select('BaseTbl.id, BaseTbl.name, BaseTbl.created, BaseTbl.start_dt, BaseTbl.end_dt, BaseTbl.status');
        $this->db->from('series as BaseTbl');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
    /** get series by name**/
    function getseries(){
        $this->db->select('DISTINCT(`name`),BaseTbl.id');

        $this->db->from('series as BaseTbl'); 
        $query = $this->db->get();
        $result = $query->result();        
        return $result;

        
    }
    
    /**
     * This function is used to seres name by id
     * @param number $id : This is series id
     * @return string $name : This is series name
     */
    function getSeriesDesc($id)
    {
        $this->db->select('BaseTbl.name');
        $this->db->from('series as BaseTbl');
        $this->db->where('id', $id);
        $query = $this->db->get();
        $name = '--';
        foreach ($query->result_array() as $row) {
            $name = $row['name'];
        }
        return $name;
    }

    /**
     * This function is used to add new series to system
     * @param array $data : This is series data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function addNewSeries($data)
    {
        $this->db->trans_start();
        $this->db->insert('series', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get series information by id
     * @param number $id : This is series id
     * @return array $result : This is series information
     */
    function getSeriesInfo($id)
    {
        $this->db->select('id, name, created, start_dt, end_dt, status');
        $this->db->from('series');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to update the series information
     * @param array $data : This is series data to be updated
     * @param number $id : This is series id
     */
    function editSeries($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('series', $data);
        
        return TRUE;
    }
     

     
}

  