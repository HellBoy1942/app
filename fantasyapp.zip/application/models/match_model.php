<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Match_model extends CI_Model
{
    /**
     * This function is used to get the match listing count
     * @return number $count : This is row count
     */
    function matchsListingCount($searchText = '', $type)
    {
        
        $this->db->select('BaseTbl.match_id');
        $this->db->from('matches as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.match_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
    
        if ($type == 'upcomming') {
            $typeCriteria = "((BaseTbl.matchStarted=0 and BaseTbl.status='UPCOMING'))";
            $this->db->where($typeCriteria);
        }
        if ($type == 'live') {            
            $typeCriteria = "((BaseTbl.matchStarted=1 and BaseTbl.status='LIVE') and BaseTbl.admin_status='APPROVED')";
            $this->db->where($typeCriteria);
        }
        if ($type == 'result') {
            $typeCriteria = "((BaseTbl.matchStarted=1 and BaseTbl.status='FINISH') and BaseTbl.admin_status='APPROVED')";
            $this->db->where($typeCriteria);
        }
         if ($type == 'cancel') {
            $typeCriteria = "((BaseTbl.matchStarted=1 and BaseTbl.status='ABANDONED') and BaseTbl.admin_status='ABANDONED')";
            $this->db->where($typeCriteria);
        }

        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the match listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function matchListing($searchText = '', $type, $page, $segment)
    {
        $this->db->select();
        $this->db->from('matches as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.match_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if ($type == 'upcomming') {
            $typeCriteria = "((BaseTbl.matchStarted=0 and BaseTbl.status='UPCOMING') and BaseTbl.admin_status='APPROVED' or BaseTbl.admin_status='UNAPPROVED')";
            $this->db->where($typeCriteria);
        }
        if ($type == 'live') {            
            $typeCriteria = "((BaseTbl.matchStarted=1 or BaseTbl.status='LIVE') and BaseTbl.admin_status='APPROVED' )";
            $this->db->where($typeCriteria);
        }
        if ($type == 'result') {
            $typeCriteria = "((BaseTbl.matchStarted=1 or BaseTbl.status='FINISH') and BaseTbl.admin_status='APPROVED' )";
            $this->db->where($typeCriteria);
        }
         if ($type == 'cancel') {
            $typeCriteria = "((BaseTbl.matchStarted=1 or BaseTbl.status='ABANDONED') and  BaseTbl.admin_status='ABANDONED')";
            $this->db->where($typeCriteria);
        }


        $this->db->limit($page, $segment);
        if ($type == 'result') {
            $this->db->order_by("BaseTbl.end_dt", "desc");
        } else {
            $this->db->order_by("BaseTbl.start_dt", "desc");
        }

        $query = $this->db->get();

        // echo $this->db->last_query(); 
        // die();
        
        $result = $query->result();        
        return $result;
    }
    
    function getMatchByLeague($id){
          $this->db->select('team1,team2');
        $this->db->from('matches');
        $this->db->where('match_id',$id);
        $query = $this->db->get();
        return $query->result();
         
     }
     function getMatch($id){
          $this->db->select();
        $this->db->from('matches');
        $this->db->where('match_id',$id);
        $query = $this->db->get();
        return $query->result();
         
     }
    /**
     * This function is used to add new matches to system
     * @param array $data : This is match data to be inserted
     * @return number $insert_id : This is last inserted id
     */
    function storeNewmatches($data)
    {
        $this->db->trans_start();
        $this->db->insert('matches', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get all matches as list
     * @return array $result : This is match list
     */
    function getMatchList($type = '')
    {
        $this->db->select('BaseTbl.match_id, BaseTbl.team1, BaseTbl.team2');
        $this->db->from('matches as BaseTbl');
        if ($type != '') {
            $this->db->where('BaseTbl.status', $type);
        }
        $query = $this->db->get();
        $data[''] = 'Select Match';
        foreach ($query->result_array() as $row) {
            $data[$row['match_id']] = $row['team1'] . ' vs ' . $row['team2']. '-'.$row['match_id'];
        }
        return $data;
    }

    /**
     * This function used to get all matches
     * @return array $result : This is match result
     */
    function getAllMatch()
    {
        
        $this->db->select();
        $this->db->from('matches as BaseTbl');
        
        $query = $this->db->get();

        $result = $query->result();        
        return $result;
    }

    /**
     * This function used to get match information by match_id
     * @param number $id : This is match id
     * @return array $result : This is match information
     */
    function getMatchInfo($id)
    {
        $this->db->select();
        $this->db->from('matches');
        $this->db->where('match_id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }

  /**
     * This function used to get match information by series
     * @param number $id : This is match id
     * @return array $result : This is match information
     */
    function getMatchInfoBySeries($id)
    {
        $this->db->select('matches.*,series.name');
        $this->db->from('matches');
        $this->db->join('series','matches.series = series.id' ,'inner');
        $this->db->where('series', $id);
        $query = $this->db->get();
        
        return $query->result();
    }

     /**
     * This function used to get match information by series
     * @param number $id : This is match id
     * @return array $result : This is match information
     */
    function getMatchInfoBySeriesId($value)
    {
        $this->db->select();
        $this->db->from('matches');
        $this->db->where('series',$value);
        $query = $this->db->get();
        return $query->result();
        
    }

    /**
     * This function used to get match information by series
     * @param number $id : This is match id
     * @return array $result : This is match information
     */
    function getMatchIDBySeriesId($value)
    {
        $this->db->select('match_id,team1,team2');
        $this->db->from('matches');
        $this->db->where('series',$value);
        $query = $this->db->get();
        return $query->result();
        
    }


    /**
     * This function is used to update the match information
     * @param array $data : This is match data to be updated
     * @param number $match_id : This is match id
     */
    function editMatch($data, $id)
    {
        $this->db->where('match_id', $id);
        $this->db->update('matches', $data);
        
        return TRUE;
    }

     function editflagMatch($data,$id){
        //$this->db->set('team1_logo',$team1_logo);
        $this->db->where('id', $id);
        $this->db->update('matches',$data);
        
        return TRUE;
     }

    /**
     * This function is used to delete the match information
     * @param number $match_id : This is match id
     */
    function deleteMatch($id)
    {
        /*$this->db->where('match_id', $id);
        $this->db->delete('matches');
        
        return TRUE;*/
         $this->db->query("DELETE matches, points_calculation, squad FROM matches INNER JOIN points_calculation ON matches.match_id = points_calculation.match_id INNER JOIN squad ON matches.match_id = squad.match_id WHERE matches.match_id = $id");
        
        return TRUE;
    }
    /**
     * This function is used to get the  information of contest joined
     * @param number $match_id : This is match id
     */
    /*function getcontestjoined($id,$match_id)
    {
        $this->db->select('contest_joined.*',count('contest_joined.id'), $id);
        $this->db->from('contest_joined');
        $this->db->join( 'contests','contest_joined.league_id = contests.id' );
        $this->db->where('contests.match_id',$match_id);
        
        return TRUE;
    }*/

}

  