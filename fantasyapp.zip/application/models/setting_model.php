<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Setting_model extends CI_Model
{
    

    function bonusdetaillist()
    {
        $this->db->select();
        $this->db->from('app_settings as BaseTbl');
        $this->db->order_by("BaseTbl.id", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }


    /** add new flag**/
    /*function addNewBonus($data)
    {
        
       

        $this->db->trans_start();
        $this->db->insert('app_settings', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }*/

     function getBonusInfo()
    {
         $this->db->select();
        $this->db->from('app_settings as BaseTbl');
        $this->db->order_by("BaseTbl.id", "desc");
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    function editData($data,$id)
    {

        $this->db->where('id', $id);
        $this->db->update('app_settings', $data);
        
        return TRUE;
    
    }

    

}

  