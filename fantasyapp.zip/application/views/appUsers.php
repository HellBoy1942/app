<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="form-group" style="font-size:18px;font-weight:bold;"> User Listing
      </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                   <!-- <h3 class="box-title">Users List</h3>-->
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="appUserTbl" class="table table-hover">
                    <thead>
                      <tr>
                        <th>Sr. No.</th>
                        <th>User Id</th>
                        <th>Customer Name</th>
                        <th>Referral Code</th>
                        <th>Created</th>
                        <th>Team Name</th>
                        <th>Winning Amount</th>
                        <th>Wallet Amount</th>
                        <th>Referral Count</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                      </tr>
                    </thead>
                      <tbody>
                        <?php
                        $i=1;
                        if(!empty($userRecords))
                        {
                            foreach($userRecords as $record)
                            {
                             //  print_r($record);
                              $array=(array)$record;
                             //print_r($array);
                            $array_1=array_values($array);
                            //print_r($array_1);
                              $a=$array_1[16]; 
                              $b= $array_1[17];
                              $c= $array_1[18]; 
                              $d= $array_1[19];
                              //$ab=array() ;
                              $ab=$a+$b+$c+$d;
                              
                            //$arr= array_sum($ab);
                            //print_r($arr);  
                        ?>
                        <tr>
                          <td><?php echo $i ?></td>
                          <td><?php echo $record->id ?></td>
                          <td><?php echo $record->name ?></td>
                          <td><?php echo $record->r_id?></td>
                          <td><?php echo date("d-m-Y H:i:s", strtotime($record->created)) ?></td>
                          <td><?php echo $record->team_name ?></td>
                    
                          
                          <td><?php echo $record->cash_winning  ?></td>
                          <td><?php echo $ab  ?></td>
                          <td><?php echo $referral_count[$record->id];?></td>
                          <td><?php echo $record->status ?></td>
                          <td class="text-center">
                              <a class="btn btn-sm btn-info" href="<?php echo base_url() . 'viewAppUser/' . $record->id; ?>">View</a>
                          </td>
                        </tr>
                        <?php
                         $i=$i+1;
                            }
                        }
                        ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('#appUserTbl').DataTable();
    });
</script>
