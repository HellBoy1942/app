
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;">Add New User
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <!-- form start -->
                    

                    <form role="form" id="addUser" action="<?php echo base_url()?>addNewUser" method="post" enctype="multipart/form-data" autocomplete="off" >
                        <div class="box-body">
                            <div class="col-md-6">
                                <div class="row">
                                    
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Name</label>
                                            <input type="text" class="form-control required" id="name"  name="fname">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Email</label>
                                            <input type="email" class="form-control required" id="email" name="email" placeholder="please enter email id" >
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Password</label>
                                            <input type="password" class="form-control required" id="password" name="password"  placeholder="please enter password id">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Mobile</label>
                                            <input type="text" class="form-control required" id="mobile" name="mobile" maxlength="10" >
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Role</label>
                                            <select class="form-control" id="role" name="role" class="mdb-select">
                                                <option  value="" disabled selected><-- Select Role --></option>
                                                <option value="1">System Administrator</option>
                                                <option value="2">Manager</option>
                                                <option value="3">Employee</option>
                                                <option value="4">Accountant</option>
                                                <option value="5">Backend</option>
                                            </select>
                                        </div>
                                        
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">View</label>
                                            <select  multiple  id="people" name="view[]" class="form-control" >
                                                <?php                                               
                                                     foreach($menulist as $record):
                                                        
                                                        echo '<option value="' . $record->menu_id . '">' . $record->menu_item. '</option>';
                                                    endforeach;
                                                ?>
                                            </select>
                                            

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div> 
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<!-- add series valida -->

    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/src/example-styles.css">
    <link rel="stylesheet" type="text/css" href="demo-styles.css">
<script src="<?php echo base_url(); ?>assets/js/addUser.js" type="text/javascript"></script>

   <script type="text/javascript" src="<?php echo base_url()?>/test/lib/jquery-2.2.4.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>/src/jquery.multi-select.js"></script>
    <script type="text/javascript">
    $(function(){
        $('#people').multiSelect();
        $('#line-wrap-example').multiSelect({
            
            positionMenuWithin: $('.position-menu-within')
        });
        
    });
    </script>