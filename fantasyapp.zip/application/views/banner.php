 <?php
    date_default_timezone_set('Asia/Kolkata');
 
   $action = base_url() . 'statusChange';
   
?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
    <section class="content">
      <div class="row">
            <div class="col-xs-12 ">
                <div class="form-group" style="font-size:18px;font-weight:bold;float:left;">Banner Management</div>
                <div class="form-group" style="float:right;" >
                    <a class="btn btn-primary" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i> Add New Banner</a>
                </div>
            </div>
        </div>
       <div class="row">
            <div class="col-xs-12">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="banner_tbl" class="table table-hover">
                    <thead>
                      <tr>
                        <th> ID</th>
                        <th>Banner Type</th>
                        <th>URL</th>
                        <th>Image</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      if(!empty($bannerlist_info))
                      {
                          foreach($bannerlist_info as $record)
                          {
                            
                      ?>
                      <tr>
                        <td><?php echo $record->id ?></td>
                        <td><?php echo ucfirst($record->banner_type) ?></td>
                        <td><?php echo ucfirst($record->name) ?></td>
                        <td ><img src="<?php echo base_url() ?>banners/<?php echo $record->name?>" width="100" height="60" class="img-responsive"></td>
                        <td>
                         
                            <form action="<?php echo $action?>" method="POST">
                              <div class="input-group">
                                <select name="status" class="status_change">
                                <?php                              
                                  
                                  echo '<option value="ACTIVE" ' . (($record->status == 'ACTIVE') ? ' selected="selected"' : '') . '>ACTIVE</option>';

                                  echo '<option value="INACTIVE" ' . (($record->status == 'INACTIVE') ? ' selected="selected"' : '') . '>INACTIVE</option>';
                                 
                                ?>
                                </select>
                                 <input name="id" value="<?php echo $record->id ?>" type="hidden" />
                                
                                <input style="display: none;" id="change_submit" name="op" value="submit" type="submit"/>
                              </div>
                            </form>
                            </td>
                      
                       
                        <td class="text-center"> 
                           <input type="hidden" name="b_id" id="b_id" value="<?php echo $record->id; ?>">
                          <button type="button"  id="edit-banner" class="btn btn-sm btn-warning " onclick="funnew('<?=$record->id;?>')" ><i class="fa fa-pencil" ></i></button>
                          <a class="btn btn-sm btn-danger" href="<?php echo base_url().'deleteOldBanner/'.$record->id; ?>"><i class="fa fa-remove"></i></a>
                          
                        </td>
                      </tr>
                      <?php
                          }
                      }
                      ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>

<script type="text/javascript">
    jQuery(document).ready(function(){
      jQuery('#banner_tbl').DataTable({"order": [[1, 'desc']]});
    });

  jQuery(document).ready(function(){
    jQuery(".status_change").change(function() {
      jQuery(this).parent().parent().parent().find('form').submit();
    });
  });
  function funnew(x)
{   
    
    var ab=x;
      document.getElementById("bn_id").value=ab;
    $("#myModal1").modal("show");
}

</script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/addBanner.js" charset="utf-8"></script>

<!--popup for add banner--> 
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    <script>
    $(function () {
    $("#banner_name").change( function () {
        //Get reference of FileUpload.
        var fileUpload = $("#banner_name")[0];
 
        //Check whether the file is valid Image.
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png)$");
        if (regex.test(fileUpload.value.toLowerCase())) {
            //Check whether HTML5 is supported.
            if (typeof (fileUpload.files) != "undefined") {
                //Initiate the FileReader object.
                var reader = new FileReader();
                //Read the contents of Image File.
                reader.readAsDataURL(fileUpload.files[0]);
                reader.onload = function (e) {
                    //Initiate the JavaScript Image object.
                    var image = new Image();
                    //Set the Base64 string return from FileReader as source.
                    image.src = e.target.result;
                    image.onload = function () {
                        //Determine the Height and Width.
                        var height = this.height;
                        var width = this.width;
                        if (height > 720 || width > 1280) {
                            alert("Width and Height  must not exceed 1280*720px.");
                            $("#banner_name").val("");
                            return false;
                        }
                       
                    };
                }
            } else {
                alert("This browser does not support HTML5.");
                return false;
            }
        } else {
            alert("Please select a valid Image file.");
            return false;
        }
    });
});
</script>
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center;font-size: 14px;font-weight: bold;">Add Banner</h4>
        </div>
        <div class="modal-body">
           <form role="form" id="newbanner" action="<?php echo base_url()?>addNewBanner" method="post" enctype="multipart/form-data" autocomplete="off" >
                        <div class="box-body">
                           
                            
                                    
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="type">Banner Type</label>
                                            <select class="form-control required" id="banner_type"  name="banner_type">
                                              <option><--select banner type--></option>
                                              <option value="HOME">HOME</option>
                                               <option value="REFERRAL">REFERRAL</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Image</label>
                                            <input type="file" class="form-control required" id="banner_name" name="banner_name" value="" size="20">
                                        </div>
                                        <span style="color:red;">Note* Banner should be 1280*720 without Canvas</span>
                                    </div>
                                </div>
                                
                             
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Cancelled" data-dismiss='modal' />
                        </div>
                    </form>
        </div>
        
      </div>
    </div>
</div>
 <script>
   $(function () {
    $("#banner_name").change( function () {
        //Get reference of FileUpload.
        var fileUpload = $("#banner_name")[0];
 
        //Check whether the file is valid Image.
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png)$");
        if (regex.test(fileUpload.value.toLowerCase())) {
            //Check whether HTML5 is supported.
            if (typeof (fileUpload.files) != "undefined") {
                //Initiate the FileReader object.
                var reader = new FileReader();
                //Read the contents of Image File.
                reader.readAsDataURL(fileUpload.files[0]);
                reader.onload = function (e) {
                    //Initiate the JavaScript Image object.
                    var image = new Image();
                    //Set the Base64 string return from FileReader as source.
                    image.src = e.target.result;
                    image.onload = function () {
                        //Determine the Height and Width.
                        var height = this.height;
                        var width = this.width;
                        if (height > 720 || width > 1280) {
                            alert("Width and Height  must not exceed 1280*720px.");
                             $("#banner_name").val("");
                            return false;
                        }
                       
                    };
                }
            } else {
                alert("This browser does not support HTML5.");
                return false;
            }
        } else {
            alert("Please select a valid Image file.");
            return false;
        }
    });
});
</script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/editBanner.js" charset="utf-8"></script>
<!--popup for edit banner--> 
<div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
   
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center;font-size: 14px;font-weight: bold;">Edit Banner</h4>
        </div>
        <div class="modal-body">
          <?php $form_action='banner/editBanner';?>
           <form role="form" id="editBanner" action="<?=base_url().$form_action?>"" method="post" enctype="multipart/form-data" autocomplete="off" >
                        <div class="box-body">
                            
                                  <input type="hidden" name="bn_id" value="" id="bn_id">   
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="type">Banner Type</label>
                                            <select class="form-control required" id="banner_type"  name="banner_type">
                                              <option><--select banner type--></option>
                                               <option value="HOME">HOME</option>
                                               <option value="REFERRAL">REFERRAL</option> 
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Image</label>
                                            <input type="file" class="form-control required" id="banner_name" name="banner_name" >
                                           
                                           
                                        </div>
                                       <span style="color:red;">Note* Banner should be 1280*720 without Canvas</span> 
                                    </div>
                                </div>
                                
                           
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary"  id="submit-edit" value="Save" />
                            <input type="reset" class="btn btn-default" value="Cancelled" data-dismiss='modal' />
                        </div>
                    </form>
        </div>
        
      </div>
    </div>
</div>