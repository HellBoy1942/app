
<style>
    .input-group-btn:last-child>.btn, .input-group-btn:last-child>.btn-group {
    margin-left: -27px;
}
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="row">
                    <div class="col-md-6"></div>
                    <div class="col-md-6" style="margin-left: 50px;margin-top: 20px;">
                        <?php if( $userInfo[0]->status =='ACTIVE')
                        {
                             echo'<form action="'.base_url().'userStatus" method="POST" id="cancelForm">
                                    <div class="input-group">
                                    <input type="hidden" name="user_id" value="'. $userInfo[0]->id.'"/>
                                    <input type="hidden" name="user_status" value="'.$userInfo[0]->status.'"/>
                                    <div class="input-group-btn">
                                      
                                      <button class="btn btn-lg btn-primary">Suspended</button>
                                      
                                    </div>
                                  </div>
                              </form>';
                        } else if( $userInfo[0]->status =='INACTIVE')
                        {
                             echo'<form action="'.base_url().'userStatus" method="POST" id="cancelForm">
                                    <div class="input-group">
                                    <input type="hidden" name="user_id" value="'. $userInfo[0]->id.'"/>
                                     <input type="hidden" name="user_status" value="'.$userInfo[0]->status.'"/>
                                    <div class="input-group-btn">
                                      
                                      <button class="btn btn-lg btn-primary">UnSuspended</button>
                                      
                                    </div>
                                  </div>
                              </form>';
                        }?>
                    </div>
                   
                  </div>
    <section class="content">
      <div class="panel-group">
          <div class="panel panel-default">
            <div class="panel-heading">General Information</div>
            <div class="panel-body">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>Name</label>
                    </div>
                    <div class="col-md-4">
                      <?php
                        print $userInfo[0]->name;
                      ?>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4">
                      <label>Team Name</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        print $userInfo[0]->team_name;
                      ?>
                    </div>          
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <label>Phone</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        print $userInfo[0]->phone;
                      ?>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <label>Email</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        print $userInfo[0]->email;
                      ?>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4">
                      <label>City</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        if($userInfo[0]->city) {
                          echo $city[$userInfo[0]->city][0]->city;
                        } else {
                          echo "N/A";
                        }
                      ?>
                    </div>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>Joined Date</label>
                    </div>
                    <div class="col-md-4">
                      <?php
                        print date("d/m/Y", strtotime($userInfo[0]->created));
                      ?>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4">
                      <label>Gender</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        print $userInfo[0]->gender;
                      ?>
                    </div>          
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <label>DOB</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        print $userInfo[0]->dob;
                      ?>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <label>Address</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        print $userInfo[0]->address;
                      ?>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4">
                      <label>State</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        if($userInfo[0]->state) {
                          echo $state[$userInfo[0]->state][0]->state;
                        } else {
                          echo "N/A";
                        }
                      ?>
                    </div>
                  </div>
                </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">Account Information</div>
            <div class="panel-body">
                
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>Add Cash</label>
                    </div>
                    <div class="col-md-4">
                      <?php
                        print $userInfo[0]->add_cash;
                      ?>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4">
                      <label>Referral Bonus</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        print $userInfo[0]->referral_bonus;
                      ?>
                    </div>          
                  </div>
                  
                  </div>
                
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>Cash Bonus</label>
                    </div>
                    <div class="col-md-4">
                      <?php
                        print $userInfo[0]->cash_bonus;
                      ?>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4">
                      <label>Cash Winning</label>
                    </div>
                    <div class="col-md-4">
                      <?php 
                        print $userInfo[0]->cash_winning;
                      ?>
                    </div>          
                  </div>
                  
                  
                </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading"> My Referrals</div>
            <div class="panel-body">
                <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  
                    <h4 class="box-title" style="font-weight: 400;">Total Referral Amount - <?php
                    foreach ($transcation_list_info1 as $res) {
                     print_r($res[0]['txn_amt']);
                    }
                     
                  ?></h4>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="appUserTbl" class="table table-hover">
                    <thead>
                      <tr>
                       <th> Sr No</th>
                        <th>Date</th>
                        <th>Referee User Id</th>
                        <th>Referee Name</th>
                         <th>Code</th>
                        <th> Referral Amount</th>
                        <th>Txn Status</th>
                       
                      </tr>
                    </thead>
                      <tbody>
                        <?php
                          $i=1; 
                          { 
                            
                        if(!empty($referral_info))
                        {
                            foreach($referral_info as $record)
                            {
                              
                             foreach($transcation_list_info as $record1)
                            { 
                                 
                        ?>
                        <tr>
                          
                         
                            <td><?php echo $i;?></td>
                             <td><?php 
                             if($record1 != "N/A"){
                              echo date("d-m-Y H:i:s", strtotime($record1[0]['txn_dt']));
                              }
                              elseif($record1 == "N/A")
                              {
                                echo "N/A";
                              }
                              ?></td> 
                           
                            <td><?php echo $record['id']; ?></td>
                            <td><?php echo $record['name']; ?></td>
                             <td><?php echo $record['r_id']; ?></td>
                             <td><?php echo $record1[0]['txn_amt'];  ?></td>
                          
                            <td><?php echo $record1[0]['txn_status'];  ?></td> 
                            
                        </tr>
                      
                        <?php
                          $i++;
                            }
                          }
                          
                         } 
                        }
                        ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                </div>
              </div><!-- /.box -->
            </div>
               
                
               
            </div>
          </div>
          <div class="panel panel-default" id="transaction">
            <div class="panel-heading">Transaction History</div>
            <div class="panel-body">
                <div class="col-xs-12">
              <div class="box">
                 <div class="box-header">
                  
                  <div class="col-xs-4">
                    <p style="font-weight: bold;">Transaction Type -</p>
                    </div><div class="col-xs-6">
                    <?php $action=  base_url() . 'showTransaction';?> 
                      <form method="POST" action="<?php echo $action?>">
                      <select id="txn_type" name="txn_type" class="form-control status_change">
                                                              <option ><-- select transaction type ---></option>  
                                                              <option value="CASH_BONUS">CASH BONUS</option>
                                                              <option value="JOIN_CONTEST">Join Contest</option>
                                                              <option value="WITHDRAW_REQUEST">WITHDRAW REQUEST</option>
                                                              <option value="PG_ADD_CASH">PG ADD CASH</option>
                                                              <option value="REFERRAL_BONUS">REFERRAL BONUS</option>
                                                              <option value="WINNING_AMOUNT">WINNING AMOUNT</option>
                                                              <option value="PAYTM_WALLET">PAYTM WALLET</option>
                                                              <option value="REFUND_AMT">REFUND AMT</option>
                                                              </select>
                                                             
                                  <input name="u_id"  id="u_id" value="<?php echo $userInfo[0]->id ?>" type="hidden" />
                                
                                <input style="display: none;" id="change_submit" name="op" value="submit" type="submit"/>
                      </form>
                    </div>
                    <div class="col-xs-4"></div>
                    
                </div> <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="appUserTbl1" class="table table-hover">
                    <thead>
                         <th> Sr No</th>
                        <th>Transaction Date</th>
                        <th>Transaction Id</th>
                        <th> Transaction Amount</th>
                        <th>Transaction Msg</th>
                        <th>Txn Status</th>
                        </thead> 
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                </div>
              </div><!-- /.box -->
            </div>
               
                
               
            </div>
          </div>
        </div>
    </section>
</div>
<script type="text/javascript">
   
    jQuery(document).ready(function(){
        jQuery('#appUserTbl').DataTable();
    });
    jQuery(document).ready(function(){
        jQuery('#appUserTbl1').DataTable();
    });
    /*jQuery(document).ready(function(){
    jQuery(".status_change").change(function() {
      jQuery(this).parent().parent().parent().find('form').submit();
    });
  });*/

    $(function(){
$('#txn_type').change(function(){
  var txn_type=$('#txn_type').val();
  var user_id=$('#u_id').val();
   $('#loading').html('<img src="../uploads/load.gif"> loading...');
    $.ajax({
        url: "<?php echo $action?>",
        data:{txn_type:txn_type,user_id:user_id},
        type: "post",
        success: function(data){
           $('#appUserTbl1').html(data);

        }
    });
});
});
</script>
