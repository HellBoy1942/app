 <?php
    date_default_timezone_set('Asia/Kolkata');
 ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;">Bank Verification Details
      </div>
    </section>
    <section class="content">
       <div class="row">
            <div class="col-xs-12">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="bank_tbl" class="table table-hover">
                    <thead>
                      <tr>
                        <th>User ID</th>
                        <th>Date</th>
                        <th>Name</th>
                        <th>DOB</th>
                        <th>Pan Status</th>
                        <th>Bank Status</th>
                        <th class="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      if(!empty($bankDetailList))
                      {
                          foreach($bankDetailList as $record)
                          {
                      ?>
                      <tr>
                        <td><?php echo $record->user_id ?></td>
                        <td data-order="<?php print strtotime($record->created);?>"><?php echo date("d-m-Y H:i:s", strtotime($record->created)) ?></td>
                        <td><?php echo ucfirst($record->pan_name) ?></td>
                        <td><?php echo date("d-m-Y H:i:s", strtotime($record->pan_dob)) ?></td>
                        <td><?php echo $record->pan_is_verify ?></td>
                        <td><?php echo $record->is_bank_verify ?></td>
                        <td class="text-center"> 
                          <a class="btn btn-sm btn-info" href="<?php echo base_url().'bankVerifyEdit/'.$record->id; ?>"><i class="fa fa-eye"></i></a>
                        </td>
                      </tr>
                      <?php
                          }
                      }
                      ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
      jQuery('#bank_tbl').DataTable({"order": [[1, 'desc']]});
    });
</script>
