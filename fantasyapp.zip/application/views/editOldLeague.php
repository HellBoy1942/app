<?php
$id = '';
$name = '';
$type = '';
$wamt = '';
$size = '';
$com = '';
$entry = '';
$aid='';
$auto_repeat='';


if(!empty($league_info))
{
    foreach ($league_info as $li)
    {
        $id = $li->id;
        $name = $li->name;
        $match = $li->match_id;
        $type = $li->type;
        $wamt = $li->winning_amount;
        $size = $li->contest_size;
        $com = $li->commission;
        $entry = $li->entry_fees;
        $multi_joined=$li->multi_joined;
        $cancel_contest=$li->cancel_contest;
    }

}

if(!empty($repeat_info))
{
    foreach($repeat_info as $kk)
    {
        $aid=$kk->aid;
        $auto_repeat=$kk->auto_repeat;
        $bonus_per=$kk->bonus_per;
    }
}

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;">Edit League 
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-6">
              <!-- general form elements -->
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" id="editLeague" action="<?php echo base_url() ?>editLeague" method="post" role="form">
                        <div class="box-body">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="name">Leage Type</label>                                        
                                            <?php
                                              $c_selected = "";
                                              $p_selected = "";
                                              if ($type == 'CASH') {
                                                $c_selected = 'selected';
                                              } elseif ($type == 'PRACTICE') {                                      
                                                $p_selected = 'selected';
                                              } else {
                                                $c_selected = "";
                                                $p_selected = "";
                                              }
                                            ?>
                                            <select class="form-control required" id="league_type" name="league_type">
                                                <option value="">--Select League Type--</option>
                                                <option <?php echo $c_selected;?> value="CASH">CASH</option>
                                                <option <?php echo $p_selected;?> value="PRACTICE">PRACTICE</option>
                                            </select>
                                            <input type="hidden" value="<?php echo $id; ?>" name="id" id="id" />
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="start_dt">Match</label>
                                            <select name="match" class="form-control required" id="match">
                                                <?php                                       
                                                    foreach($match_list as $match_id => $des):
                                                      if ($match_id == $match) {
                                                        $selected = 'selected';
                                                      } else {
                                                        $selected = '';
                                                      }
                                                      echo '<option ' . $selected . ' value="' . $match_id . '">' . $match_id . '</option>';
                                                    endforeach;
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">League Name</label>
                                            <input type="text" class="form-control required" id="name"  name="name" value="<?php echo $name;?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Winning Amount</label>
                                            <input type="text" class="form-control required" id="win_amount" name="win_amount" value="<?php echo $wamt;?>">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">League Size</label>
                                            <input type="text" class="form-control required" id="size" name="size" value="<?php echo $size;?>">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Margin (%)</label>
                                            <input type="text" class="form-control required" id="margin" name="margin" value="<?php echo $com;?>">                                        
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Entry Fees</label>
                                            <input type="text" class="form-control required" id="entry_fees" readonly="readonly"name="entry_fees" value="<?php echo $entry;?>">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group bg-info">
                                            <label for="status" id="fee">Bonus %</label>
                                            <input type="text" class="form-control required" id="bonus1" name="bonus1" value="<?=$bonus_per?>" maxlength="128" >
                                            <span id="error212" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                           <input type="checkbox" name="multi_joined" id="ismultijoined" value="1" <?php echo $multi_joined?'checked':'';?>><label id="multi">Is Joined Multi Team ??</label> 
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                          <input type="checkbox" name="cancel_contest" id="iscontestcancelled" value="1" <?=$cancel_contest?'checked':''?> > <label id="contest"> Is Contest Cancelled ??</label>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <input type="hidden" name="aid" value="<?=$aid?>">
                                          <input type="checkbox" name="auto_repeat" id="autorepeat1" value="1" <?=$auto_repeat?'checked':''?>> <label id="contest">  Auto Repeat</label>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <?php
                            if (!empty($winners_info)) {
                                $set_of_winners = $winners_info[0]->set_of_winners;
                            ?>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Set No of Winners</label>
                                            <input type="text" class="form-control" id="set_of_winners" name="set_of_winners" value="<?php echo $set_of_winners;?>" maxlength="128">
                                            <p id="win_error"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12" id="winner_section">
                                        <?php
                                                $rank_html = "";
                                                $rank_html .= '<div class="box-body table-responsive">';
                                                $rank_html .= '<table class="table table-hover table-bordered table-striped">';
                                                $rank_html .= '<tr><th class="text-center" colspan="5">Winners</th></tr>';
                                                $rank_html .= '<tr><th>Rank</th><th>Winner Ammount (%)</th><th>Amount</th></tr>';
                                                $rank_html .= '<div class="box box-primary">';   
                                                $rank_html .= '<div class="box box-primary">';
                                                for ($i = 0; $i < $set_of_winners; $i++) { 
                                                    $rank_html .= '<tr class="winner_rank_item"><td class="winner_rank">' . $winners_info[$i]->rank . '</td><td class="winner_rank_per"><input type="text" class="form-control" name="percen_' . $winners_info[$i]->rank . '" value="' . $winners_info[$i]->winning_percent . '"></td><td class="winner_rank_amt"><input type="text" class="form-control" name="rank_amt_' . $winners_info[$i]->rank . '" value="' . $winners_info[$i]->winning_amount . '"></td></tr>';
                                                }
                                                $rank_html .= '</table>';
                                                $rank_html .= '</div>';
                                                print $rank_html;
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                              }
                            ?>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" name="edit_league" value="Submit" />
                            <input type="submit" class="btn btn-primary" name="delete_league" value="Delete" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
        </div> 
    </section>
    
</div>
<!-- add series valida -->
<script src="<?php echo base_url(); ?>assets/js/editLeague.js" type="text/javascript"></script>