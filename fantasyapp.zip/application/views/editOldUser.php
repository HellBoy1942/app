<?php

$id = '';
$name = '';
$email = '';
$password = '';
$mobile = '';
$roleId = '';
$views = '';




if(!empty($userInfo_edit))
{
    foreach ($userInfo_edit as $si)
    {
        //print_r($userId);
        $id = $si->userId;
        $name = $si->name;
        $email = $si->email;
        $password = $si->password;
        $mobile = $si->mobile;
        $view=$si->view;
        $roleId=$si->roleId;
        //$team1_short_name = $si->team1_short_name;
       // $team2_short_name = $si->team2_short_name;

    }
}


?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;"> Edit User 
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <!-- form start -->
                    

                    <form role="form" id="editUser" action="<?php echo base_url()?>editUser" method="post"  autocomplete="off" >
                        <div class="box-body">
                            <div class="col-md-6">
                                <div class="row">
                                    
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Name</label>
                                            <input type="text" class="form-control required" id="name"  name="fname" value="<?php echo $name;?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Email</label>
                                            <input type="email" class="form-control required" id="email" name="email" placeholder="please enter email id" value="<?php echo $email;?>" >
                                            <input type="hidden" name="user_id" value="<?php echo $id;?>">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Password</label>
                                            <input type="password" class="form-control required" id="password" name="password"  placeholder="please enter password id" value="<?php echo $password;?>">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Mobile</label>
                                            <input type="text" class="form-control required" id="mobile" name="mobile" maxlength="10" value="<?php echo $mobile;?>" >
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Role</label>
                                            <?php
                                              $s_selected = "";
                                              $m_selected = "";
                                              $e_selected = "";
                                              $a_selected = "";
                                              $b_selected = "";
                                              if ($roleId == '1') {

                                                $s_selected = 'selected';
                                              } elseif ($roleId == '2') {                                      
                                                $m_selected = 'selected';
                                              }elseif ($roleId == '3') {                                      
                                                $e_selected = 'selected';
                                              }
                                              elseif ($roleId == '4') {                                      
                                                $a_selected = 'selected';
                                              }elseif ($roleId == '5') {                                      
                                                $b_selected = 'selected';
                                              } else {
                                                 $s_selected = "";
                                                  $m_selected = "";
                                                  $e_selected = "";
                                                  $a_selected = "";
                                                  $b_selected = "";
                                              }
                                            ?>
                                            <select class="form-control" id="role" name="role" class="mdb-select">
                                                <option  value="" disabled selected><-- Select Role --></option>
                                                
                                                <option <?php echo $s_selected;?> value="1">System Administrator</option>
                                                <option  <?php echo $m_selected;?> value="2">Manager</option>
                                                <option <?php echo $e_selected;?> value="3">Employee</option>
                                                <option <?php echo $a_selected;?> value="4">Accountant</option>
                                                <option <?php echo $b_selected;?> value="5">Backend</option>
                                            </select>
                                        </div>
                                        
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">View</label>
                                            <select  multiple  id="people" name="view[]" class="form-control sel" >
                                              
                                            <?php
                                            
                                            $view1 = explode(",", $view);
                                            // print_r($view1);
                                            foreach ($menulist as $key => $value) {
                                                //if(in_array($value->menu_id, $view1)){
                                                 $selected = in_array($value->menu_id, $view1 ) ? ' selected="selected" ' : '';
                                                //}
                                               echo"<option value='$value->menu_id' '.$selected.'> $value->menu_item
                                               </option>"; 

                                              } ?>                 
                                                  
                                            </select>
                                            

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div> 
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Save" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<!-- add series valida -->

    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/src/example-styles.css">
    <link rel="stylesheet" type="text/css" href="demo-styles.css">

   <script type="text/javascript" src="<?php echo base_url()?>/test/lib/jquery-2.2.4.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>/src/jquery.multi-select.js"></script>
    <script type="text/javascript">
    $(function(){
        $('#people').multiSelect();
        $('#line-wrap-example').multiSelect({
            
            positionMenuWithin: $('.position-menu-within')
        });
        
    });
    </script>