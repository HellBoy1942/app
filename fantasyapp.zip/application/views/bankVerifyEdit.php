<?php
 $this->config->load('config');
$bank_verify = $this->config->item('bank_verify');

$id = '';
$user_id = '';
$pan_name = '';
$pan_dob = '';
$pan_state = '';
$pan_no = '';
$pan_photo = '';
$bank_name = '';
$account_no = '';
$ifsc = '';
$account_type = '';
$bank_photo = '';
$pan_is_verify ='';
$is_bank_verify ='';


if(!empty($bankDetail))
{
    foreach ($bankDetail as $b)
    {
        $id = $b->id;
        $user_id = $b->user_id;
        $pan_name = $b->pan_name;
        $pan_dob = $b->pan_dob;
        $pan_state = $b->pan_state;
        $pan_no = $b->pan_no;
        $pan_photo = $b->pan_photo;
        $bank_name = $b->bank_name;
        $account_no = $b->account_no;
        $ifsc = $b->ifcs;
        $account_type = $b->account_type;
        $bank_photo = $b->bank_proof;
         $is_bank_verify =  $b->is_bank_verify;
        $pan_is_verify =$b->pan_is_verify;
    }
}


?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="form-group" style="font-size:18px;font-weight:bold;"> Bank Detail Verification
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>bankEdit" method="post" enctype="multipart/form-data" id="editMatch" role="form">
                        <div class="box-body">
                            <div id="pan_photo_area">
                                <?php 
                                    if (!empty($pan_photo)) {
                                ?>
                                    <a href="<?php echo $bank_verify?>/user_verification_document/<?php echo $pan_photo?>" target="_blank"><img width="300" height="200" src="<?php echo $bank_verify?>/user_verification_document/<?php echo $pan_photo?>"></a>
                                <?php
                                    }
                                ?>
                            </div>
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="pan_no">Pan No</label>
                                        <input type="text" class="form-control" value="<?php echo $pan_no;?>" name="pan_no" id="pan_no">
                                        <input type="hidden" value="<?php echo $id; ?>" name="id" id="id" />
                                        <input type="hidden" value="<?php echo $user_id; ?>" name="user_id" id="user_id" />
                                    </div>                                    
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="pan_name">Pan Name</label>
                                        <input type="text" class="form-control" value="<?php echo $pan_name;?>" name="pan_name" id="pan_name">
                                        <input type="hidden" value="<?php echo $id; ?>" name="id" id="id" />
                                    </div>                                    
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="pan_dob">Pan Dob</label>
                                        <input type="text" name="pan_dob" id="pan_dob" class="form-control" value="<?php echo $pan_dob;?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="pan_state">Pan State</label>
                                        <input type="text" name="pan_state" id="pan_state" class="form-control" value="<?php echo $pan_state;?>">
                                    </div>
                                </div>
                                
                                <input type="hidden" name="pan_verify_bonus"  id="pan_verify_bonus" value="<?php echo $panVerify[0]->pan_verify_bonus; ?>">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                         <?php  if($pan_is_verify == 'SUCCESS'){?>
                                        <input type="button" name="reject_lbl_pan" id='reject_lbl_pan' disabled class="btn btn-primary" value="Reject" />
                                        <input type="button" name="accept_lbl_pan" id='accept_lbl_pan' disabled class="btn btn-primary" value="Accept" />
                                        <textarea class="form-control" name="pan_reject_msg" id="pan_reject_msg"></textarea>
                                        <?php } else{ ?>
                                          <input type="button" name="reject_lbl_pan" id='reject_lbl_pan'  class="btn btn-primary" value="Reject" />
                                        <input type="button" name="accept_lbl_pan" id='accept_lbl_pan' class="btn btn-primary" value="Accept" />
                                        <textarea class="form-control" name="pan_reject_msg" id="pan_reject_msg"></textarea>
                                        <?php }?>
                                    </div>                                        
                                </div>
                            </div>
                        </div>
        
                        <div class="box-footer">
                          <?php  if($pan_is_verify == 'SUCCESS'){?>
                                <input type="submit" name="pan_op" id="pan_op_acpt" class="btn btn-primary" disabled value="Accept" />
                                <input type="submit" name="pan_op" id="pan_op_rjct" class="btn btn-primary" disabled value="Reject" />
                              <?php  }  else{?>
                                 <input type="submit" name="pan_op" id="pan_op_acpt" class="btn btn-primary" value="Accept" />
                                <input type="submit" name="pan_op" id="pan_op_rjct" class="btn btn-primary" value="Reject" />
                              <?php  }?>
                                
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>bankEdit" method="post" enctype="multipart/form-data" id="editMatch" role="form">
                        <div class="box-body">
                            <div id="bank_photo_area">
                                <?php 
                                    if (!empty($bank_photo)) {
                                ?>
                                     <a href="<?php echo $bank_verify?>/user_verification_document/<?php echo $bank_photo?>" target="_blank"><img width="300" height="200" src="<?php echo $bank_verify?>/user_verification_document/<?php echo $bank_photo?>"></a>
                                <?php
                                    }
                                ?>
                            </div>
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="bank_name">Bank Name</label>
                                        <input type="text" class="form-control" value="<?php echo $bank_name;?>" name="bank_name">
                                        <input type="hidden" value="<?php echo $id; ?>" name="id" id="id" />
                                        <input type="hidden" value="<?php echo $user_id; ?>" name="user_id" id="user_id" />
                                    </div>                                        
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="account_no">Account No</label>
                                        <input type="text" name="account_no" id="account_no" value="<?php echo $account_no;?>" class="form-control"/>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="ifsc">IFSC</label>
                                        <input type="text" name="ifsc" value="<?php echo $ifsc;?>" id="ifsc" class="form-control"/>
                                    </div>
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="account_type">Account Type</label>
                                        <input type="text" class="form-control" value="<?php echo $account_type;?>" name="account_type">
                                    </div>                                        
                                </div>
                                <input type="hidden" name="bank_verify_bonus" id="bank_verify_bonus" value="<?php echo $bankVerify[0]->bank_verify_bonus; ?>">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <?php if($is_bank_verify =='SUCCESS'){ ?>
                                        <input type="button" name="reject_lbl_bk" id='reject_lbl_bk' disabled class="btn btn-primary" value="Reject" />
                                        <input type="button" name="accept_lbl_bk" id='accept_lbl_bk' disabled class="btn btn-primary" value="Accept" />
                                        <textarea class="form-control" name="bank_reject_msg" id="bank_reject_msg"></textarea>
                                        <?php } else{?>
                                             <input type="button" name="reject_lbl_bk" id='reject_lbl_bk'  class="btn btn-primary" value="Reject" />
                                        <input type="button" name="accept_lbl_bk" id='accept_lbl_bk'  class="btn btn-primary" value="Accept" />
                                        <textarea class="form-control" name="bank_reject_msg" id="bank_reject_msg"></textarea>
                                      <?php } ?>
                                        
                                    </div>                                        
                                </div>
                            </div>
                        </div>
            
                         <div class="box-footer">
                             <?php if($is_bank_verify =='SUCCESS'){?>
                                <input type="submit" name="bank_op" id="bank_op_acpt"class="btn btn-primary" disabled value="Accept" />
                                <input type="submit" name="bank_op" id="bank_op_rjct" class="btn btn-primary" disabled value="Reject" />
                              <?php } else {?>
                                 <input type="submit" name="bank_op" id="bank_op_acpt"class="btn btn-primary"  value="Accept" />
                                <input type="submit" name="bank_op" id="bank_op_rjct" class="btn btn-primary"  value="Reject" /> 
                            <?php }?>
                        </div>
                    </form>
                </div>
            </div>

        </div>   
    </section>
</div>
<script type="text/javascript">
    jQuery(document).ready(function(){
        
        jQuery("#pan_reject_msg").hide();
        jQuery("#pan_op_rjct").hide();
        jQuery("#accept_lbl_pan").hide();

        jQuery("#bank_reject_msg").hide();
        jQuery("#bank_op_rjct").hide();
        jQuery("#accept_lbl_bk").hide();

        jQuery('#reject_lbl_bk').click(function(){
            jQuery("#bank_reject_msg").show();
            jQuery("#bank_op_acpt").hide();
            jQuery("#bank_op_rjct").show();
            jQuery("#accept_lbl_bk").show();
            jQuery("#reject_lbl_bk").hide();
        });

        jQuery('#reject_lbl_pan').click(function(){
            jQuery("#pan_reject_msg").show();
            jQuery("#pan_op_acpt").hide();
            jQuery("#pan_op_rjct").show();
            jQuery("#reject_lbl_pan").hide();
            jQuery("#accept_lbl_pan").show();
        });

        jQuery('#accept_lbl_bk').click(function(){
            jQuery("#bank_reject_msg").hide();
            jQuery("#bank_op_acpt").hide();
            jQuery("#bank_op_rjct").show();
            jQuery("#accept_lbl_bk").hide();
            jQuery("#reject_lbl_bk").show();
        });

        jQuery('#accept_lbl_pan').click(function(){
            jQuery("#pan_reject_msg").hide();
            jQuery("#pan_op_acpt").hide();
            jQuery("#pan_op_rjct").show();
            jQuery("#accept_lbl_pan").hide();
            jQuery("#reject_lbl_pan").show();
        });
    });

</script>