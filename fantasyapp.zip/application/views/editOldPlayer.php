<?php

$id = '';
$p_id = '';
$name = '';
$credit = '';
$points = '';
$country = '';


if(!empty($player_info))
{
    foreach ($player_info as $si)
    {
        $id = $si->id;
        $p_id = $si->p_id;
        $name = $si->name;
        $credit = $si->credit;
        $points = $si->points;
        $country = $si->country;
        $playing_role = $si->playing_role;
    }
}


?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="form-group" style="font-size:18px;font-weight:bold;">Edit Player 
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>editPlayer" method="post" id="editPlayer" role="form">
                        <div class="box-body">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" disabled value="<?php echo $name;?>" maxlength="128">
                                            <input type="hidden" value="<?php echo $p_id; ?>" name="p_id" id="p_id" />
                                        </div>                                    
                                    </div>
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="name">Playing Role</label>
                                            <select name="playing_role" class="form-control required" id="playing_role">
                                                <option value="">Select Playing Role</option>
                                                <option <?php echo (($playing_role == 'BOWL') ? 'selected' : '');?>value="BOWL">BOWL</option>
                                                <option <?php echo (($playing_role == 'WK') ? 'selected' : '');?> value="WK">WK</option>
                                                <option <?php echo (($playing_role == 'BAT') ? 'selected' : '');?> value="BAT">BAT</option>
                                                <option <?php echo (($playing_role == 'AR') ? 'selected' : '');?> value="AR">AR</option>
                                            </select>
                                        </div>                                    
                                    </div>                                
                                    <div class="col-md-12">                                
                                        <div class="form-group">                  
                                          <select name="country" class="form-control input-lg" id="country">
                                              <?php                                                
                                                  foreach($country_list as $cname):
                                                      if ($cname == $country) {
                                                          $selected = 'selected';
                                                      } else {
                                                          $selected = '';
                                                      }
                                                      echo '<option ' . $selected . ' value="' . $cname . '">' . $cname . '</option>';
                                                  endforeach;
                                              ?>
                                          </select>                      
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="start_dt">Credit</label>
                                            <input type="text" class="form-control" name="credit" id="credit" value="<?php echo $credit;?>">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="start_dt">Points</label>
                                            <input type="text" class="form-control" name="points" id="points" value="<?php echo $points;?>">
                                        </div>
                                    </div>
                                </div>
                            </div><!-- /.col-md-6 -->
        
                            <div class="box-footer">
                                <input type="submit" class="btn btn-primary" value="Submit" />
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div> 
    </section>
</div>