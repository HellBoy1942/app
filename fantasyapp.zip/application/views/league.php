 <?php
  
  $match_type = array();
  foreach($all_match_list as $record) {
    //echo $record->match_type;
    $match_type [$record->match_id] = $record->status; 
  }
 ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-server"></i> League Management
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>newLeague"><i class="fa fa-plus"></i> Add New League</a>
                </div>
            </div>
        </div>
   
        <div class="row">
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">All Leagues</h3>
                </div><!-- /.box-header -->
                
               
              
                <div class="box-body" style="overflow: auto;">
                  
            
                  <table id="league_tbl" class="table table-hover">
                    <thead>
                      <tr>
                        <th class="hidden-xs">League ID</th>
                       <!-- <th>League Name</th>-->
                        <th>League Type</th>
                        <th>League Date</th>
                        <th>Winning Price</th>                  
                        <th>Commission (%)</th>
                        <th>League Size</th>
                        <th>Entry Fees</th>
                        <th>MultiJoined</th>
                        <th>Cancel Contest</th>
                        <th>Match ID</th>
                        <th>League Status</th>
                        <th class="text-center">Actions</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      
                      if(!empty($leagueRecords))
                      {
                          foreach($leagueRecords as $record)
                          {
                            
                          
                      ?>
                      <tr>
                        <td><?php echo $record->id ?></td>
                        <!--<td><?php echo $record->name ?></td>-->
                        <td><?php  echo $record->league_name; ?></td>
                        <td><?php echo date('d-m-Y H:i:s', strtotime($record->created)) ?></td>
                        <td><?php echo $record->winning_amount ?></td>
                        <td><?php echo $record->commission ?></td>
                        <td><?php echo $record->contest_size ?></td>
                        <td><?php echo $record->entry_fees;?></td>
                        <td><?php if($record->multi_joined =='0'){ echo "FALSE"; }else{echo "TRUE";}?></td>
                       <td><?php if($record->cancel_contest =='0'){ echo "FALSE"; }else{echo "TRUE";}?></td>
                        <td><?php echo $record->match_id; ?></td>
                        <td><?php echo $record->status;?>
                        </td>
                        <td class="text-center">
                          <a class="view_teams btn btn-primary btn-xs" target="_blank" href="<?php echo base_url() . 'joinedTeams/' . $record->id; ?>"> Teams (<?php echo (!empty($join_team_count) ? $join_team_count[$record->id] : "0");?>)</a> 
                          <?php if($record->league_name =='Practice Contest'){ ?>
                          <a class="view_winners btn btn-success btn-xs"  disabled="disabled" target="_blank"  href="<?php echo base_url() . 'winners/' . $record->id; ?>">Winners</a> 
                          <?php }else{?>
                              <a class="view_winners btn btn-success btn-xs" target="_blank" href="<?php echo base_url() . 'winners/' . $record->id; ?>">Winners</a>  
                         <?php }?>
                         <?php if($record->league_name =='Practice Contest'){ ?>
                         <a class="league btn btn-info btn-xs" style="margin-top:5px;" disabled="disabled" href="<?php echo base_url().'editOldLeague/'.$record->id; ?>"><i class="fa fa-pencil" style="padding-left: 6px;
                            padding-right: 8px;"></i> Edit</a>
                         <?php }else{?>
                           <a class="league btn btn-info btn-xs"  style="margin-top:5px;" href="<?php echo base_url().'editOldLeague/'.$record->id; ?>"><i class="fa fa-pencil" style="padding-left: 6px;
                            padding-right: 8px;"></i> Edit</a>
                            <?php }?>
                          <?php if($record->status =='ACTIVE' && $record->cancel_contest =='1'){
                            
                         echo' <button type="button"  class="btn btn-danger btn-xs"  style="margin-top:5px;" onclick="deleteValue('.$record->id.')" ><i class="fa fa-remove" ></i>Cancel</button>';
                       }
                       else {
                         echo' <button  type="button" class="btn btn-danger btn-xs"  style="margin-top:5px;display:none;" ><i class="fa fa-remove" ></i>Cancel</button>';
                          }
                       ?>
                        </td>
                        <td>
                          <a class="league btn btn-danger btn-xs" style="margin-top:5px;" href="<?php echo base_url().'deleteOldLeague2/'.$record->id; ?>"><i class="fa fa-trash-o"></i> Delete</a>
                        </td>
                      </tr>
                      <?php
                          }
                        
                      }
                      ?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php //echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
      jQuery('#league_tbl').DataTable();
    });
     $(function(){
  $('#series_name').change(function(){
  var series_name = $('#series_name').val();
  
    $.ajax({
        url: "league/setSelect",
        data:{series_name:series_name},
        type: "post",
        success: function(response){
           document.getElementById('match_id').innerHTML=response;

        }
    });
});
});
     $(function(){
  $('#match_id').change(function(){
  var match_id=$('#match_id').val();
  $('#league_tbl').html('<img src="assets/images/load.gif"> loading...');
  
    $.ajax({
        url: "<?php echo $action2?>",
        data:{match_id:match_id},
        type: "post",
        success: function(data){
           document.getElementById('league_tbl').innerHTML=data;

        }
    });
});
});
     function deleteValue(x){
      
      var ab=x;
      
      document.getElementById("l_id").value=ab;
      $('#myModal2').modal('show');
     }
</script>
<div class="modal fade"  id="myModal2" role="dialog">
                                            <div class="modal-dialog">
                                            
                                              <!-- Modal content-->
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                  <h4 class="modal-title"><b>why you want to cancelled this League ??</b></h4>
                                                </div>
                                                <div class="modal-body">
                                                   
                                                    <form method="post" action="editStatus" >
                                                <input type="hidden" name="l_id" id="l_id" value="">
                                                    
                                                    <textarea rows="4" cols="50" name="cancel_desc" id="cancel_desc"></textarea>
                                                    <br>
                                                    <input type="submit"  id="update" class="btn btn-info"  value="Update"  >
                                                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                              </div>
                                              
                                            </div>
                                          </div>
