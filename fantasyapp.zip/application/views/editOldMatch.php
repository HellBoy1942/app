<?php

$id = '';
$match_id = '';
$name = '';
$start_dt = '';
$team1 = '';
$team2 = '';
$series = '';
$flag1 = '';
$flag2 = '';
$team1_short='';
$team2_short='';
$match_type = '';
$admin_status = '';
$team1_short_name = '';
$team2_short_name='';


if(!empty($match_info))
{
    foreach ($match_info as $si)
    {
        //print_r($match_info);
        $id = $si->id;
        $match_id = $si->match_id;
        $team1 = $si->team1;
        $team2 = $si->team2;
        $start_dt = date("m-d-Y H:i:s", strtotime($si->start_dt));
        
        $end_dt = date('m-d-Y H:i:s',strtotime($si->end_dt));
        $admin_status = $si->admin_status;
        $series = $si->series;
        $match_type = $si->match_type;
        $team1_logo = $si->team1_logo;
        $team2_logo = $si->team2_logo;
        $team1_short_name = $si->team1_short_name;
       $team2_short_name = $si->team2_short_name;

    }
}


?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="form-group" style="font-size:18px;font-weight:bold;">Edit Match
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>editMatch" method="post" enctype="multipart/form-data" id="editMatch" role="form">
                        <div class="box-body">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="name">Team 1</label>
                                            <input type="text" class="form-control" disabled value="<?php echo $team1;?>" maxlength="128">
                                            <input type="hidden" value="<?php echo $match_id; ?>" name="match_id" id="match_id" />
                                        </div>                                    
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="start_dt">Team 1 Logo</label><br>
                                            
                                            <input type="hidden" name="team1" id="team1" value="<?php echo $team1; ?>">

                                            <!--  <img src="<?php echo base_url() ?>uploads/<?php echo $team1_logo?>" width="50" height="30" name="team1_img1" > -->
                                              <?php if(empty($team1_logo)){?>
                                                 <img src="<?php echo base_url() ?>uploads/no-image-icon.png" width="50" height="30" name="logo1" id="logo1" >
                                              <?php   }else{?>
                                                <img src="<?php echo base_url() ?>uploads/<?php echo $team1_logo?>" width="50" height="30" name="team1_img1">
                                                <?php }?>
                                               <input type="hidden" name="team1_img_1" id="image_1"  >
                                             &nbsp;<button type="button"  id="team_flag1" class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal">SELECT FLAG</button>
                                            <div class="modal fade"  id="myModal" role="dialog">
                                            <div class="modal-dialog">
                                            
                                              <!-- Modal content-->
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                  <h4 class="modal-title">SELECT FLAG</h4>
                                                </div>
                                                <div class="modal-body">
                                                  
                                                        <input type="hidden" name="f_id" id="f_id" value="<?php echo $id;?>">
                                                    <select  class="form-control required"   id="team1_img"  name="team1_img">
                                                        <option><-- select flag --></option>
                                                        <?php   
                                                                                                   
                                                        foreach($flag_list1 as $record):
                                                           
                                                            if ($record == $flag1) {
                                                                $selected = 'selected';
                                                            } else {
                                                                $selected = '';
                                                            }
                                                           
                                                            echo '<option ' . $selected . ' value="'.$record->image_name.'"> '. $record->team_name .'</option>';
                                                          
                                                        endforeach;
                                                        ?>
                                                    </select>
                                                 
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                              </div>
                                              
                                            </div>
                                          </div>
                                             

                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            
                                                    
                                            <label for="start_dt">Team 1 short name </label>
                                            <input type="text" name="team1_short" id="team1_short" class="form-control" value="<?php echo $team1_short_name?>" />
                                            
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="start_dt">Start Date</label>
                                           
                                            <div class='input-group date' id='datetimepicker1' >
                                            <input type='text' class="form-control"  name="start_dt" value="<?php echo $start_dt;?>" />
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">End Date</label>
                                           
                                            <div class='input-group date' id='datetimepicker2' >
                                            <input type='text' class="form-control"  name="end_dt" value="<?php echo $end_dt;?>" />
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Match Type</label>
                                            <select name="match_type" class="form-control input-lg" id="match_type">
                                                <?php

                                                    echo '<option value="">Select Match Type</option>';
                                                    echo '<option value="T20" ' . (($match_type == 'T20') ? ' selected="selected"' : '') . '>T20</option>';
                                                   
                                                    echo '<option value="ODI" ' . (($match_type == 'ODI') ? ' selected="selected"' : '') . '>ODI</option>';
                                                    echo '<option value="Test" ' . (($match_type == 'Test') ? ' selected="selected"' : '') . '>Test</option>';
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- /.col-md-6 -->

                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="name">Team 2</label>
                                            <input type="text" class="form-control" disabled value="<?php echo $team2;?>" maxlength="128">
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="start_dt">Team 2 Logo</label><br>
                                            
                                            <input type="hidden" name="team2" id="team2" value="<?php echo $team2; ?>">
                                            
                                            
                                                <?php if(empty($team2_logo)){?>
                                                 <img src="<?php echo base_url() ?>uploads/no-image-icon.png" width="50" height="30" name="logo2" id="logo2" >
                                              <?php   }else{?>
                                                <img src="<?php echo base_url() ?>uploads/<?php echo $team2_logo?>" width="50" height="30" name="team2_img1">
                                                <?php }?>
                                                <input type="hidden" name="team2_img_1" id="image_2"  >
                                                &nbsp;<button type="button" class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal1" id="team_flag2">SELECT FLAG</button>
                                            <div class="modal fade" id="myModal1" role="dialog">
                                            <div class="modal-dialog">
                                            
                                              <!-- Modal content-->
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                  <h4 class="modal-title">SELECT FLAG</h4>
                                                </div>
                                                <div class="modal-body">
                                                
                                                    <input type="hidden" name="f_id" id="f2_id" value="<?php echo $id;?>">

                                                   <select  name="team2_img" id="team2_img" class="form-control required" >
                                                    <option><-- select flag --></option>
                                                    <?php   
                                                    //print_r($flag_list2 as $records2);                                            
                                                    foreach($flag_list2 as $records2):
                                                        if ($records2 == $flag2) {
                                                            $selected = 'selected';
                                                        } else {
                                                            $selected = '';
                                                        }

                                                        echo '<option ' . $selected . ' value="' . $records2->image_name . '">' . $records2->team_name . '</option>';
                                                    endforeach;
                                                    ?>
                                                    </select>
                                                   
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                              </div>
                                              
                                            </div>
                                          </div>
                                         
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="start_dt">Team 2 short name </label>
                                            <input type="text" name="team2_short" id="team2_short" class="form-control" value="<?php echo $team2_short_name?>" />
                                            
                                        </div>
                                    </div>
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Series</label>  
                                           <!--  <?php    print_r($series_list);?> -->                                  
                                            <select name="series" class="form-control required" id="series">
                                                <?php                                                
                                                    foreach($series_list as $sid => $sname):
                                                        if ($sid == $series) {
                                                            $selected = 'selected';
                                                        } else {
                                                            $selected = '';
                                                        }
                                                        echo '<option ' . $selected . ' value="' . $sid . '">' . $sname . '</option>';
                                                    endforeach;
                                                ?>
                                            </select>
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Status</label>                                    
                                            <select name="admin_status" class="form-control required" id="admin_status">
                                                <option value="">Select Status</option>
                                                <option <?php echo (($admin_status == 'APPROVED') ? 'selected ' : '');?> value="APPROVED">APPROVED</option>
                                                <option <?php echo (($admin_status == 'UNAPPROVED') ? 'selected ' : '');?> value="UNAPPROVED">UNAPPROVED</option>
                                                
                                            </select>                                            
                                        </div>
                                        
                                    </div>
                                </div>
                            </div><!-- /.col-md-6 -->
        
                            <div class="box-footer">

                                <input type="submit" class="btn btn-primary"  value="Submit" />
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>   
        <div class="row">
            <div class="box box-primary">
                <div class="col-md-6">
                <div class="box-body table-responsive">
                  <table class="table table-hover table-bordered table-striped">
                    <tr>
                      <th class="text-center" colspan="5">
                        <?php 
                            if (!empty($team1_logo)) {
                        ?>
                            <img src="<?php echo base_url() ?>uploads/<?php echo $team1_logo?>" width="50" height="30">
                        <?php
                            }
                        ?>
                        <?php echo $team1; ?></th>  
                    </tr>
                    <tr>
                      <th>PLAYER ID</th>
                      <th>NAME</th>    
                      <th>POINTS</th> 
                       <th>PLAYING ROLE</th>
                       <th>CREDIT</th>
                      <th class="text-center">Actions</th>
                    </tr>
                    <?php
                    if(!empty($players1))
                    {
                        foreach($players1 as $record)
                        {
                            
                    ?>
                    <tr>
                      <td><?php echo $record->player_id ?></td>
                      <td><?php echo $record->name ?></td>  
                      <td> <?php echo $record->points;?></td>  
                        <form  method="get" autocomplete="off">              
                              <td>
                                <?php
                                                      $b_selected = "";
                                                      $w_selected = "";
                                                      $t_selected = "";
                                                      $a_selected = "";
                                                      if ($record->role == 'BOWL') {

                                                        $b_selected = 'selected';
                                                      } elseif ($record->role == 'WK') {                                      
                                                        $w_selected = 'selected';
                                                      }elseif ($record->role == 'BAT') {                                      
                                                        $t_selected = 'selected';
                                                      }elseif ($record->role == 'AR') {                                      
                                                        $a_selected = 'selected';
                                                      } else {
                                                        $b_selected = "";
                                                        $w_selected = "";
                                                        $t_selected = "";
                                                        $a_selected = "";
                                                      }
                                                    ?>
                                <select name="playing_role" class="form-control required" id="playing_role<?=$record->player_id?>">

                                                         <option value="">Select Playing Role</option>
                                                        <option <?php echo $b_selected;?> value="BOWL">BOWL</option>
                                                        <option <?php echo $w_selected;?> value="WK">WK</option>
                                                        <option <?php echo $t_selected;?> value="BAT">BAT</option>
                                                        <option <?php echo $a_selected;?> value="AR">AR</option>  
                                 </select>
                                 
                              </td>
                                   
                          <td>
                            <input type="text" value="<?php echo $record->credit ?>" name="credit"  style="width:50%;text-align: center;" id="credit<?=$record->player_id?>">
                            
                          </td>
                          <td class='text-center'>                    
                             <input type="button" class='btn btn-sm btn-info' type='submit' id='editInfo1' value="Save" onclick="updatePlayer(<?php echo $record->player_id;?>)">
                          </td>
                     </form>
                     <form  method="get">  
                        <td class='text-center'>                    
                             <input type="button" class='btn btn-sm btn-info' type='submit' id='delete' value="Delete" onclick="deletePlayer(<?php echo $record->player_id;?>)">
                        </td>
                    </form> 
                      
                      
                    </tr>
                    <?php
                        }
                    }
                    ?>
                  </table>
                   <div class="form-group" style="float:right;">
                    <a class="btn btn-primary" data-toggle="modal" data-target="#myModal3"><i class="fa fa-plus"></i> Add Another Players</a>
                    </div>
                </div><!-- /.box-body -->

            </div>

            <div class="col-md-6">
                <div class="box-body table-responsive">
                  <table class="table table-hover table-bordered table-striped">
                    <tr>
                      <th class="text-center" colspan="5">
                        <?php 
                            if (!empty($team2_logo)) {
                        ?>
                            <img src="<?php echo base_url() ?>uploads/<?php echo $team2_logo?>" width="50" height="30">
                        <?php
                            }
                        ?>
                        <?php echo $team2; ?></th>  
                    </tr>
                    <tr>
                       <th>PLAYER ID</th>
                      <th>NAME</th>    
                      <th>POINTS</th> 
                       <th>PLAYING ROLE</th>
                       <th>CREDIT</th>
                      <th class="text-center">Actions</th>
                    </tr>
                    <?php
                    if(!empty($players2))
                    {
                        foreach($players2 as $record)
                        {
                    ?>
                    <tr>
                      <td><?php echo $record->player_id ?></td>
                      <td><?php echo $record->name ?></td>  
                       <td><?php echo $record->points;?></td>
                       <form  method="get" autocomplete="off">              
                              <td>
                                <?php
                                                      $b_selected = "";
                                                      $w_selected = "";
                                                      $t_selected = "";
                                                      $a_selected = "";
                                                      if ($record->role == 'BOWL') {

                                                        $b_selected = 'selected';
                                                      } elseif ($record->role == 'WK') {                                      
                                                        $w_selected = 'selected';
                                                      }elseif ($record->role == 'BAT') {                                      
                                                        $t_selected = 'selected';
                                                      }elseif ($record->role == 'AR') {                                      
                                                        $a_selected = 'selected';
                                                      } else {
                                                        $b_selected = "";
                                                        $w_selected = "";
                                                        $t_selected = "";
                                                        $a_selected = "";
                                                      }
                                                    ?>
                                <select name="playing_role" class="form-control required" id="playing_role<?=$record->player_id?>">

                                                         <option value="">Select Playing Role</option>
                                                        <option <?php echo $b_selected;?> value="BOWL">BOWL</option>
                                                        <option <?php echo $w_selected;?> value="WK">WK</option>
                                                        <option <?php echo $t_selected;?> value="BAT">BAT</option>
                                                        <option <?php echo $a_selected;?> value="AR">AR</option>  
                                 </select>
                                 
                              </td>
                                   
                          <td>
                            <input type="text" value="<?php echo $record->credit ?>" name="credit"  style="width:50%;text-align: center;" id="credit<?=$record->player_id?>">
                            
                          </td>
                          <td class='text-center'>                    
                             <input type="button" class='btn btn-sm btn-info' type='submit' id='editInfo1' value="Save" onclick="updatePlayer(<?php echo $record->player_id;?>)">
                          </td>
                     </form>
                     <form  method="get">  
                        <td class='text-center'>                    
                             <input type="button" class='btn btn-sm btn-info' type='submit' id='delete' value="Delete" onclick="deletePlayer(<?php echo $record->player_id;?>)">
                        </td>
                    </form> 
                    
                    </tr>
                    <?php
                        }
                    }
                    ?>
                  </table>
                  <div class="form-group" style="float:right;">
                    <a class="btn btn-primary" data-toggle="modal" data-target="#myModal2"><i class="fa fa-plus"></i> Add Another Players</a>
                    </div>
                </div><!-- /.box-body -->

            </div>
            </div>
        </div> 
    </section>
</div>

<script src="<?php echo base_url(); ?>assets/js/editMatch.js" type="text/javascript"></script>
<!--add timepicker--->
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css">
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.12.0/moment.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
       function updatePlayer($id){

          var credit= $('#credit'+$id).val();

          var playing_role= $('#playing_role'+$id).val();

             $('#loading').html('<img src="../uploads/load.gif"> loading...');

           console.log(credit);

           console.log(playing_role);

          $.ajax({

              url: "match/editPlayer",

              data:{credit:credit,playing_role:playing_role,id:$id},

              type: "get",

              success: function(data){

                alert('Credit & Player Role Update Successfully.');

              }

          });
      }

       function deletePlayer($id){

          

          $.ajax({

              url: "match/deletePlayer",

              data:{id:$id},

              type: "get",

              success: function(data){

                alert('Player data delete Successfully ');
                location.reload();

              }

          });
      }


        

 $(function(){
  $('#country1').change(function(){
  var country = $('#country1').val();
 
  
    $.ajax({
        url: "match/setPlayer",
        data:{country:country},
        type: "post",
        success: function(response){
           document.getElementById('player_id').innerHTML=response;

        }
    });
});
});

  $(function(){
  $('#country2').change(function(){
  var country = $('#country2').val();
 
  
    $.ajax({
        url: "match/setPlayer1",
        data:{country:country},
        type: "post",
        success: function(response){
           document.getElementById('player_id1').innerHTML=response;

        }
    });
});
});
$('document').ready(function(){
        $('#player_id').on('change', function(){
           
        var player_name=$("#player_id").val();
       
        var match_id=$("#match_id").val();
        
        $.ajax({
            type:'post',
                url:'match/checkPlayer',// put your real file name 
                data:{player_name: player_name,match_id:match_id},
                success:function(response){
                if (response == 'taken' ) {
                  alert("palyer Id already exist");
                  $("#player_id").val("");
                  }     
                }
         });
        });
        
        
        
        $('document').ready(function(){
        $('#player_id1').on('change', function(){
           
        var player_name=$("#player_id1").val();
       
        var match_id=$("#match_id").val();
        
        $.ajax({
            type:'post',
                url:'match/checkPlayer',// put your real file name 
                data:{player_name: player_name,match_id:match_id},
                success:function(response){
                if (response == 'taken' ) {
                  alert("palyer Id already exist");
                  $("#player_id1").val("");
                  }     
                }
         });
        });
                $(function(){
        
                $('#admin_status').change(function(){
                   
                    if ($(this).val() == "ABANDONED") {
                    $('#myModa2').modal('show');
                  
                }
                });
            });
}); 
                $(function(){
        
                $('#admin_status').change(function(){
                   
                    if ($(this).val() == "ABANDONED") {
                    $('#myModa2').modal('show');
                  
                }
                });
            });
}); 



 function updateValue($id){

          var cancel_desc= $('#cancel_desc'+$id).val();

       
             $('#loading').html('<img src="../uploads/load.gif"> loading...');

           console.log(cancel_desc);

           //console.log(id);

          $.ajax({

              url: "match/editMatch",

              data:{cancel_desc:cancel_desc,id:$id},

              type: "get",

              success: function(data){
            }

          });



       }
       $(document).ready(function(){
   $("#team1_img").change(function(){
        var base_url = window.location.origin;
     $("img[name=logo1]").attr("src",base_url+"/adminpanel/uploads/"+$(this).val());
     $("#image_1").val($(this).find("option:selected").attr("value"));
       // $("input[name=team1_short]").val($(this).find("option:selected").attr("value"));
  
   });
});
   $(document).ready(function(){
   $("#team2_img").change(function(){
       var base_url = window.location.origin;
     $("img[name=logo2]").attr("src",base_url+"/adminpanel/uploads/"+$(this).val());
     $("#image_2").val($(this).find("option:selected").attr("value"));
    // $("#team2_short").val(($this).find("option:selected").attr("value"));
   });


});
</script>
<div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center;font-size: 14px;font-weight: bold;">Add Another Player</h4>
        </div>
        <div class="modal-body">
            <form role="form" id="newPlayer1" action="<?php echo base_url()?>addNewPlayer1" method="post"  autocomplete="off" >
                        <div class="box-body">
                            <div class="col-md-12">
                                <input type="hidden" value="<?php echo $match_id; ?>" name="match_id" id="match_id" />
                                 <input type="hidden" value="<?php echo $team1; ?>" name="team1" id="team1" />                                 
                                    
                               
                                 <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Country</label>
                                           <select class="form-control" name="country" id="country1">
                                            
                                              <?php                                                

                                                  foreach($country_list as $cname):

                                                      echo '<option ' . $selected . ' value="' . $cname . '">' . $cname . '</option>';

                                                  endforeach;
                                                ?>
                                          </select>
                                        </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                         <div class="form-group">
                                            <label for="end_dt">Player</label>
                                           <select class="form-control" name="player_id" id="player_id" >
                                           
                                          </select>
                                        </div>
                                    </div>
                                </div>
                                
                           
                            
                            </div> 
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
        </div>
        
      </div>
    </div>
</div>
<div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center;font-size: 14px;font-weight: bold;">Add Another Player</h4>
        </div>
        <div class="modal-body">
            <form role="form" id="newPlayer1" action="<?php echo base_url()?>addNewPlayer1" method="post"  autocomplete="off" >
                        <div class="box-body">
                            <div class="col-md-12">
                                <input type="hidden" value="<?php echo $match_id; ?>" name="match_id" id="match_id" />
                                 <input type="hidden" value="<?php echo $team2; ?>" name="team1" id="team2" />                                 
                                    
                               
                                 <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Country</label>
                                           <select class="form-control" name="country" id="country2">
                                            
                                              <?php                                                

                                                  foreach($country_list as $cname):

                                                    

                                                      echo '<option ' . $selected . ' value="' . $cname . '">' . $cname . '</option>';

                                                  endforeach;
                                                ?>
                                          </select>
                                        </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                         <div class="form-group">
                                            <label for="end_dt">Player</label>
                                           <select class="form-control" name="player_id" id="player_id1">
                                           
                                          </select>
                                        </div>
                                    </div>
                                </div>
                                
                           
                            
                            </div> 
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
        </div>
        
      </div>
    </div>
</div>

