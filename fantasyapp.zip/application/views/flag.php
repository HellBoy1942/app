 <?php
    date_default_timezone_set('Asia/Kolkata');
 ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!--<section class="content-header">
      <h1>
        <i class="fa fa-server"></i> Team Flag
      </h1>
    </section>-->
    <section class="content">
      <div class="row">
            <div class="col-xs-12 ">
                <div class="form-group" style="font-size:18px;font-weight:bold;float:left;">Team Flag</div>
                <div class="form-group" style="float:right;">
                    <a class="btn btn-primary" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i> Add New Flag</a>
                </div>
            </div>
        </div>
       <div class="row">
            <div class="col-xs-12">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="flag_tbl" class="table table-hover">
                    <thead>
                      <tr>
                        <th> ID</th>
                        <th>Flag</th>
                        <th>Team Name</th>
                        <th>Short Name</th>
                        <th>Created</th>
                        
                        <th class="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      if(!empty($flaglist))
                      {
                          foreach($flaglist as $record)
                          {
                            
                      ?>
                      <tr>
                        <td><?php echo $record->id ?></td>
                        
                        <td ><img src="<?php echo base_url() ?>uploads/<?php echo $record->image_name?>" width="50" height="30" class="img-responsive"></td>
                        <td><?php echo ucfirst($record->team_name) ?></td>
                        <td><?php echo ucfirst($record->short_name) ?></td>
                        <td><?php echo date("d-m-Y", strtotime($record->create_dt)) ?></td>
                       
                        <td class="text-center"> 
                          <a class="btn btn-sm btn-info" href="<?php echo base_url().'editOldFlag/'.$record->id; ?>"><i class="fa fa-pencil"></i></a>
                           
                          <a class="btn btn-sm btn-info" href="<?php echo base_url().'deleteOldFlag/'.$record->id; ?>"><i class="fa fa-remove"></i></a>
                        </td>
                      </tr>
                      <?php
                          }
                      }
                      ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/editFlag.js" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/addFlag.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
      jQuery('#flag_tbl').DataTable({"order": [[1, 'desc']]});
    });
</script>
<!--popup for add banner--> 
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    <script>
    $(function () {
    $("#image_name").change( function () {
        //Get reference of FileUpload.
        var fileUpload = $("#image_name")[0];
 
        //Check whether the file is valid Image.
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png)$");
        if (regex.test(fileUpload.value.toLowerCase())) {
            //Check whether HTML5 is supported.
            if (typeof (fileUpload.files) != "undefined") {
                //Initiate the FileReader object.
                var reader = new FileReader();
                //Read the contents of Image File.
                reader.readAsDataURL(fileUpload.files[0]);
                reader.onload = function (e) {
                    //Initiate the JavaScript Image object.
                    var image = new Image();
                    //Set the Base64 string return from FileReader as source.
                    image.src = e.target.result;
                    image.onload = function () {
                        //Determine the Height and Width.
                        var height = this.height;
                        var width = this.width;
                        if (height > 150 || width > 150) {
                            alert("Width and Height  must not exceed 150*150px.");
                             $("#image_name").val("");
                            return false;
                        }
                       
                    };
                }
            } else {
                alert("This browser does not support HTML5.");
                return false;
            }
        } else {
            alert("Please select a valid Image file.");
            return false;
        }
    });
});
</script>
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center;font-size: 14px;font-weight: bold;">Add Flag</h4>
        </div>
        <div class="modal-body">
            <form role="form" id="newFlag" action="<?php echo base_url()?>addNewFlag" method="post" enctype="multipart/form-data" autocomplete="off" >
                        <div class="box-body">
                            <div class="col-md-6">
                                <div class="row">
                                    
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Team Name</label>
                                            <input type="text" class="form-control required" id="name"  name="team_name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">Icon Name</label>
                                            <input type="file" class="form-control required" id="image_name" name="image_name" value="" size="20">
                                        </div>
                                        <span style="color:red;">Note* Team Flag Icon should be 150*150 without Canvas</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Short Name</label>
                                            <input type="text" class="form-control required" id="short_name"  name="short_name">
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            
                            </div> 
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
        </div>
        
      </div>
    </div>
</div>

