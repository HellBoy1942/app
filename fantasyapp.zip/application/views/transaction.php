<?php 
                    if(!empty($player_records)) {
                  ?> 
                  <table id="appUserTbl1" class="table table-hover table-bordered table-striped">
                   <!-- <tr>
                      <th class="text-center" colspan="5"><?php echo ucfirst($country); ?></th>  
                    </tr>-->
                    <tr>
                      <th> Sr No</th>
                        <th>Transaction Date</th>
                        <th>Transaction Id</th>
                        <th> Transaction Amount</th>
                        <th>Transaction Msg</th>
                        <th>Txn Status</th>
                    </tr>
                      <?php
                      $i=1;
                        foreach($all_transaction as $row1){
                          //print_r($record);
                          ?>
                      <tr>
                       <td class='print-clean' style='width:70px;'><center>$i</center></td>"; ?>
                     <td style='width:120px;' class='print-clean'><center><?php echo date("d-m-Y H:i:s", strtotime($row1['txn_dt']));?></center></td>
                        <td width='100px;'><center><?php echo $row1['txn_id'];?></center></td>
                        
                        <td width='140px;' class='print-clean'><center><?php echo $row1['txn_amt'];?></center></td>
                        <td width='150px;' class='print-clean'><center><?php echo strtoupper($row1['txn_msg']);?></center></td>
                        <td width='150px;' class='print-clean'><center><?php echo strtoupper($row1['txn_status']);?></center></td>
                     
                    </tr>
                    <?php
                    $i++;
                      }
                  ?>
                  </table>
                   <?php
                    
                  }
                  ?> 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/editPlayer.js" charset="utf-8"></script>