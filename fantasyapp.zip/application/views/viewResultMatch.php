<?php

$id = '';
$match_id = '';
$name = '';
$start_dt = '';
$team1 = '';
$team2 = '';
$series = '';
$match_type = '';
$admin_status = '';
$status = '';
$cancel_desc ='';


if(!empty($match_info))
{
    foreach ($match_info as $si)
    {
        $id = !empty($si->id) ? $si->id : '';
        $match_id = !empty($si->match_id) ? $si->match_id : '';
        $team1 = !empty($si->team1) ? $si->team1 : '';
        $team2 = !empty($si->team2) ? $si->team2 : '';
        $start_dt = date("d-m-Y H:i:s", strtotime($si->start_dt));
        //$end_dt = date('d-m-Y H:i:s',strtotime('+1 day',strtotime($si->start_dt)));
        $end_dt = date('d-m-Y H:i:s',strtotime($si->end_dt));
        $cancel_desc = !empty($si->cancel_desc) ? $si->cancel_desc : '';
        $admin_status = !empty($si->admin_status) ? $si->admin_status : '';
        $status = !empty($si->status) ? $si->status : '';
        $series = !empty($si->series) ? $si->series : '';
        $match_type = !empty($si->match_type) ? $si->match_type : '';
        $team1_logo = !empty($si->team1_logo) ? $si->team1_logo : '';
        $team2_logo = !empty($si->team2_logo) ? $si->team2_logo : '';
    }
}


?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="form-group" style="font-size:18px;font-weight:bold;"> View Match Details
      </div>
      <?php if($status == 'ABANDONED' && $admin_status == 'ABANDONED'){
      echo'<div class="form-group" style="margin-top: -44px;margin-left: 1050px; font-weight: bold;display:none;"> <a class="btn btn-xs btn-primary" data-toggle="modal" data-target="#myModa2"><p style="font-size:20px;padding:5px 5px 5px 5px">Abandoned Match</p></a>
      </div>';
       } else{
        echo'<div class="form-group" style="margin-top: -44px;margin-left: 1050px; font-weight: bold;"> <a class="btn btn-xs btn-primary" data-toggle="modal" data-target="#myModa2"><p style="font-size:20px;padding:5px 5px 5px 5px">Abandoned Match</p></a>
      </div>';  
      }?>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="box box-primary">
                        <div class="box-body">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                        <label>Match Details</label>
                                    </div>
                                    <div class="col-md-12">   
                                        <div class="col-md-3">
                                          <label>Team 1 Name</label>
                                        </div>
                                        <div class="col-md-3">
                                          <?php 
                                            echo $team1;
                                          ?>
                                        </div>                                 
                                    </div>
                                    <div class="col-md-12">
                                        <div class="col-md-3">
                                          <label>Start Date</label>
                                        </div>
                                        <div class="col-md-4">
                                          <?php 
                                            echo $start_dt;
                                          ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="col-md-3">
                                          <label>Reason</label>
                                        </div>
                                        <div class="col-md-4">
                                          <?php 
                                            echo $cancel_desc;
                                          ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="col-md-3">
                                          <label>Series</label>
                                        </div>
                                        <div class="col-md-3">
                                          <?php 
                                            echo (isset($series_list[$series]) && !empty($series_list[$series])) ? $series_list[$series] : "";
                                          ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <label>Contest Details</label>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="col-md-3">
                                          <label>Total Contests</label>
                                        </div>
                                        <div class="col-md-3">
                                          <?php 
                                            echo $leage_list_count . " (<a href='" . base_url() . "leagueListing?match_id=" . $match_id . "'>View</a>)";
                                          ?>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- /.col-md-6 -->

                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-3">
                                          <label>Team 2 Name</label>
                                        </div>
                                        <div class="col-md-3">
                                          <?php 
                                            echo $team2;
                                          ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="col-md-3">
                                          <label>End Date</label>
                                        </div>
                                        <div class="col-md-4">
                                          <?php 
                                            echo $end_dt;
                                          ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="col-md-3">
                                          <label>Match Type</label>
                                        </div>
                                        <div class="col-md-3">
                                          <?php 
                                            echo $match_type;
                                          ?>
                                        </div>                              
                                    </div>
                                </div>
                            </div><!-- /.col-md-6 -->
                        </div>
                </div>
            </div>

        </div>   
        <div class="row">
            <div class="box box-primary">
                <div class="col-md-6">
                <div class="box-body table-responsive">
                  <table class="table table-hover table-bordered table-striped">
                    <tr>
                      <th class="text-center" colspan="5">
                        <?php 
                            if (!empty($team1_logo)) {
                        ?>
                            <img src="<?php echo base_url() ?>uploads/<?php echo $team1_logo?>" width="50" height="30">
                        <?php
                            }
                        ?>
                        <?php echo $team1; ?></th>  
                    </tr>
                    <tr>
                      <th>PLAYER ID</th>
                      <th>NAME</th>  
                      <th>PLAYING ROLE</th>                
                      <th>CREDIT</th>
                      <th>POINTS</th>                      
                     
                    </tr>
                    <?php
                    if(!empty($players1))
                    {
                        foreach($players1 as $record)
                        {
                    ?>
                    <tr>
                      <td><?php echo $record->player_id ?></td>
                      <td><?php echo $record->name ?></td>  
                      <td><?php echo $record->role ?></td>                
                      <td><?php echo $record->credit ?></td>
                      <td><?php echo $record->points ?></td>
                      
                    </tr>
                    <?php
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->

            </div>

            <div class="col-md-6">
                <div class="box-body table-responsive">
                  <table class="table table-hover table-bordered table-striped">
                    <tr>
                      <th class="text-center" colspan="5">
                        <?php 
                            if (!empty($team2_logo)) {
                        ?>
                            <img src="<?php echo base_url() ?>uploads/<?php echo $team2_logo?>" width="50" height="30">
                        <?php
                            }
                        ?>
                        <?php echo $team2; ?></th>  
                    </tr>
                    <tr>
                      <th>PLAYER ID</th>
                      <th>NAME</th>    
                      <th>PLAYING ROLE</th>              
                      <th>CREDIT</th>
                      <th>POINTS</th>                      
                      
                    </tr>
                    <?php
                    if(!empty($players2))
                    {
                        foreach($players2 as $record)
                        {
                    ?>
                    <tr>
                      <td><?php echo $record->player_id ?></td>
                      <td><?php echo $record->name ?></td>  
                      <td><?php echo $record->role ?></td>              
                      <td><?php echo $record->credit ?></td>
                      <td><?php echo $record->points ?></td>
                      
                    </tr>
                    <?php
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->

            </div>
            </div>
        </div> 
    </section>
</div>
<div class="modal fade"  id="myModa2" role="dialog">
                                            <div class="modal-dialog">
                                            
                                              <!-- Modal content-->
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                  <h4 class="modal-title"><b>why you want to cancelled this Match ??</b></h4>
                                                </div>
                                                <div class="modal-body">
                                                   
                                                    <form method="post" action="editMatch" >
                                                    <!-- //<input type="hidden" name="match_id" id="match_id" value="<?php echo $match_id;?>"> -->
                                                    
                                                    <textarea rows="4" cols="50" name="cancel_desc" id="cancel_desc"></textarea>
                                                    <br>
                                                    <input type="button"  id="update" class="btn btn-info"  value="Update" data-dismiss="modal" onclick="updateValue(<?php echo $match_id;?>)">
                                                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                              </div>
                                              
                                            </div>
                                          </div>

<script type="text/javascript">
 function updateValue($id){

          var cancel_desc= $('#cancel_desc').val();
           var match_id= $('#id').val();
          $('#loading').html('<img src="http://winner11.in/adminpanel/uploads/load.gif"> ');

          $.ajax({

              url: "match/cancelMatch",

              data:{cancel_desc:cancel_desc,id:$id},

              type: "Post",

              success: function(data){

                 alert('Match Cancel Successfully');
                 location.reload();

                 }

          });
       }

</script>
