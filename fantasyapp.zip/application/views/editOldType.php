<?php

$id = '';
$league_name = '';
$type='';
$image = '';
$slug = '';
$status = '';
$arrange ='';

if(!empty($type_Info))
{
    foreach ($type_Info as $si)
    {
        //print_r($si);die;
        $id = $si->id;
        $league_name = $si->league_name;
        $type = $si->type;
        $image = $si->image;
        $slug =$si->slug;
        $arrange =$si->arrange;
        $status = $si->status;
    }
}


?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;">Edit Contest Type
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>editType" method="post" id="editType" role="form" enctype="multipart/form-data" autocomplete="off">
                        <input type="hidden" name="id" value="<?php echo $id;?>">
                          <div class="box-body">
                            <div class="row">
                               <!-- <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="status">League Type</label>
                                        <?php
                                              $s_selected = "";
                                              $m_selected = "";
                                              $e_selected = "";
                                              $a_selected = "";
                                              $b_selected = "";
                                              if ($type == 'MEGA') {

                                                $s_selected = 'selected';
                                              } elseif ($type == 'PRACTICE') {                                      
                                                $m_selected = 'selected';
                                              }elseif ($type == 'OTHERS') {                                      
                                                $e_selected = 'selected';
                                              }
                                              else {
                                                 $s_selected = "";
                                                  $m_selected = "";
                                                  $e_selected = "";
                                                 
                                              }
                                            ?>
                                        <select name="league_type" class="form-control required"  id="league_type">
                                            <option value="" >Select League</option>
                                            <option <?php echo $s_selected;?>  value="MEGA" disabled>MEGA</option>
                                            <option <?php echo $m_selected;?> value="PRACTICE" disabled>PRACTICE</option>
                                             <option <?php echo $e_selected;?> value="OTHERS" disabled>OTHERS</option>
                                        </select>
                                    </div>
                                    
                                </div>-->
                            </div>
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control required" id="type" name="type" value="<?php echo $league_name;?>" maxlength="128">
                                        
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="row">
                                
                                    <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="name">Slug</label>
                                        <input type="text" class="form-control required" id="slug" name="slug" value="<?php echo $slug;?>" maxlength="128">
                                        
                                    </div>
                                    
                                </div>
                                
                            </div>
                             <div class="row">
                                
                                    <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="name">Arrange By</label>
                                        <input type="text" class="form-control required" id="arrange" name="arrange" value="<?php echo $arrange;?>" maxlength="128">
                                        
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="row">
                                
                                    <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="name">Image</label>
                                        <input type="file" class="form-control required" id="logo" name="logo" maxlength="128">
                                        <img src="<?php echo base_url()?>/uploads/<?php echo $image;?>" style="width:50px;height:50px;" class="img-responsive" >
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="status">Status</label>
                                       <select name="status" class="form-control required" id="status">
                                            <option value="">Select Status</option>
                                            <option <?php echo (($status == 'ACTIVE') ? 'selected' : '');?> value="ACTIVE">ACTIVE</option>
                                            <option <?php echo (($status == 'INACTIVE') ? 'selected' : '');?> value="INACTIVE">INACTIVE</option>
                                        </select>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                     <!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script src="<?php echo base_url(); ?>assets/js/editType.js" type="text/javascript"></script>
<!--add datepicker--->


