<div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

      <div class="form-group" style="font-size:18px;font-weight:bold;float:left;"> Player Listing</div>

         <div class="form-group" style="float:right;">
              <a class="btn btn-primary" data-toggle="modal" data-target="#myModal1"><i class="fa fa-search"></i> Find Player</a>
                    <a class="btn btn-primary" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i> Add New Players</a>
         </div>
    </section>

    <section class="content">

        <div class="row">

          <div class="col-md-4">

              <?php

                  $this->load->helper('form');

                  $error = $this->session->flashdata('error');

                  if($error)

                  {

              ?>

              <div class="alert alert-danger alert-dismissable">

                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                  <?php echo $this->session->flashdata('error'); ?>                    

              </div>

              <?php } ?>

              <?php  

                  $success = $this->session->flashdata('success');

                  if($success)

                  {

              ?>

              <div class="alert alert-success alert-dismissable">

                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                  <?php echo $this->session->flashdata('success'); ?>

              </div>

              <?php } ?>

              

              <div class="row">

                  <div class="col-md-12">

                      <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>

                  </div>

              </div>

          </div>

            <div class="col-xs-12">

              <div class="box">

                <div class="box-body table-responsive">

                 

                    <div class="form-group">                  

                      <select name="country" class="form-control input-lg" id="country">

                          <?php                                                

                              foreach($country_list as $cname):

                                  if ($cname == $country) {

                                      $selected = 'selected';

                                  } else {

                                      $selected = '';

                                  }

                                  echo '<option ' . $selected . ' value="' . $cname . '">' . $cname . '</option>';

                              endforeach;

                          ?>

                      </select>                      

                    </div>

                  

                 

                  

                  <div id="playerTbl">
                   
                 

                </div>

                

                </div><!-- /.box-body -->

              </div><!-- /.box -->

            </div>

        </div>

    </section>

</div>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/editPlayer.js" charset="utf-8"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/addPlayer.js" charset="utf-8"></script>
<script type="text/javascript">
   var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric1(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error1").style.display = ret ? "none" : "inline";
            return ret;
        }
</script>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center;font-size: 14px;font-weight: bold;">Add New Player</h4>
        </div>
        <div class="modal-body">
            <form role="form" id="newPlayer" action="<?php echo base_url()?>addNewPlayer" method="post"  autocomplete="off" >
                        <div class="box-body">
                            <div class="col-md-12">
                               
                                    
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Player Name</label>
                                            <input type="text" class="form-control required" id="name"  name="name">
                                        </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Player Id</label>
                                            <input type="text" class="form-control required" id="p_id"  name="p_id" onkeypress="return IsNumeric(event);">
                                             <span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                        </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Player Credit</label>
                                            <input type="text" class="form-control required" id="credit"  name="credit" onkeypress="return IsNumeric1(event);">
                                             <span id="error1" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                        </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">Country</label>
                                           <select class="form-control" name="country" id="country">
                                            
                                              <?php                                                

                                                  foreach($country_list as $cname):

                                                      if ($cname == $country) {

                                                          $selected = 'selected';

                                                      } else {

                                                          $selected = '';

                                                      }

                                                      echo '<option ' . $selected . ' value="' . $cname . '">' . $cname . '</option>';

                                                  endforeach;
                                                ?>
                                          </select>
                                        </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                         <div class="form-group">
                                            <label for="end_dt">Playing Role</label>
                                           <select class="form-control" name="playing_role" id="playing_role">
                                            <option>-Select Player Role--</option>
                                            <option value="BAT">BAT</option>
                                            <option value="BOWL">BOWL</option>
                                             <option value="WK">WK </option>
                                              <option value="AR">AR</option>
                                          </select>
                                        </div>
                                    </div>
                                </div>
                                
                           
                            
                            </div> 
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
        </div>
        
      </div>
    </div>
</div>


<div class="modal fade" id="myModal1" role="dialog" >
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center;font-size: 14px;font-weight: bold;">Find Player</h4>
        </div>
        <div class="modal-body" >
            <form role="form" id="findPlayer"  method="post"  autocomplete="off" >
                        <div class="box-body">
                            <div class="col-md-12">
                               
                                    
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                          <label for="end_dt">Player Name</label>
                                          <input type="text" class="form-control required" id="player_name"  name="player_name" >
                                            
                                        </div>
                                    </div>
                                </div>
                                
                               <div id="display">
                                    <table id="appUserTbl1" class="table table-hover" >
                                        <thead>
                                            <th style='font-weight:bold;'>Sr No</th>
                                                                <th style='font-weight:bold;' >Player ID</th>
                                                                <th style='font-weight:bold;' >Player Name</th>
                                            </thead> 
                                    </table>
                                    
                               </div>
                            
                            </div> 
                        </div><!-- /.box-body -->
    
                      
                    </form>
        </div>
        
      </div>
    </div>
</div>
<script type="text/javascript">
 

//Getting value from "ajax.php".
 
function fill(Value) {
 
   //Assigning value to "search" div in "search.php" file.
 
   $('#player_name').val(Value);
 
   //Hiding "display" div in "search.php" file.
 
   $('#display').hide();
 
}
 
$(document).ready(function() {
 
   //On pressing a key on "Search box" in "search.php" file. This function will be called.
 
   $("#player_name").keyup(function() {
 
       //Assigning search box value to javascript variable named as "name".
 
       var name = $('#player_name').val();
 
       //Validating, if "name" is empty.
 
       if (name == "") {
 
           //Assigning empty value to "display" div in "search.php" file.
 
           $("#display").html("");
 
       }
 
       //If name is not empty.
 
       else {
 
           //AJAX is called.
 
           $.ajax({
 
               //AJAX type is "Post".
 
               type: "POST",
 
               //Data will be sent to "ajax.php".
 
               url: "players/playerSearchAjax",
 
               //Data, that will be sent to "ajax.php".
 
               data: {
 
                   //Assigning value of "name" into "search" variable.
 
                   name: name
 
               },
 
               //If result found, this funtion will be called.
 
               success: function(data) {
 
                   //Assigning result to "display" div in "search.php" file.
                    document.getElementById('appUserTbl1').innerHTML=data;
                   //$("#display").html(html).show();
 
               }
 
           });
 
       }
 
   });
 
});
</script>
