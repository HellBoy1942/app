 <?php 
 error_reporting(0);

 ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;"> Match Management
      </div>
    </section>
    <section class="content">
       <div class="row">
            <div class="col-xs-12">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                   
                    <div class="box-tools">
                      <?php
                        if ($type == 'upcomming') {
                          $action = base_url() . 'upcommingMatches';
                        }
                        if ($type == 'live') {
                          $action = base_url() . 'liveMatches';
                        }
                        if ($type == 'result') {
                          $action = base_url() . 'resultMatches';
                        }
                         if ($type == 'cancel') {
                          $action = base_url() . 'cancelMatches';
                        }
                      ?>
                        
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="match_tbl" class="table table-hover">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Match Id</th>
                        <th>Match Type</th>                  
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Series Name</th>
                        <th>Team 1</th>
                        <th>Team 2</th>
                        <th>Total Contest</th>
                         <th>User Joined</th> 
                        <th>Status</th>
                        <!--<th><?php  if ($type == 'cancel') { echo "Reason";}?></th>-->
                        <th class="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      if(!empty($matchRecords))
                      {
                          foreach($matchRecords as $record)
                          {
                            
                      ?>
                      <tr>
                        <td><?php echo $record->id ?></td>
                        <td><?php echo $record->match_id ?></td>
                        <td><?php echo $record->match_type ?></td>
                        <td><?php echo date("d-m-Y H:i:s", strtotime($record->start_dt)) ?></td>
                        <td><?php echo date("d-m-Y H:i:s", strtotime($record->end_dt)) ?></td>
                        <td><?php echo $series_names[$record->series];?></td>
                        <td><?php echo $record->team1 ?></td>
                        <td><?php echo $record->team2 ?></td>
                        <td><?php echo $leage_list_count[$record->id];?></td>
                        <td><?php echo $join_team_count[$record->id]; ?></td>
                        <td><?php echo $record->admin_status ?></td>
                        <!--<td><?php
                            if ($type == 'cancel') {
                             echo $record->cancel_desc;} ?></td>-->
                        <td class="text-center" style="padding: 5px 0px 0px 0px;">    
                            <?php
                            if ($type == 'upcomming' || $type == 'live') {
                            ?>
                              <a class="btn btn-xs btn-info" href="<?php echo base_url().'editOldMatch/'.$record->match_id; ?>"><i class="fa fa-pencil"></i></a>
                             
                               
                              <?php
                               echo  " <a href='" . base_url() . "leagueListing?match_id=" . $record->match_id . "' class='btn btn-xs btn-info'><i class='fa fa-eye'></i></a>";
                              ?>
                                        
                            <?php
                            }
                            ?>
                            <?php
                            if ($type == 'result') {
                            ?>
                              <a class="btn btn-xs btn-info" href="<?php echo base_url().'viewResultMatch/'.$record->match_id; ?>"><i class="fa fa-eye"></i></a>
                            <?php
                            }
                            ?>
                             <?php
                            if ($type == 'cancel') {
                            ?>
                                
                              <a class="btn btn-xs btn-info" href="<?php echo base_url().'viewResultMatch/'.$record->match_id; ?>"><i class="fa fa-eye"></i></a>
                            <?php
                            }
                            ?>
                           
                            
                        </td>
                      </tr>
                      <?php
                          }
                      }
                      ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
      jQuery('#match_tbl').DataTable();
        // jQuery('ul.pagination li a').click(function (e) {
        //     e.preventDefault();            
        //     var link = jQuery(this).get(0).href;
        //     var type = jQuery("#type").val();            
        //     var value = link.substring(link.lastIndexOf('/') + 1);
        //     if (type == 'upcomming') {
        //       jQuery("#searchList").attr("action", baseURL + "upcommingMatches/" + value);
        //     }
        //     if (type == 'live') {
        //       jQuery("#searchList").attr("action", baseURL + "liveMatches/" + value);
        //     }
        //     if (type == 'result') {
        //       jQuery("#searchList").attr("action", baseURL + "resultMatches/" + value);
        //     }

        //     jQuery("#searchList").submit();
        // });

    });
</script>
