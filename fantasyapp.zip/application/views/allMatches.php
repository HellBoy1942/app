<?php
  $action = base_url() . 'addMatch';
?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;"> All API Matches
      </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                     $match_id = $this->session->flashdata('match_id');
                    if($success)
                    {
                ?>
               <script type="text/javascript">
                 jQuery(document).ready(function(){
                 var match ="<?php echo $match_id; ?>";
                    document.getElementById("bn_id").value = match;
                  $("#myModal111").modal('show');
                 });
               </script>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <?php  
                    $successed = $this->session->flashdata('success');
                   if($success)
                    {
                      //print_r($data);

                ?>
                 <div class="alert alert-successed alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('successed'); ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="all_match_tbl" class="table table-hover">
                    <thead>
                      <tr>
                        <th>Match Id</th>                  
                        <th>Start Date</th>
                        <th>Team 1</th>
                        <th>Team 2</th>
                        <th>Squad</th>
                        <th>Type</th>
                        <th>Toss Winner Team</th>
                        <th>Winner Team</th>
                        <th>Match Started?</th>
                        <th class="text-center">Actions</th>
                      </tr>
                    </thead>   
                    <tbody>
                    <?php
                      if(!empty($matchRecords))
                      {
                          foreach($matchRecords as $i => $record)
                          {
                            $record =  (array) $record;
                            if ($record['matchStarted'] != 1 && $record['squad']) {                              
                      ?>
                      <tr>
                        <td><?php echo $record['unique_id'] ?></td>
                        <td><?php echo date('Y-m-d H:i:s', strtotime($record['dateTimeGMT'])) ?></td>
                        <td><?php echo $record['team-1'] ?></td>
                        <td><?php echo $record['team-2']?></td>
                        <td><?php echo $record['squad'] ?></td>
                        <td><?php echo $record['type'] ?></td>
                        <td><?php echo (isset($record['toss_winner_team'])) ? $record['toss_winner_team'] : "N/A"?></td>
                        <td><?php echo (isset($record['winner_team'])) ? $record['winner_team'] : "N/A"?></td>
                        <td><?php echo $record['matchStarted'] ?></td>
                        <td class="text-center">                    
                          <form action="<?php echo $action?>" method="POST" id="matchAddForm">
                            <div class="input-group">
                              <input type="hidden" name="match_id" value="<?php echo $record['unique_id']; ?>"/>
                              <input type="hidden" name="start_dt" value="<?php echo $record['dateTimeGMT']; ?>"/>
                              <input type="hidden" name="squad" value="<?php echo $record['squad']; ?>"/>
                              <input type="hidden" name="match_type" value="<?php echo $record['type']; ?>"/>
                              <input type="hidden" name="team1" value="<?php echo $record['team-1']; ?>"/>
                              <input type="hidden" name="team2" value="<?php echo $record['team-2']; ?>"/>
                              <input type="hidden" name="matchStarted" value="<?php echo $record['matchStarted']; ?>"/>
                              
                              <div class="input-group-btn">
                                <button title="Add Match to DB" class="btn btn-sm btn-default searchList"><i class="fa fa-plus-circle" aria-hidden="true"></i></button>
                                  <a class="btn btn-xs btn-info" style=" margin-left: 5px;padding: 5px 10px 5px 10px;" href="<?php echo base_url().'playerInfo/'.$record['unique_id']; ?>"><i class="fa fa-eye"></i></a>
                            
                              </div>
                            </div>
                          </form>
                        </td>
                      </tr>
                      <?php
                          }
                        }
                      }
                      ?>
                    </tbody>                    
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php //echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<!-- <script>
     $('#myModal111').modal({
    backdrop: 'static',
    keyboard: false
});
 </script> -->
 <style>
 .modal-body {
       max-height: calc(100% - 300px);
    overflow-y: scroll;
 }
 </style>
 <div id="myModal111" class="modal fade" role="dialog" >
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Laegue List</h4>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo base_url();?>addDefaultLeague" enctype="multipart/form-data">
          <input type="hidden" name="mat_id" id="bn_id"  >
            <table  class="table table-hover">
                        <thead>
                          <tr>
                            <th>select</th>
                            <th> Id</th>                  
                            <th>Name</th>
                            <th>Winner Amount</th>
                            <th>Contest Size</th>
                           
                          </tr>
                        </thead>   
                        <tbody>
                        <?php
                          //print_r($leagueRecords);
                              foreach($leagueRecords as $row)
                              {
                                //print_r($row);
                                                              
                          ?>
                          <tr>
                           
                            
                            <td><input type="checkbox" name="league[]" id="opt1" class="cb"  value="<?php echo $row['id'] ?>" ></td>
                            <td><?php echo $row['id'] ?></td>
                            <td><?php echo $row['name'] ?></td>
                            <td><?php echo $row['winning_amount']?></td>
                            <td><?php echo $row['contest_size'] ?></td>
                           
                          </tr>
                          <?php
                             
                            }
                          
                          ?>
                        </tbody>                    
                      </table>
                      <div  class="form-group">
                       <input type="submit" class="btn btn-primary" value="Submit" />
                          <input type="button" class="btn btn-default" value="Cancel" data-dismiss="modal" />
                       </div>
                </form>
      </div>
      
    </div>

  </div>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('#all_match_tbl').DataTable();
        // jQuery('ul.pagination li a').click(function (e) {
        //     e.preventDefault();            
        //     var link = jQuery(this).get(0).href;
        //     var type = jQuery("#type").val();            
        //     var value = link.substring(link.lastIndexOf('/') + 1);
        //     if (type == 'upcomming') {
        //       jQuery("#searchList").attr("action", baseURL + "upcommingMatches/" + value);
        //     }
        //     if (type == 'live') {
        //       jQuery("#searchList").attr("action", baseURL + "liveMatches/" + value);
        //     }
        //     if (type == 'result') {
        //       jQuery("#searchList").attr("action", baseURL + "resultMatches/" + value);
        //     }

        //     jQuery("#searchList").submit();
        // });
    });
</script>
