<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;">Add New Contest Type 
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" id="newcontestType" action="<?php echo base_url() ?>addnewcontestType" method="post" role="form" enctype="multipart/form-data" autocomplete="off">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="status">League Type</label>
                                        <select name="league_type" class="form-control required" id="league_type">
                                            <option value="">Select League</option>
                                            <option value="MEGA">MEGA</option>
                                            <option value="PRACTICE">PRACTICE</option>
                                             <option value="OTHERS">OTHERS</option>
                                        </select>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control required" id="type" name="type" maxlength="128">
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="row">
                                
                                    <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="name">Slug</label>
                                        <input type="text" class="form-control required" id="slug" name="slug" maxlength="128">
                                    </div>
                                    
                                </div>
                                
                            </div>
                             <div class="row">
                                
                                    <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="name">Arrange By</label>
                                        <input type="text" class="form-control required" id="arrange" name="arrange" maxlength="128">
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="row">
                                
                                    <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="name">Image</label>
                                        <input type="file" class="form-control required" id="logo" name="logo" maxlength="128">
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="status">Status</label>
                                        <select name="status" class="form-control required" id="status">
                                            <option value="">Select Status</option>
                                            <option value="ACTIVE">ACTIVE</option>
                                            <option value="INACTIVE">INACTIVE</option>
                                        </select>
                                    </div>
                                    
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<!-- InputMask -->

