<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <!-- <h1>
        <i class="fa fa-server"></i> Joined Teams
      </h1> -->
    </section>
    
    <section class="content"> 
        <div class="row">
            <div class="box box-primary">
                <div class="col-md-12">
                    <div class="box-body table-responsive">
                      <table class="table table-hover table-bordered table-striped">
                        <tr>
                          <th>Sr No</th>
                          <th>Player Id</th>
                          <th>Player Name</th>  
                          <th>Country</th>                    
                          <th>Player Type</th>
                          <th>Points</th>
                        </tr>
                        <?php
                        if(!empty($players_data))
                        {

                            foreach($players_data as $i => $player)
                            {
                              $vc = "";
                              $vclass = "";
                              $cap = "";
                              $capclass = "";
                              if ($player['pid'] == $crew_data ['captain']) {
                                  $cap = " (C) ";
                                  $capclass = "cap";
                              } else if ($player['pid'] == $crew_data ['vc']) {
                                  $vc = " (VC) ";
                                  $vclass = "vc";
                              }
                        ?>
                        <tr>
                          <td><?php echo $i+1 ?></td>
                          <td><?php echo $player['pid'] ?></td>
                          <td><?php echo $player['name'] ?></td>  
                          <td><?php echo $player['country'] ?></td>                
                          <td class="<?php echo $capclass; echo $vclass?>"><?php echo $player['role'] . $cap . $vc; ?></td>
                          <td><?php echo $player['points'] ?></td>              
                        </tr>
                        <?php
                            }
                        }
                        ?>
                      </table>
                    </div><!-- /.box-body -->
                </div>
            </div>
        </div>
    </section>
</div>