<!-- <?php
  $action = base_url() . 'withdrawChange';
?> -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-server"></i> Withdraw Management
      </h1>
    </section>
    <section class="content">
      
       <div class="row">
            <div class="col-xs-12">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                   <h3 class="box-title">Withdraw Request</h3>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table id="series_tbl" class="table table-hover">
                    <thead>
                      <tr>
                          <th>Sr No</th>
                          <th>User Id</th>
                          <th>Request User</th>                      
                          <th>Request Date</th>
                          <th>Amount</th>
                          <!-- <th>Status</th> -->
                          <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                     <?php
                        if(!empty($withdraw_list))
                        {
                            foreach($withdraw_list as $record)
                            {
                              //print_r($record['status']);
                        ?>
                    <tr>
                       <td><?php echo $record['sr_no'] ?></td>
                          <td><?php echo $record['user_id'] ?></td>
                          <td><?php echo $record['user_name'] ?></td>
                          <td><?php echo date("d-m-Y", strtotime($record['txn_dt'])); ?></td>
                          <td><?php echo $record['txn_amt'] ?></td>
                          
                          <td>
                            <?php 
                              if ($record['status']== 'PENDING') {
                               // print_r($record['status']);
                            ?>
                            <?php $form_action="withdraw/changestatus";?>
                            <!-- <?php echo base_url();?> -->
                            <form  method="POST" action="<?php echo base_url().$form_action?>">
                               <input type="hidden" name="status" id="status" value="success">
                            <input type="hidden" name="user_id" id="user_id" value="<?php echo $record['user_id']?>">
                             <input type="hidden" name="txn_amt" id="txn_amt" value="<?php echo $record['txn_amt']?>">
                              <input type="hidden" name="t_id" id="t_id" value="<?php echo $record['id']?>">
                            <button type="submit" class=" btn btn-primary"  id="btn_accept">ACCEPT</button>&nbsp;
                           
                          </form>
                          &nbsp;
                            <button type="button"  style="margin-top: -59px;
                              margin-left: 71px;" class=" btn btn-primary" id="btn_reject" data-toggle="modal" data-target="#myModal">REJECT</button>
                            &nbsp;
                           <button type="button"  style="margin-top: -59px;" class=" btn btn-primary" disabled id="btn_pay">PAY NOW</button>
                         
                            <?php
                              }

                              elseif($record['status']== 'SUCCESS'){
                              ?>
                               <button type="submit" class=" btn btn-primary" disabled  id="btn1_accept">ACCEPT</button>
                                <button type="button"   class=" btn btn-primary" enabled id="btn1_reject" data-toggle="modal" data-target="#myModal">REJECT</button>
                                 &nbsp;
                                <button type="button"   class=" btn btn-primary" enabled id="btn1_pay">PAY NOW</button>
                           <?php

                              } 

                              elseif($record['status']== 'FAILED')
                              { //print_r($record['status']);
                              ?>
                              <?php $form_action="withdraw/changestatus";?>
                            <!-- <?php echo base_url();?> -->
                            <form  method="POST" action="<?php echo base_url().$form_action?>">
                             <input type="hidden" name="status" id="status" value="success">
                            <input type="hidden" name="user_id" id="user_id" value="<?php echo $record['user_id']?>">
                             <input type="hidden" name="txn_amt" id="txn_amt" value="<?php echo $record['txn_amt']?>">
                              <input type="hidden" name="t_id" id="t_id" value="<?php echo $record['id']?>">
                            <button type="submit" class=" btn btn-primary"  id="btn_accept">ACCEPT</button>&nbsp;
                           
                          </form>
                          &nbsp;
                            <button type="button"  style="margin-top: -59px;
                              margin-left: 71px;" class=" btn btn-primary" id="btn2_reject" disabled>REJECT</button>
                            &nbsp;
                           <button type="button"  style="margin-top: -59px;" class=" btn btn-primary" disabled id="btn_pay">PAY NOW</button>

                            <?php  
                              }
                            ?>
                          </td>
                        </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
 <div class="modal fade"  id="myModal" role="dialog">
                                            <div class="modal-dialog">
                                            
                                              <!-- Modal content-->
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                  <h4 class="modal-title"><b>why you have rejected this request??</b></h4>
                                                </div>
                                                <div class="modal-body">
                                                   <?php $form_action="withdraw/changestatus";?>
                                                    <form method="post" action="<?php echo base_url().$form_action?>" >
                                                    <input type="hidden" name="t_id" id="t_id" value="<?php echo $record['id'];?>">
                                                     <input type="hidden" name="status" id="status_1" value="failed">
                                                    <textarea rows="4" cols="50" name="txn_msg"></textarea>
                                                    <br>
                                                    <button type="submit"  id="update" class="btn btn-info" >Update</button>
                                                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                              </div>
                                              
                                            </div>
                                          </div>
 
 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script type="text/javascript">
    jQuery(document).ready(function(){
      jQuery('#series_tbl').DataTable({"order": [[1, 'desc']]});
    });

    $(document).ready(function(){
    $("#btn_accept").click(function(){
      //alert('hlo');
      $("#btn_pay").attr('disabled','disabled');
      $("#btn_reject").attr('disabled','disabled');
       
      // return false;

         
        //alert("The paragraph was clicked.");
      });
      
    });
</script>
