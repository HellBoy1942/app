<?php 
                    if(!empty($player_records)) {
                  ?> 
                  <table id="player_tbl3" class="table table-hover table-bordered table-striped">
                    <tr>
                      <th class="text-center" colspan="5"><?php echo ucfirst($country); ?></th>  
                    </tr>
                    <tr>
                      <th>PLAYER ID</th>
                      <th>NAME</th>  
                      <th>POINTS</th>                  
                      <th>PLAYING ROLE</th>                  
                      <th>CREDIT</th> 
                      
                    </tr>
                      <?php 
                        foreach($player_records as $record){
                         
                          ?>
                      <tr>
                        
                      <td><?php echo $record->p_id; ?></td>
                      <td><?php echo $record->name;?> </td> 
                      <td><?php echo $record->points; ?></td> 
                      
                                   
                      <td><?php echo $record->playing_role;?></td>
                                   
                      <td><?php echo $record->credit ?> </td>
                    
                     </form>  
                    </tr>
                    <?php
                      }
                  ?>
                  </table>
                   <?php
                    
                  }
                  ?> 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/editPlayer.js" charset="utf-8"></script>