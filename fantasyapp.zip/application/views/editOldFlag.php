<?php



$id = '';

$image_name = '';

$team_name = '';
$short_name ='';







if(!empty($flag_info_edit))

{

    foreach ($flag_info_edit as $si)

    {

        $id = $si->id;

        $image_name = $si->image_name;

        $team_name = $si->team_name;
         $short_name = $si->short_name;

       

        //$team1_short_name = $si->team1_short_name;

       // $team2_short_name = $si->team2_short_name;



    }

}





?>



<div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

      <div class="form-group" style="font-size:18px;font-weight:bold;">
      Edit Flag

      </div>

    </section>

    

    <section class="content">

    

        <div class="row">

            <!-- left column -->

            <div class="col-md-4">

                <?php

                    $this->load->helper('form');

                    $error = $this->session->flashdata('error');

                    if($error)

                    {

                ?>

                <div class="alert alert-danger alert-dismissable">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    <?php echo $this->session->flashdata('error'); ?>                    

                </div>

                <?php } ?>

                <?php  

                    $success = $this->session->flashdata('success');

                    if($success)

                    {

                ?>

                <div class="alert alert-success alert-dismissable">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    <?php echo $this->session->flashdata('success'); ?>

                </div>

                <?php } ?>

                

                <div class="row">

                    <div class="col-md-12">

                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>

                    </div>

                </div>

            </div>

            <div class="col-md-12">

                <div class="box box-primary">

                    <!-- form start -->

                    

                    <form role="form" action="<?php echo base_url() ?>editFlag" method="post" enctype="multipart/form-data" id="editFlag" role="form" autocomplate="off">

                        <div class="box-body">

                            <div class="col-md-6">

                                <div class="row">

                                    <div class="col-md-12">

                                        <div class="form-group">

                                            <label for="start_dt">Flag</label>

                                            <input type="file" name="image_name" id="image_name" class="form-control"/>

                                            <input type="hidden" name="flag_id" value="<?php echo $id;?>">

                                            <?php 

                                                if (!empty($image_name)) {

                                            ?>

                                                <img src="<?php echo base_url() ?>uploads/<?php echo $image_name?>" width="50" height="30" id="blah">

                                            <?php

                                                }

                                            ?>
                                    <span style="color:red;">Note* Team Flag Icon should be 150*150 without Canvas</span>
                                        </div>

                                    </div>

                                    <div class="col-md-12">

                                        <div class="form-group">

                                            <label for="start_dt">Team Name</label>

                                            <input type="text" name="team_name" id="team_name" class="form-control" value="<?php echo $team_name;?>" />

                                           

                                        </div>
                                         

                                    </div>
                                    <div class="col-md-12">

                                        <div class="form-group">

                                            <label for="start_dt">Short Name</label>

                                            <input type="text" name="short_name" id="short_name" class="form-control" value="<?php echo $short_name;?>" />

                                           

                                        </div>
                                         

                                    </div>
                                </div>

                                  

                            </div><!-- /.col-md-6 -->



                           </div>

        

                            <div class="box-footer">

                                <input type="submit" class="btn btn-primary" value="Submit" />

                                 <input type="reset" class="btn btn-default" value="Reset" />

                            </div>

                        

                    </form>

                </div>

            </div>



        </div>   

        

    </section>

</div>
<script src="<?php echo base_url(); ?>assets/js/editFlag.js" type="text/javascript"></script>
<script type="text/javascript">
    function readURL(input) {

  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }

    reader.readAsDataURL(input.files[0]);
  }
}

$("#image_name").change(function() {
  readURL(this);
});
</script>
 <script>
    $(function () {
    $("#image_name").change( function () {
        //Get reference of FileUpload.
        var fileUpload = $("#image_name")[0];
 
        //Check whether the file is valid Image.
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png)$");
        if (regex.test(fileUpload.value.toLowerCase())) {
            //Check whether HTML5 is supported.
            if (typeof (fileUpload.files) != "undefined") {
                //Initiate the FileReader object.
                var reader = new FileReader();
                //Read the contents of Image File.
                reader.readAsDataURL(fileUpload.files[0]);
                reader.onload = function (e) {
                    //Initiate the JavaScript Image object.
                    var image = new Image();
                    //Set the Base64 string return from FileReader as source.
                    image.src = e.target.result;
                    image.onload = function () {
                        //Determine the Height and Width.
                        var height = this.height;
                        var width = this.width;
                        if (height > 150 || width > 150) {
                            alert("Width and Height  must not exceed 150*150px.");
                             $("#image_name").val("");
                            return false;
                        }
                       
                    };
                }
            } else {
                alert("This browser does not support HTML5.");
                return false;
            }
        } else {
            alert("Please select a valid Image file.");
            return false;
        }
    });
});
</script>



