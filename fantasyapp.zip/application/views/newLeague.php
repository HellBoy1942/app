<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <div class="form-group" style="font-size:18px;font-weight:bold;"> Add New League
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" id="newLeague" action="<?php echo base_url() ?>addNewLeague" method="post" role="form" autocomplete="off">
                         <input type="hidden" name="is_default" value="<?php echo $is_default;?>">  
                        <div class="box-body">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">                           
                                        <div class="form-group">
                                            <label for="name">Leage Type</label>
                                            <select class="form-control required" id="league_type" name="league_type">
                                                <option value="">--Select League Type--</option>
                                                <?php 
                                                foreach ($type_list as $row):
                                               
                                               
                                               echo' <option value="'.$row->id. '">'. $row->league_name.'</option>';
                                               
                                               endforeach;?>
                                            </select> 
                                            
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="start_dt">Match</label>
                                            <select name="match" class="form-control required" id="match">
                                                <?php                                                
                                                    foreach($match_list as $id => $name):
                                                        echo '<option value="' . $id . '">' . $name. '</option>';
                                                    endforeach;
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="end_dt">League Name</label>
                                            
                                            <input type="text" name="name" id="name" class="form-control required">
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status" id="fee">Entry Fees</label>
                                            <input type="text" class="form-control required" id="fees" name="fees" value="" maxlength="128" >
                                            <span id="error2" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group bg-info">
                                            <label for="status" id="fee">Bonus %</label>
                                            <input type="text" class="form-control required" id="bonus1" name="bonus1" value="" maxlength="128" >
                                            <span id="error212" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                        </div>
                                        
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status">League Size</label>
                                            <input type="text" class="form-control required" id="size" name="size" value="" maxlength="128" onkeypress="return IsNumeric1(event);" ondrop="return false;" onpaste="return false;">
                                             <span id="error1" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status" id="t_amt">Total Amount</label>
                                            <input type="text" class="form-control required"  readonly="readonly" 
                                            id="total_amount" name="total_amount" value="" maxlength="128">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status" id="amt">Winning Amount</label>
                                            <input type="text" class="form-control required" id="win_amount" name="win_amount" value="" maxlength="128" >
                                            <span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status" id="margin">Total Margin (Rs. && %)</label>
                                            <input type="text"  style= "width: 50%" class="form-control required" id="total_margin" name="total_margin" readonly="readonly" placeholder="(Rs.)"  value="" maxlength="128">
                                              <input type="text"  style= "width: 50%;margin-top: -34px;margin-left: 190px;" class="form-control required" placeholder="(%)" readonly="readonly" id="total_per" name="total_per" value="" maxlength="128">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row" style="display: none;">
                                    <div class="col-md-12" >                                
                                        <div class="form-group">
                                            <label for="status" id="fresh">Fresh Margin</label>
                                            <input type="text" class="form-control required"  readonly="readonly" id="fresh_margin" name="fresh_margin" value="" maxlength="128">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row" style="display: none;">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status" id="gst">GST Amount</label>
                                            <input type="text" class="form-control required" readonly="readonly" id="gst_amount" name="gst_amount" value="" maxlength="128">
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                           <input type="checkbox" name="multi_joined" id="ismultijoined" value="1"><label id="multi">  Join with multiple teams?</label> 
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                          <input type="checkbox" name="cancel_contest" id="iscontestcancelled" value="1"> <label id="contest">  Contest can be cancel?</label>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                          <input type="checkbox" name="auto_repeat" id="autorepeat1" value="1"> <label id="contest">  Auto Repeat</label>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                          <input type="checkbox" name="template" id="template" value="1"> <label id="contest">  Save as Template</label>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label id="default"> Is Default</label>
                                          <input type="checkbox" name="is_default" class="cb" id="is_default1" value="1"  onClick="cbChange(this);"> 
                                          <label id="default"> YES</label>
                                           <input type="checkbox" name="is_default" id="is_default"  value="0" class="cb"   checked onClick="cbChange(this);">
                                           <label id="default"> NO </label>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="status" id="set">Set No of Winners</label>
                                            <input type="text" class="form-control required" id="set_of_winners" name="set_of_winners" value="" maxlength="128">
                                            <div id="winner_data_wraper">
                                                <fieldset id="winner_detail_wrap">
                                                    <legend>Add Winner Details</legend>
                                                </fieldset>
                                                <input type="button" value="Add a field" class="add" id="add"/>
                                            </div>
                                            <p id="win_error"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12" id="winner_section">
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-3">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<link href="<?php echo base_url(); ?>assets/dist/css/custom.css" rel="stylesheet" type="text/css" />
<!-- add series valida -->
<script src="<?php echo base_url(); ?>assets/js/addLeague.js" type="text/javascript"></script>
<script type="text/javascript">
 function totalMargin()
    {

        var win_amount = $("#win_amount").val();
        var total_amount = $("#total_amount").val();
        var total_margin = (total_amount  - win_amount );
        $("#total_margin").val(total_margin);
        var total_margin_per = ((win_amount * 100) / total_amount);
        var total_per = (100 - total_margin_per).toFixed(2);
        $("#total_per").val(total_per);
        var  gst = 18;
        var gst_amount =  (total_margin * (gst / 100)).toFixed(2);
       
        $("#gst_amount").val(gst_amount);
        var fresh_margin = (total_margin - gst_amount).toFixed(2);
        $("#fresh_margin").val(fresh_margin);
    }

    $(document).on("change, keyup", "#win_amount", totalMargin);
   
    function entryFees()
    {

        var fees = $("#fees").val();
        var size = parseFloat($("#size").val());
        var total_earning = (fees  * size );
      
        $("#total_amount").val(total_earning);
    }

    $(document).on("change, keyup", "#fees", entryFees);
    $(document).on("change, keyup", "#size", entryFees);
    function cbChange(obj) {
   // alert("hlo");
        var cbs = document.getElementsByClassName("cb");
        for (var i = 0; i < cbs.length; i++) {
            cbs[i].checked = false;
        }
        obj.checked = true;
}
    $("#league_type").change(function(){
        if ($(this).val() == '1') {
            //alert('hlo');
          $("#win_amount").hide();
             $("#total_amount").hide();
             $("#total_per").hide();
            $("#total_margin").hide();
            $("#set_of_winners").hide();
            $("#entry_fees").hide();
             $("#fees").hide();
              $("#fee").hide();
            $("#iscontestcancelled").hide();
            $("#ismultijoined").hide();
            $("#contest").hide();
            $("#amt").hide();
           
            $("#set").hide();
            $("#multi").hide();
           
            $("#t_amt").hide();
            $("#margin").hide();
        } else {
            $("#win_amount").show();
            $("#size").show();
            $("#margin").show();
            $("#entry_fees").show();
             $("#fees").show();
             $("#fee").show();
            $("#set_of_winners").show();
            $("#set").show();
            $("#amt").show();
            $("#marg").show();
            $("#multi").show();
            $("#ismultijoined").show();
            $("#contest").show();
            $("#iscontestcancelled").show();

        }

    });
    
    $("#league_type").change(function(){
       
        if ($(this).val() == '3'|| $(this).val() == '5') {
            //alert('hlo');
            $('#name').val('OTHERS');
            
        } else if ($(this).val() == '1') {
            $('#name').val('PRACTICE');

        }
        else if ($(this).val() == '2'|| $(this).val() == '6') {
        $('#name').val('MEGA'); 

        }
            else if ($(this).val() == '1') {
                // alert('hlo');
        $('#name').val('PRIVATE');  

        }


    });
        var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error").style.display = ret ? "none" : "inline";
            return ret;
        }
        var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric1(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error1").style.display = ret ? "none" : "inline";
            return ret;
        }
    </script>