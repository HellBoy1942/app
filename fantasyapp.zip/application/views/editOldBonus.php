<?php 
$id = '';
$referral_bonus = '';
$register_bonus = '';
$cash_bonus_used = '';
$referral_bonus_used = '';
$pan_verify_bonus ='';
$bank_verify_bonus ='';
$email_verify_bonus ='';
$mobile_verify_bonus ='';
$withdraw_request_limit ='';

if(!empty($bonus_info))
{
    foreach ($bonus_info as $bi)
    { //print_r($bi);
        $id = $bi->id;
        //echo $id;
        $referral_bonus = $bi->referral_bonus;
        $register_bonus = $bi->register_bonus;
        $cash_bonus_used = $bi->cash_bonus_used;
        $referral_bonus_used = $bi->referral_bonus_used;
        $pan_verify_bonus = $bi->pan_verify_bonus;
        $bank_verify_bonus = $bi->bank_verify_bonus;
        $email_verify_bonus = $bi->email_verify_bonus;
        $mobile_verify_bonus = $bi->mobile_verify_bonus;
        $withdraw_request_limit = $bi->withdraw_request_limit;
    }
}

?>  
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-server"></i> Settings
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <!-- form start -->
                    <form method="post" action="<?php echo base_url()?>editSetting" autocomplete="off">
                     <div class="box-body">
                                <div class="col-md-12">
                                    <div class="row">
                                        <input type="hidden" name="b_id" value="<?php echo $id;?>"> 
                                        <h4>Bonus Uses Detail</h4>
                                        <div class="row">
                                            <div class="col-md-6">
                                               
                                                    <div class="form-group">
                                                        <label for="end_dt">First Time Register Cash Bonus(Rs)</label>
                                                        <input type="text" class="form-control required" id="register_bonus"  name="register_bonus" value="<?php echo $register_bonus; ?>" onkeypress="return IsNumeric(event);">
                                                         <span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                               
                                            </div>
                                            <div class="col-md-6">
                                                
                                                    <div class="form-group">
                                                        <label for="end_dt">Referral Bonus Amount(Rs)</label>
                                                        <input type="text" class="form-control required" id="referral_bonus"  name="referral_bonus"  value="<?php echo $referral_bonus; ?>" onkeypress="return IsNumeric1(event);">
                                                         <span id="error1" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                               
                                            </div>
                                        </div>
                                        <!-- <div class="row">
                                            <div class="col-md-6"> 
                                                                              
                                                    <div class="form-group">
                                                        <label for="status">Mobile Verify Cash Bonus(Rs))</label>
                                                        <input type="text" class="form-control required" id="mobile_verify_bonus" name="mobile_verify_bonus"   value="<?php echo $mobile_verify_bonus; ?>" onkeypress="return IsNumeric9(event);">
                                                         <span id="error9" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                                
                                                
                                            </div>
                                            <div class="col-md-6">
                                             
                                                    <div class="form-group">
                                                        <label for="end_dt">Email Verify Cash Bonus(Rs)</label>
                                                        <input type="text" class="form-control required" id="email_verify_bonus"  name="email_verify_bonus" value="<?php echo $email_verify_bonus; ?>" onkeypress="return IsNumeric10(event);">
                                                         <span id="error10" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                               
                                            </div>
                                        </div> -->
                                        <!-- <div class="row">
                                            <div class="col-md-6"> 
                                                                              
                                                    <div class="form-group">
                                                        <label for="status">Pan Card Verification  Bonus(Rs)</label>
                                                        <input type="text" class="form-control required" id="pan_verify_bonus" name="pan_verify_bonus"   value="<?php echo $pan_verify_bonus; ?>" onkeypress="return IsNumeric2(event);">
                                                         <span id="error2" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                                
                                                
                                            </div>
                                            <div class="col-md-6">
                                             
                                                    <div class="form-group">
                                                        <label for="end_dt">Bank Details Bonus(Rs)</label>
                                                        <input type="text" class="form-control required" id="bank_verify_bonus"  name="bank_verify_bonus" value="<?php echo $bank_verify_bonus; ?>" onkeypress="return IsNumeric3(event);">
                                                         <span id="error3" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                               
                                            </div>
                                        </div>
                                        <h4>Usable Amount</h4>
                                        <div class="row">

                                            <div class="col-md-6"> 
                                                                       
                                                    <div class="form-group">
                                                        <label for="status">Cash Bonus Used (%)</label>
                                                        <input type="text" class="form-control required" id="cash_bonus_used" name="cash_bonus_used" onkeypress="return IsNumeric4(event);" value="<?php echo $cash_bonus_used; ?>">
                                                         <span id="error4" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                                
                                                
                                            </div>
                                            <div class="col-md-6">
                                                
                                                    <div class="form-group">
                                                        <label for="end_dt">Referral Bonus Used (%)</label>
                                                        <input type="text" class="form-control required" id="referral_bonus_used"  name="referral_bonus_used"  value="<?php echo $referral_bonus_used; ?>" onkeypress="return IsNumeric5(event);">
                                                         <span id="error5" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                                
                                            </div>
                                        </div> -->
                                       
                                        <div class="row">
                                          <div class="col-md-6">
                                                
                                                    <div class="form-group">
                                                        <label for="status">Withdraw Request Limit(Rs)</label>
                                                        <input type="text" class="form-control required" id="withdraw_request_limit" name="withdraw_request_limit" value="<?php echo $withdraw_request_limit; ?>" onkeypress="return IsNumeric8(event);" >
                                                         <span id="error8" style="color: Red; display: none">* Input digits (0 - 9)</span>
                                                    </div>
                                                
                                             </div>  
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                    
              
                      <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div> 
                    </form>
                </div>
            </div>
            <div class="col-md-2">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<!-- add series valida -->
<script type="text/javascript">
    var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric1(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error1").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric2(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error2").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric3(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error3").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric4(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error4").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric5(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error5").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric6(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error6").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric7(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error7").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric8(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error8").style.display = ret ? "none" : "inline";
            return ret;
        }
         var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric9(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error9").style.display = ret ? "none" : "inline";
            return ret;
        }
        var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric10(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error10").style.display = ret ? "none" : "inline";
            return ret;
        }
</script>