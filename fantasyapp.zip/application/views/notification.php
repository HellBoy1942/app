<?php

$id = '';
$match_id = '';
$name = '';
$start_dt = '';
$team1 = '';
$team2 = '';
$series = '';
$match_type = '';
$admin_status = '';


if(!empty($match_info))
{
    foreach ($match_info as $si)
    {
        $id = $si->id;
        $match_id = $si->match_id;
        $team1 = $si->team1;
        $team2 = $si->team2;
        $start_dt = date("d-m-Y H:i:s", strtotime($si->start_dt));
        //$end_dt = date('d-m-Y H:i:s',strtotime('+1 day',strtotime($si->start_dt)));
        $end_dt = date('d-m-Y H:i:s',strtotime($si->end_dt));
        $admin_status = $si->admin_status;
        $series = $si->series;
        $match_type = $si->match_type;
        $team1_logo = $si->team1_logo;
        $team2_logo = $si->team2_logo;
    }
}


?>
<style>
.open>.dropdown-menu {
    display: block;
    height: 150px!important;
    overflow-y: scroll;
}
    .btn-default {
    background-color: #fff!important; 
    color: #444;
    border-color: #ddd;
}
.btn-default:hover, .btn-default:active, .btn-default.hover {
     background-color: #fff !important; 
}
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="form-group" style="font-size:18px;font-weight:bold;">Notification
      </div>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>notify_user" method="post" id="notify_form" role="form" autocomplete="off">
                         <div class="box-body">
                            <div class="col-md-6">
                                <div class="row">
                                    <!--<div class="col-md-12">                   
                                        <div class="form-group">
                                            <label for="all_user">To All Users</label>
                                            <select name="user" id="user" class="form-control">
                                                <option> Select User</option>
                                                <option value="AllUSER">All Users</option>
                                                <option value="SPECIFICUSER ">Specific Users</option>
                                            </select>
                                        </div>                                    
                                    </div>-->
                                    <div class="col-md-12" >
                                        <div class="form-group" >
                                            <label for="start_dt" id="users" >Select User</label>
                                            <select id="boot-multiselect-demo" multiple="multiple" name="user[]">
                                                  
                                                    <?php 
                                                foreach ($users as $row):
                                                
                                               echo' <option value="'.$row->id. '">'. $row->name.'-'.$row->id.'</option>';
                                               
                                               endforeach;?>
                                            </select>
                                          <!--  <input type="text" name="user_ids" id="user_ids" placehoder="Enter user ids separated by comma" class="form-control"/>   -->    
                                        </div>
                                    </div>
                                    <div class="col-md-12" >
                                        <div class="form-group">
                                            <label for="start_dt">Title</label>
                                            <input required type="text" placehoder="Message Title" name="title" id="title" class="form-control" value="">
                                        </div>
                                    </div>
                                    <div class="col-md-12" >
                                        <div class="form-group">
                                            <label for="end_dt">Message</label>
                                            <textarea required name="message" id="message" placeholder="Enter Message here" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="box-footer">
                                    <input type="submit" class="btn btn-primary" value="Submit" />
                                </div>
                            </div><!-- /.col-md-6 -->
                        </div>
                    </form>
                </div>
            </div>
        </div>   
        <div class="row">
        	<div class="col-xs-12">
        	  <div class="box">
        	    <div class="box-header">
        	    </div><!-- /.box-header -->
        	    <div class="box-body table-responsive no-padding">
        	      <table id="notification_tbl" class="table table-hover">
        	        <thead>
        	          <tr>
        	            <th>Id</th>
        	            <th>Date</th>
        	            <th>Title</th>
        	            <th>Message</th>        	         
        	            <th class="text-center">Actions</th>
        	          </tr>
        	        </thead>
        	        <tbody>
        	          <?php
        	          if(!empty($notification_list))
        	          {
        	              foreach($notification_list as $record)
        	              {
        	          ?>
        	          <tr>
        	            <td><?php echo $record->id ?></td>
        	            <td data-order="<?php print strtotime($record->created_dt);?>"><?php echo date("d-m-Y H:i:s", strtotime($record->created_dt)) ?></td>
        	            <td class="title"><?php echo $record->title ?></td>
        	            <td class="msg"><?php echo $record->message ?></td>
        	            <td class="text-center"> 
        	              <a class="btn btn-sm btn-info repeat">Repeat</a>
        	            </td>
        	          </tr>
        	          <?php
        	              }
        	          }
        	          ?>
        	        </tbody>
        	      </table>
        	      
        	    </div><!-- /.box-body -->
        	    <div class="box-footer clearfix">
        	    </div>
        	  </div><!-- /.box -->
        	</div>
        </div> 
    </section>
</div>
   

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/css/bootstrap-multiselect.css" type="text/css">
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/js/bootstrap-multiselect.js"></script>
       <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/js/bootstrap-multiselect.min.js"></script>-->
<script type="text/javascript" src="<?php echo base_url()?>assets/js/addNotification.js"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $('#boot-multiselect-demo').multiselect({
            includeSelectAllOption: true,
            buttonWidth: 580,
            enableFiltering: true,
            enableCaseInsensitiveFiltering:true
        });
        });

        $("#user").change(function(){
        if ($(this).val() == 'AllUSER') {
             $("#users").hide();
            $("#user_ids").hide();
        
        } else{
           
            $("#users").show();
            $("#user_ids").show(); 
        }
            
    

    });
	jQuery(document).ready(function(){
        jQuery('#notification_tbl').DataTable({"order": [[1, 'asc']]});
		jQuery('.repeat').click(function() {
			var title = jQuery(this).parent().parent().find(".title").html();
			var msg = jQuery(this).parent().parent().find(".msg").html();
			jQuery("#title").val(title);
			jQuery("#message").val(msg);
			console.log(title);
			console.log(msg);
		});

	});

</script>