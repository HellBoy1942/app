<?php
$team1 = '';
$team2 = '';



if(!empty($squads))
{

 
    foreach ($squads as $i => $squad) {
        $players[] = $squad->players;
        $teams[] = $squad->name;

    }


  
}
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="form-group" style="font-size:18px;font-weight:bold;">Player Information
      </div>
    </section>
    <section class="content">
        <div class="row">
                <div class="box box-primary">
                    <div class="col-md-6">
                    <div class="box-body table-responsive">
                      <table class="table table-hover table-bordered table-striped">
                        <tr>
                          <th class="text-center" colspan="5">
                            <?php 
                                if (!empty($team1_logo)) {
                            ?>
                                <img src="<?php echo base_url() ?>uploads/<?php echo $team1_logo?>" width="50" height="30">
                            <?php
                                }
                            ?>
                            <?php echo $teams[0]; ?></th>  
                        </tr>
                        <tr>
                          <th>PLAYER ID</th>
                          <th>PLAYER NAME</th> 
                       
                        </tr>
                        <?php
                        if(!empty($players[0]))
                        {
                            foreach($players[0] as $record)
                            {
                                
                        ?>
                        <tr>
                          <td><?php echo $record->pid ?></td>
                          <td><?php echo $record->name ?></td>  
                          
                          
                        </tr>
                        <?php
                            }
                        }
                        ?>
                      </table>
                      
                    </div><!-- /.box-body -->

                </div>

                <div class="col-md-6">
                    <div class="box-body table-responsive">
                      <table class="table table-hover table-bordered table-striped">
                        <tr>
                          <th class="text-center" colspan="5">
                            <?php 
                                if (!empty($team2_logo)) {
                            ?>
                                <img src="<?php echo base_url() ?>uploads/<?php echo $team2_logo?>" width="50" height="30">
                            <?php
                                }
                            ?>
                            <?php echo $teams[1]; ?></th>  
                        </tr>
                        <tr>
                          <th>PLAYER ID</th>
                          <th>PLAYER NAME</th>    
                         
                        </tr>
                        <?php
                         if(!empty($players[1]))
                        {
                            foreach($players[1] as $record)
                            {
                        ?>
                        <tr>
                          <td><?php echo $record->pid ?></td>
                          <td><?php echo $record->name ?></td>  
                          
                        
                        </tr>
                        <?php
                            }
                        }
                        ?>
                      </table>
                      
                    </div><!-- /.box-body -->

                </div>
                </div>
        </div>
    </section>
  </div>  