<?php

class DbOperation {

    //Database connection link
    private $con;

    //Class constructor
    function __construct() {
        //Getting the DbConnect.php file
        include_once('../db_config.php');
        include_once('DbConnect.php');
        //Creating a DbConnect object to connect to the database
        $db = new DbConnect();

        //Initializing our connection link of this class
        //by calling the method connect of DbConnect class
        $this->con = $db->connect();
    }

    //getting all tokens to send push to all devices
    public function getAllTokens() {
        $stmt = $this->con->prepare("SELECT fcm_id FROM user");
        $stmt->execute();
        $result = $stmt->get_result();
        $tokens = array();
        while ($token = $result->fetch_assoc()) {
            array_push($tokens, $token['fcm_id']);
        }
        return $tokens;
    }

    //getting a specified token to send push to selected device
    public function getSingleUser($user_id) {
        // $stmt = $this->con->prepare("SELECT fcm_id FROM user WHERE id = ?");
        //$stmt->bind_param("s", $user_id);
       // $stmt->execute();
        $query = "select fcm_id from user where id='27'";
        
        $result = mysqli_query($this->con, $query);
        $result = mysqli_fetch_assoc($result);
       // print_r($result);
        //$result = $stmt->get_result()->fetch_assoc();
        return array($result['fcm_id']);
    }

    //getting all the registered devices from database 
    public function getAllDevices() {
        $stmt = $this->con->prepare("SELECT * FROM user");
        $stmt->execute();
        $result = $stmt->get_result();
        return $result;
    }

}
