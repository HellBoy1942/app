<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class SendPushNotification {

    private $db;

    //Class constructor
    function __construct() {
        include_once('DbOperation.php');
        include_once('Firebase.php');
        include_once('Push.php');

        $this->db = new DbOperation();
    }

    public function sendPushNotification($title, $message, $image, $user_id) {
        $response = array();
        
        if (isset($title) and isset($message)) {
            //creating a new push
            $push = null;
            //first check if the push has an image with it
            if (isset($image)) {
                $push = new Push(
                        $title, $message, $image
                );
            } else {
                //if the push don't have an image give null in place of image
                $push = new Push(
                        $title, $message, null
                );
            }

            //getting the push from push object
            $mPushNotification = $push->getPush();
            //print_r($mPushNotification);
            //getting the token from database object 
            $devicetoken = $this->db->getSingleUser($user_id);
            echo "Device Token" . $devicetoken;
            //creating firebase class object 
            $firebase = new Firebase();

            //sending push notification and displaying result 
            echo $firebase->send($devicetoken, $mPushNotification);
        } else {
            echo "Hello world WRONG ";
            $response['error'] = true;
            $response['message'] = 'Parameters missing';
        }
    }

    public function sendNotificationtoALL($title, $message, $image) {
        $response = array();
        if (isset($title) and isset($message)) {
            //creating a new push
            $push = null;
            //first check if the push has an image with it
            if (isset($image)) {
                $push = new Push(
                        $title, $message, $image
                );
            } else {
                //if the push don't have an image give null in place of image
                $push = new Push(
                        $title, $message, null
                );
            }

            //getting the push from push object
            $mPushNotification = $push->getPush();

            //getting the token from database object 
            $devicetoken = $this->db->getAllDevices();

            //creating firebase class object 
            $firebase = new Firebase();

            //sending push notification and displaying result 
            $firebase->send($devicetoken, $mPushNotification);
        } else {
            $response['error'] = true;
            $response['message'] = 'Parameters missing';
        }
    }

}
